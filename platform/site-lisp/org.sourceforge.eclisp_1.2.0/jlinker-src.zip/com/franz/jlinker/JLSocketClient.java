package com.franz.jlinker;

import com.franz.jlinker.JLSocketClient.Registry;
import java.util.Hashtable;

public class JLSocketClient extends JLSocketCodes {
   static Hashtable<Integer, Registry> table;
   static int connectIndex = -1;
   static int nextIndex;
   static int tableLive;
   static int tableFree;
   static Registry oldestFree;
   static Registry newestFree;
   static final int topIndex = 536870912;
   public static int bigIndex = 402653184;

   static synchronized void registerJavaObject(Object x, TranStruct struct) {
      Registry nextEntry = null;
      int ix;
      if (oldestFree != null) {
         nextEntry = oldestFree;
         ix = oldestFree.num;
         oldestFree = (Registry)oldestFree.ref;
         --tableFree;
      } else {
         if (nextIndex >= 536870912) {
            throw new IllegalStateException("Jlinker Java Object Registry is full.");
         }

         ix = nextIndex++;
         nextEntry = new Registry(0, x);
         nextEntry.num = ix;
      }

      nextEntry.ref = x;
      table.put(ix, nextEntry);
      struct.nums[0] = ix;
      struct.nums[1] = connectIndex;
      ++tableLive;
   }

   static synchronized void discard(int num) {
      Registry oldEntry = (Registry)table.remove(num);
      if (oldEntry == null) {
         JLCommon.dsprint("Discarding UNREGISTERED handle " + num);
      } else {
         oldEntry.ref = null;
         if (oldestFree == null) {
            oldestFree = oldEntry;
         } else {
            newestFree.ref = oldEntry;
         }

         newestFree = oldEntry;
         ++tableFree;
         --tableLive;
      }
   }

   static boolean query(boolean verify) {
      Object err = null;
      if (JLCommonSocket.isReady()) {
         if (!verify) {
            return true;
         }

         TranStruct[] r = null;

         try {
            r = invokeInLisp(2, new TranStruct("cl:values"), new TranStruct[0], 1000);
         } catch (Exception var4) {
            err = var4;
         }

         if (r != null && r.length == 1 && r[0].integerP() && r[0].intValue() == 0) {
            return true;
         }

         JLCommon.dsprint("query: disconnecting r=" + TranStruct.show(r) + "  err=" + err);
         JLCommonSocket.disconnect();
      }

      return false;
   }

   static synchronized String extractJavaType(TranStruct ob, Object[] cache) {
      if (ob == cache[2]) {
         return (String)cache[0];
      } else {
         cache[1] = null;
         cache[2] = ob;
         extractJavaItem(ob, cache);
         return (String)cache[0];
      }
   }

   static synchronized Object extractJavaRef(TranStruct ob, Object[] cache) {
      if (ob == cache[2]) {
         return cache[1];
      } else {
         cache[1] = null;
         cache[2] = ob;
         extractJavaItem(ob, cache);
         return cache[1];
      }
   }

   static Object[] extractJavaItem(TranStruct ob, Object[] cache) {
      if (!liveP(ob)) {
         cache[0] = "err";
         cache[1] = "Discarded Object 1";
         return cache;
      } else if (ob.remoteP()) {
         cache[0] = "remote";
         cache[1] = ob;
         return cache;
      } else if (ob.indirectP()) {
         Object v = table.get(new Integer(ob.nums[0]));
         if (v == null) {
            cache[0] = "err";
            cache[1] = "Unregistered object 2";
            return cache;
         } else {
            Registry r = (Registry)v;
            if (r.ref == null) {
               cache[0] = "err";
               cache[1] = "Discarded object";
               return cache;
            } else {
               cache[0] = "indirect";
               cache[1] = r.ref;
               return cache;
            }
         }
      } else if (ob.rankP(0)) {
         cache[0] = "immediate";
         switch(ob.getTypeBits(5, 8)) {
         case 1:
            cache[1] = new Byte((byte)ob.nums[0]);
            break;
         case 2:
            cache[1] = new Short((short)ob.nums[0]);
            break;
         case 3:
            cache[1] = new Integer(ob.nums[0]);
            break;
         case 4:
            cache[1] = new Long(ob.longValue());
            break;
         case 5:
            cache[1] = new Character(ob.strings[0].charAt(0));
            break;
         case 6:
            cache[1] = ob.strings[0];
            break;
         case 7:
            cache[1] = new Float((float)ob.reals[0]);
            break;
         case 8:
            cache[1] = new Double(ob.reals[0]);
            break;
         case 9:
            if (ob.nums[0] == 0) {
               cache[1] = Boolean.FALSE;
            } else {
               cache[1] = Boolean.TRUE;
            }
            break;
         case 10:
            cache[0] = "remote";
            cache[1] = ob;
            return cache;
         case 31:
            break;
         default:
            cache[1] = "Unknown object base type";
            cache[0] = "err";
         }

         return cache;
      } else if (!ob.rankP(1)) {
         cache[0] = "err";
         cache[1] = "Unknown object type";
         return cache;
      } else {
         cache[0] = "immediate";
         int i;
         switch(ob.getTypeBits(5, 8)) {
         case 1:
            if (8192 == ('' & ob.type)) {
               cache[1] = ob.getExdata();
            } else {
               byte[] ta = new byte[ob.nums.length];

               for(i = 0; i < ta.length; ++i) {
                  ta[i] = (byte)ob.nums[i];
               }

               cache[1] = ta;
            }
            break;
         case 2:
            if (16384 == ('' & ob.type)) {
               cache[1] = ob.getExdata();
            } else {
               short[] ta = new short[ob.nums.length];

               for(i = 0; i < ta.length; ++i) {
                  ta[i] = (short)ob.nums[i];
               }

               cache[1] = ta;
            }
            break;
         case 3:
            cache[1] = ob.nums.clone();
            break;
         case 4:
         case 5:
         default:
            cache[1] = "Unknown object base type";
            cache[0] = "err";
            break;
         case 6:
            cache[1] = ob.strings.clone();
            break;
         case 7:
            if (24576 == ('' & ob.type)) {
               cache[1] = ob.getExdata();
            } else {
               float[] ta = new float[ob.reals.length];

               for(i = 0; i < ta.length; ++i) {
                  ta[i] = (float)ob.reals[i];
               }

               cache[1] = ta;
            }
            break;
         case 8:
            cache[1] = ob.reals.clone();
         }

         return cache;
      }
   }

   public static Class<?> extractClassRef(TranStruct ob, Object jv) throws ClassNotFoundException, ClassCastException {
      if (ob.stringP()) {
         String s = (String)jv;
         if (s.equals("bool")) {
            return Boolean.TYPE;
         } else if (s.equals("boolean")) {
            return Boolean.TYPE;
         } else if (s.equals("byte")) {
            return Byte.TYPE;
         } else if (s.equals("char")) {
            return Character.TYPE;
         } else if (s.equals("double")) {
            return Double.TYPE;
         } else if (s.equals("float")) {
            return Float.TYPE;
         } else if (s.equals("int")) {
            return Integer.TYPE;
         } else if (s.equals("long")) {
            return Long.TYPE;
         } else if (s.equals("short")) {
            return Short.TYPE;
         } else {
            return s.equals("void") ? Void.TYPE : Class.forName(s);
         }
      } else {
         return (Class)jv;
      }
   }

   public static void discard(int[] nums) {
      for(int i = 0; i < nums.length; ++i) {
         discard(nums[i]);
      }

   }

   static String[] addSig(Class<?>[] args, String s0, String s1, String s2) {
      int l = 2;
      if (s2.length() > 0) {
         ++l;
      }

      String[] ss = new String[l + args.length];
      ss[0] = s0;
      ss[1] = s1;
      if (l == 3) {
         ss[2] = s2;
      }

      for(int i = 0; i < args.length; ++i) {
         ss[l + i] = args[i].getName();
      }

      return ss;
   }

   static boolean liveP(TranStruct str) {
      synchronized(str) {
         if (str.immediateP()) {
            return true;
         } else if (str.localP() && connectIndex != str.nums[1]) {
            str.setRemote(0, 3);
            return false;
         } else {
            return str.getTypeBits(1, 2) == 0;
         }
      }
   }

   public static boolean errorP(TranStruct str) {
      return str.indirectP() && liveP(str) && str.remoteP() && str.rankP(0) && str.aggrP(61);
   }

   public static boolean pointerP(TranStruct str) {
      return str.indirectP() && liveP(str);
   }

   static void discardInLisp(TranStruct str) {
      discardInLisp(new Object[]{str});
   }

   static long discardInLisp(Object[] stra) {
      int[] anum = JLWrapper.collectDeadNums(stra);
      if (anum != null) {
         JLCommon.dsprint("JLSocketClient.discardInLisp calling Lisp " + anum.length);
         discardInLispConn(anum);
      }

      return (long)JLWrapper.toDiscard.size();
   }

   public static TranStruct[] invokeInLisp(int style, TranStruct op, TranStruct[] args) {
      int timeout = 2 * LispCall.replyTimeout;
      TranStruct[] r = null;
      JLCommonSocket.dsprint("invokeInLisp op " + TranStruct.show(op));
      JLCommonSocket.dsprint("invokeInLisp args " + TranStruct.show(args));
      Exception err = null;

      try {
         r = invokeInLisp(style, op, args, timeout);
      } catch (Exception var7) {
         JLCommonSocket.dsprint("invokeInLisp err" + TranStruct.show(var7));
         err = var7;
      }

      JLCommonSocket.dsprint("invokeInLisp = " + TranStruct.show(r));
      if (err != null) {
         r = new TranStruct[]{TranStruct.newTrS(err), TranStruct.newTrS(r)};
      }

      return r;
   }

   private static TranStruct[] invokeInLisp(int style, TranStruct op, TranStruct[] args, int timeout) throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      TranStruct[] result = invokeInLispConn(style, op, args, timeout);

      for(int i = 0; i < args.length; ++i) {
         if (args[i].lastUseP()) {
            args[i].setRemote(0, 3);
         }
      }

      JLCommonSocket.dsprint("invokeInLispConn " + TranStruct.show(result));
      return result;
   }

   public static TranStruct[] invokeInLispWithExceptions(int style, TranStruct op, TranStruct[] args, int timeout) throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      TranStruct[] result = invokeInLisp(style, op, args, timeout);
      if (result.length == 0) {
         if (style == -1) {
            return result;
         } else if (style == 0) {
            return result;
         } else {
            throw new JLinkerInvokeException("Nothing returned from Lisp");
         }
      } else if (result[0].integerP() && result[0].intValue() == result.length - 1) {
         return result;
      } else if (1 == result.length && errorP(result[0])) {
         String d = result[0].stringValue(1);
         if (d.contains("#<jlinker-port-error ")) {
            throw new JLinkerPortException("jlinker-port-error");
         } else {
            throw new JLinkerLispException(d, result[0]);
         }
      } else if (1 == result.length && result[0].stringP() && result[0].stringValue().equalsIgnoreCase("Throw in Lisp")) {
         throw new JLinkerLispThrow();
      } else {
         throw new JLinkerInvokeException("Unexpected result: " + TranStruct.show(result));
      }
   }

   private static boolean discardInLispConn(int[] nums) {
      int[] numseq = new int[2 + nums.length];
      numseq[0] = -1;
      numseq[1] = 3;

      for(int i = 0; i < nums.length; ++i) {
         numseq[2 + i] = nums[i];
      }

      TranStruct d = new TranStruct("Self", 7680, numseq, new String[0], new double[0]);
      if (Transport.exData == 0) {
         d.type |= 57344;
      }

      TranStruct[] s = new TranStruct[]{d};
      Transport port = null;
      Exception err = null;

      try {
         port = JLCommonSocket.getPortToLisp(1000L, (Object[])null);
         port.invoke(s, true);
      } catch (Exception var11) {
         err = var11;
      } finally {
         if (port != null) {
            JLCommonSocket.releasePortToLisp(port, err);
         }

      }

      return port != null;
   }

   private static TranStruct[] invokeInLispConn(int style, TranStruct op, TranStruct[] args, int timeout) throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      TranStruct[] s = new TranStruct[2 + args.length];
      TranStruct d = new TranStruct("Self", 7680, new int[]{style, 4}, new String[0], new double[0]);
      if (Transport.exData == 0) {
         d.type |= 57344;
      }

      s[0] = d;
      s[1] = op;

      for(int i = 0; i < args.length; ++i) {
         s[2 + i] = args[i];
      }

      Object v = null;
      Transport port = null;
      Exception err = null;
      Object[] eRep = new Object[1];

      try {
         port = JLCommonSocket.getPortToLisp((long)timeout, eRep);
         if (port == null && eRep[0] == null) {
            throw new JLinkerPortException(timeout);
         }

         if (port == null) {
            JLCommonSocket.disconnect();
            throw new IllegalStateException("" + eRep[0]);
         }

         TranStruct[] var13;
         switch(style) {
         case -1:
            port.invoke(s, true);
            var13 = new TranStruct[0];
            return var13;
         case 0:
            port.invoke(s, false);
            var13 = new TranStruct[0];
            return var13;
         default:
            v = port.invoke(s, false);
         }
      } catch (Exception var16) {
         err = var16;
      } finally {
         if (port != null) {
            JLCommonSocket.releasePortToLisp(port, err);
         }

      }

      if (err == null) {
         if (TranStruct.getArrayLength(v) >= 0) {
            return (TranStruct[])v;
         } else if (TranStruct.getObjectArrayLength(v) >= 0) {
            return TranStruct.toArray(v);
         } else if (v instanceof String) {
            throw new JLinkerInvokeException("Socket error: " + v);
         } else if (v instanceof Object[]) {
            throw new JLinkerInvokeException("Socket error: " + TranStruct.showStrings((Object[])v, 40));
         } else {
            throw new JLinkerInvokeException("Error?", v);
         }
      } else if (err instanceof JLinkerLispThrow) {
         throw (JLinkerLispThrow)err;
      } else if (err instanceof JLinkerInvokeException) {
         throw (JLinkerInvokeException)err;
      } else if (err instanceof JLinkerLispException) {
         throw (JLinkerLispException)err;
      } else if (err instanceof JLinkerPortException) {
         throw (JLinkerPortException)err;
      } else if (err instanceof RuntimeException) {
         throw (RuntimeException)err;
      } else {
         throw new JLinkerInvokeException("Unexpected error", err);
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 201 ms
	
	Decompiled with FernFlower.
*/