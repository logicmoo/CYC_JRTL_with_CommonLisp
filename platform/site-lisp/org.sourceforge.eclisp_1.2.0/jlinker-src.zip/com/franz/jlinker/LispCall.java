package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;
import com.franz.jlinker.LispCall.Holder;
import com.franz.jlinker.LispCall.JlinkerState;

public class LispCall {
   public static final int STYLE_ONEWAY = -1;
   public static final int STYLE_IGNORE = 0;
   public static final int STYLE_REF = 1;
   public static final int STYLE_COPY = 2;
   public static final int STYLE_ASYNC_BR = 3;
   static final int STYLE_ASYNC = 3;
   public static final int STYLE_ASYNC_GO = 4;
   static final int STYLE_TOP = 4;
   public static final int STATE_NEW = 0;
   public static final int STATE_COLLECTING = 1;
   public static final int STATE_READY = 2;
   public static final int STATE_DONE = 3;
   public static final int STATE_WAITING = 4;
   public static final int STATE_WAITDONE = 5;
   public static final int STATE_CLOSED = 6;
   public static final int RES_NULL;
   public static final int RES_BOOLEAN;
   public static final int RES_INTEGER;
   public static final int RES_LONG;
   public static final int RES_REAL;
   public static final int RES_STRING;
   public static final int RES_SYMBOL;
   public static final int RES_LISP_POINTER;
   public static final int RES_ERROR;
   public static final int RES_INT_ARRAY;
   public static final int RES_DOUBLE_ARRAY;
   public static final int RES_STRING_ARRAY;
   public static final int RES_JAVA_POINTER;
   public static final int RES_WRONG_STATE;
   public static final int RES_MISSING;
   public static final int RES_WRAPPER;
   public static final int RES_UNKNOWN;
   static int[] defaultConnectionPool;
   int state;
   boolean retain = true;
   int callStyle = 2;
   Object lispOp = null;
   int lispOpKind = 0;
   Object args = null;
   Object res = null;
   Holder chain = null;
   int count = 0;
   Object waitref = null;
   int waitres = -99;
   LispCallImplementation implementation;
   static LispCallImplementation prototype;
   public Object queryError = null;
   public static int defaultPollInterval;
   public static int defaultPollCount;
   public static Object connectError;
   public static int readTimeout;
   public static int defaultPortTimeout;
   int portTimeout;
   public static int replyTimeout;
   public static int requestTimeout;
   public static int verifiedConnectTimeout;
   public static int discardBatchSize;

   static {
      RES_NULL = TypeCode.NULL.getTypeNum();
      RES_BOOLEAN = TypeCode.BOOL.getTypeNum();
      RES_INTEGER = TypeCode.INT.getTypeNum();
      RES_LONG = TypeCode.LONG.getTypeNum();
      RES_REAL = TypeCode.DOUBLE.getTypeNum();
      RES_STRING = TypeCode.STRING.getTypeNum();
      RES_SYMBOL = TypeCode.SYMBOL.getTypeNum();
      RES_LISP_POINTER = TypeCode.LISP_POINTER.getTypeNum();
      RES_ERROR = TypeCode.ERROR.getTypeNum();
      RES_INT_ARRAY = TypeCode.INT_ARRAY.getTypeNum();
      RES_DOUBLE_ARRAY = TypeCode.DOUBLE_ARRAY.getTypeNum();
      RES_STRING_ARRAY = TypeCode.STRING_ARRAY.getTypeNum();
      RES_JAVA_POINTER = TypeCode.JAVA_POINTER.getTypeNum();
      RES_WRONG_STATE = TypeCode.WRONG_STATE.getTypeNum();
      RES_MISSING = TypeCode.MISSING.getTypeNum();
      RES_WRAPPER = TypeCode.WRAPPER.getTypeNum();
      RES_UNKNOWN = TypeCode.UNKNOWN.getTypeNum();
      defaultConnectionPool = new int[]{-1, -1, -1, -1, -1, -1};
      prototype = new LispCallSocket();
      defaultPollInterval = 1000;
      defaultPollCount = 300;
      connectError = null;
      readTimeout = 30000;
      defaultPortTimeout = -1;
      replyTimeout = 300000;
      requestTimeout = 0;
      verifiedConnectTimeout = 15000;
      discardBatchSize = 100;
   }

   public static boolean isJlinkerReady() {
      return JLCommonSocket.isReady();
   }

   public static boolean isJlinkerState(JlinkerState... targets) {
      if (targets != null && targets.length != 0) {
         JlinkerState[] var4 = targets;
         int var3 = targets.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            JlinkerState t = var4[var2];
            if (prototype.isJlinkerState(t)) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   public static boolean isJlinkerState(long timeout, JlinkerState... targets) {
      return targets != null && targets.length != 0 ? prototype.isJlinkerState(timeout, targets) : true;
   }

   public static int[] getDefaultConnectionPool() {
      int[] c = new int[6];

      for(int i = 0; i < 6; ++i) {
         c[i] = defaultConnectionPool[i];
      }

      return c;
   }

   public static synchronized void setDefaultConnectionPool(int lispMin, int lispMax, int lispIdle, int javaMin, int javaMax, int javaIdle) {
      if (!JLCommonSocket.isIdle()) {
         throw new IllegalStateException("Can only modify connection pool parameters before initializing Jlinker.");
      } else {
         int[] c = new int[]{lispMin, lispMax, lispIdle, javaMin, javaMax, javaIdle};

         for(int i = 0; i < 6; ++i) {
            if (-1 > c[i]) {
               c[i] = defaultConnectionPool[i];
            }
         }

         if (c[0] > c[1] || c[3] > c[4]) {
            throw new IllegalArgumentException("Min cannot be greater than max.");
         }
      }
   }

   public static synchronized Object queryConnectionPool() {
      JLConnectionPoolManager pm = JLConnectionPoolManager.poolManager;
      int[] c;
      if (pm != null) {
         c = defaultConnectionPool;
         return new int[]{c[0], pm.portsToJavaCount(), c[1], c[2], c[3], pm.portsToLispCount(), c[4], c[5]};
      } else {
         c = new int[6];

         for(int i = 0; i < 6; ++i) {
            c[i] = defaultConnectionPool[i];
         }

         return c[0] != 0 && c[3] != 0 ? c : null;
      }
   }

   int newHolder(Object x) {
      this.chain = new Holder(this, x, this.chain);
      ++this.count;
      return this.count;
   }

   public LispCall() {
      this.portTimeout = defaultPortTimeout;
      this.implementation = prototype.builder(this, "");
      this.state = 0;
   }

   public LispCall(boolean r) {
      this.portTimeout = defaultPortTimeout;
      this.implementation = prototype.builder(this, "");
      this.retain = r;
      this.state = 0;
   }

   public LispCall(int s) {
      this.portTimeout = defaultPortTimeout;
      this.implementation = prototype.builder(this, "");
      this.setStyle(s);
      this.state = 0;
   }

   public LispCall(String op) {
      this.portTimeout = defaultPortTimeout;
      this.implementation = prototype.builder(this, op);
      this.state = 1;
   }

   public int getState() {
      return this.state;
   }

   public Object getOp() {
      return this.lispOp;
   }

   public int getStyle() {
      return this.callStyle;
   }

   public synchronized void setOp(String op) {
      this.lispOpKind = 0;
      this.implementation.setOp(op);
   }

   public synchronized void setOp(Object op) {
      this.castObject(op);
      this.lispOpKind = 1;
      this.implementation.setOp(op);
   }

   void castObject(Object op) {
      if (!this.implementation.getOpClass().isInstance(op)) {
         throw new ClassCastException("Cannot cast object of class " + op.getClass().getName() + " to " + this.implementation.getOpClass().getName());
      }
   }

   public synchronized void setStyle(int s) {
      if (-1 <= s && s <= 4) {
         this.callStyle = s;
      } else {
         throw new IllegalArgumentException("Unknown call style " + s + ".");
      }
   }

   public synchronized boolean getRetain() {
      return this.retain;
   }

   public synchronized void setRetain(boolean r) {
      this.retain = r;
   }

   public synchronized int addArg(byte x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(short x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(int x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(long x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(boolean x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(byte[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(short[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(int[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(String x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(String[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(float x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(double x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(float[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(double[] x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addArg(Object x) {
      return this.implementation.addArg(x);
   }

   public synchronized int addSymbol(String x) {
      return this.implementation.addSymbol(x);
   }

   public synchronized int addSymbol(String x, String pk) {
      return this.implementation.addSymbol(x, pk);
   }

   public synchronized int addSymbol(String x, String pk, int action) {
      switch(action) {
      case 0:
      case 1:
      case 2:
      case 3:
         return this.implementation.addSymbol(x, pk, action);
      default:
         throw new IllegalArgumentException("addSymbol action must be 0, 1, 2, 0r 3. ?:" + action);
      }
   }

   public synchronized int call() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      switch(this.implementation.mayCall()) {
      case -1:
         throw new IllegalStateException("May not call Lisp in this thread.");
      case 0:
         throw new IllegalStateException("Lisp is not ready for a call.");
      default:
         return this.implementation.call();
      }
   }

   public synchronized int callOneWay() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = -1;
      return this.call();
   }

   public synchronized int callIgnore() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = 0;
      return this.call();
   }

   public synchronized int callRef() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = 1;
      return this.call();
   }

   public synchronized int callCopy() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = 2;
      return this.call();
   }

   public synchronized int callAsyncBr() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = 3;
      return this.call();
   }

   public synchronized int callAsyncGo() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      this.callStyle = 4;
      return this.call();
   }

   public synchronized Object getValue() {
      return this.getValue(0);
   }

   public synchronized Object getValue(int i) {
      if (this.state != 3) {
         this.throwWrongState("getValue", "");
      }

      if (this.res == null) {
         this.throwWrongState("getValue", " when result from Lisp is null");
      }

      return this.implementation.getValue(i);
   }

   public static String nameOfType(int type) {
      TypeCode tc = JLWrapper.encodeType(type);
      return tc.nameOfType();
   }

   public static Object identity(Object arg) {
      return arg;
   }

   
   public synchronized int typeOf() {
      return this.typeOf(0);
   }

   
   public synchronized int typeOf(int i) {
      if (this.state != 3) {
         return RES_WRONG_STATE;
      } else {
         return this.res == null ? RES_MISSING : this.implementation.typeOf(i);
      }
   }

   public synchronized TypeCode getTypeCode() {
      return this.getTypeCode(0);
   }

   public synchronized TypeCode getTypeCode(int i) {
      return this.implementation.getTypeCode(i);
   }

   public synchronized int intValue() {
      return this.intValue(0);
   }

   public synchronized int intValue(int i) {
      return this.implementation.intValue(i);
   }

   public synchronized long longValue() {
      return this.longValue(0);
   }

   public synchronized long longValue(int i) {
      return this.implementation.longValue(i);
   }

   public synchronized double doubleValue() {
      return this.doubleValue(0);
   }

   public synchronized double doubleValue(int i) {
      return this.implementation.doubleValue(i);
   }

   public synchronized boolean booleanValue() {
      return this.booleanValue(0);
   }

   public synchronized boolean booleanValue(int i) {
      return this.implementation.booleanValue(i);
   }

   public synchronized String stringValue() {
      return this.stringValue(0);
   }

   public synchronized String stringValue(int i) {
      return this.implementation.stringValue(i);
   }

   public synchronized int[] intArrayValue() {
      return this.intArrayValue(0);
   }

   public synchronized int[] intArrayValue(int i) {
      return this.implementation.intArrayValue(i);
   }

   public synchronized String[] stringArrayValue() {
      return this.stringArrayValue(0);
   }

   public synchronized String[] stringArrayValue(int i) {
      return this.implementation.stringArrayValue(i);
   }

   public synchronized double[] doubleArrayValue() {
      return this.doubleArrayValue(0);
   }

   public synchronized double[] doubleArrayValue(int i) {
      return this.implementation.doubleArrayValue(i);
   }

   public synchronized Object objectValue() {
      return this.objectValue(0);
   }

   public synchronized Object objectValue(int i) {
      return this.implementation.objectValue(i);
   }

   public synchronized String symbolName() {
      return this.symbolName(0);
   }

   public synchronized String symbolName(int i) {
      return this.implementation.symbolName(i);
   }

   public synchronized String symbolPackage() {
      return this.symbolPackage(0);
   }

   public synchronized String symbolPackage(int i) {
      return this.implementation.symbolPackage(i);
   }

   public synchronized String lispType() {
      return this.lispType(0);
   }

   public synchronized String lispType(int i) {
      return this.implementation.lispType(i);
   }

   public synchronized int query() {
      int r = -99;

      try {
         r = this.query(false, false);
      } catch (JLinkerException var3) {
         ;
      }

      return r;
   }

   public synchronized int query(boolean doquery, boolean dofetch) throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException {
      this.queryError = null;
      return this.implementation.query(doquery, dofetch);
   }

   public synchronized String queryAsyncName() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException {
      this.queryError = null;
      return this.implementation.queryAsyncName();
   }

   public synchronized void close() {
      if (this.waitref instanceof JLWrapper) {
         prototype.discardInLisp(new Object[]{(JLWrapper)this.waitref});
      }

      this.waitref = null;
      this.waitres = -99;
      this.res = null;
      this.args = null;
      this.count = 0;
      this.chain = null;
      if (this.state != 0) {
         this.state = 6;
      }

      this.implementation.close();
   }

   public synchronized boolean reset() {
      if (this.waitref instanceof JLWrapper) {
         prototype.discardInLisp(new Object[]{(JLWrapper)this.waitref});
      }

      this.waitref = null;
      this.waitres = -99;
      this.res = null;
      if (this.state == 1) {
         this.implementation.assemble("reset");
      }

      this.count = 0;
      this.chain = null;
      switch(this.state) {
      case 0:
      case 1:
      case 2:
         break;
      case 3:
      case 4:
      case 5:
         if (this.args == null) {
            this.state = 1;
         } else {
            this.state = 2;
         }
         break;
      case 6:
         if (this.lispOp == null) {
            this.state = 0;
         } else {
            this.state = 1;
         }
         break;
      default:
         this.throwWrongState("reset", "");
      }

      this.implementation.reset();
      return this.state == 2;
   }

   public synchronized void setArg(int i, boolean arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, int arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, long arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, double arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, String arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, Object arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, int[] arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, double[] arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setArg(int i, String[] arg) {
      this.implementation.setArg(i, arg);
   }

   public synchronized void setSymbol(int i, String name) {
      this.implementation.setSymbol(i, name);
   }

   public synchronized void setSymbol(int i, String name, String pkg) {
      this.implementation.setSymbol(i, name, pkg);
   }

   public synchronized void setSymbol(int i, String name, String pkg, int mode) {
      switch(mode) {
      case 0:
      case 1:
      case 2:
      case 3:
         this.implementation.setSymbol(i, name, pkg, mode);
         return;
      default:
         throw new IllegalArgumentException("addSymbol action must be 0, 1, 2, 0r 3. ?:" + mode);
      }
   }

   void throwWrongState(String where, String more) {
      String sn;
      switch(this.state) {
      case 0:
         sn = "STATE_NEW";
         break;
      case 1:
         sn = "STATE_COLLECTING";
         break;
      case 2:
         sn = "STATE_READY";
         break;
      case 3:
         sn = "STATE_DONE";
         break;
      case 4:
         sn = "STATE_WAITING";
         break;
      case 5:
         sn = "STATE_WAITDONE";
         break;
      case 6:
         sn = "STATE_CLOSED";
         break;
      default:
         sn = "STATE_???";
      }

      throw new IllegalStateException(where + " cannot be called in " + sn + " state" + more + ".");
   }

   public int mayCall() {
      return this.implementation.mayCall();
   }

   public static int dispatchEvent(String ev, Object target, String[] s, int[] l, int timeout) {
      return JLCommon.lispJavaConnection.sendRegisteredEvent(ev, target, s, l, timeout);
   }

   public static int dispatchEvent(String ev, Object target, String[] s, int[] l) {
      int timeout = defaultPortTimeout;
      if (defaultPortTimeout < 0) {
         timeout = replyTimeout;
      }

      return JLCommon.lispJavaConnection.sendRegisteredEvent(ev, target, s, l, timeout);
   }

   public static boolean connect(String host, int port, int pollInterval, int pollCount) {
      if (pollInterval < 0) {
         pollInterval = defaultPollInterval;
      }

      if (pollCount < 0) {
         pollCount = defaultPollCount;
      }

      return prototype instanceof LispCallSocket ? JLCommonSocket.connect(host, port, pollInterval, pollCount) : true;
   }

   public static boolean connect(String com, int pollInterval, int pollCount) {
      if (pollInterval < 0) {
         pollInterval = defaultPollInterval;
      }

      if (pollCount < 0) {
         pollCount = defaultPollCount;
      }

      return prototype instanceof LispCallSocket ? JLCommonSocket.connect(com, pollInterval, pollCount) : true;
   }

   public static boolean advertise(int port, int timeoutSeconds) {
      return prototype instanceof LispCallSocket ? JLCommonSocket.advertise(port, timeoutSeconds) : true;
   }

   public static boolean advertise(String l2j, String host, int port, int timeoutSeconds) {
      return prototype instanceof LispCallSocket ? JLCommonSocket.advertise(l2j, host, port, timeoutSeconds) : true;
   }

   public static void disconnect() {
      if (prototype instanceof LispCallSocket) {
         JLCommonSocket.disconnect();
      }

   }

   public static long discardInLisp(Object... x) {
      return prototype.discardInLisp(x);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 142 ms
	 @deprecated 
	@deprecated 
	Decompiled with FernFlower.
*/