package com.franz.jlinker;

import java.util.Hashtable;

public abstract class JLCommon extends JavaLinkCommon {
   public static JLCommon lispJavaConnection = null;
   public static int lispMinVersion = -1;
   public static int lispVersion = -1;
   public static int lispMinJava = -1;
   public static boolean sdebug = false;
   public static long sdbegin = 0L;
   public static int maxSleepStep = 0;
   public static String VMId = "";
   static Hashtable<Object, Integer> j_to_handle = new Hashtable(1000);
   static int new_handle = 1;

   abstract int sendRegisteredEvent(String var1, Object var2, String[] var3, int[] var4, int var5);

   public static int minJavaVersion() {
      return 6005000;
   }

   public static int minLispVersion() {
      return 6005000;
   }

   static boolean isLispVersion(int level) {
      if (level < 1000) {
         level *= 1000;
      }

      if (level < 1000000) {
         level *= 1000;
      }

      return level <= lispVersion;
   }

   abstract Object[] lispValuesOp(Object var1, String var2, int var3, int var4, boolean var5);

   public Object[] newGateOp() {
      return new Object[]{"", "closed"};
   }

   public String testGateOp(Object[] gate) {
      boolean w = true;

      while(w) {
         try {
            synchronized(gate) {
               if (((String)gate[1]).equals("open")) {
                  w = false;
               } else {
                  gate.wait();
               }
            }
         } catch (InterruptedException var5) {
            ;
         }
      }

      return (String)gate[0];
   }

   public static void sleep(long millis, String from) {
      dsprint(from + " sleeping " + millis);

      try {
         while(millis > 0L) {
            long s = millis;
            if (maxSleepStep > 0 && millis > (long)maxSleepStep) {
               s = (long)maxSleepStep;
            }

            Thread.sleep(s);
            millis -= s;
         }
      } catch (InterruptedException var5) {
         ;
      }

      dsprint(from + " done.");
   }

   public static void dsprint(String s) {
      if (sdebug) {
         if (sdbegin == 0L) {
            sdbegin = System.currentTimeMillis();
         }

         long dt = System.currentTimeMillis() - sdbegin;
         String name = Thread.currentThread().getName();
         System.out.println(name + ("".equals(VMId) ? "" : "-" + VMId) + "(" + dt + ") " + s);
      }

   }

   public static int registerSOb(Object x) {
      Object v = j_to_handle.get(x);
      if (v == null) {
         ++new_handle;
         j_to_handle.put(x, new Integer(new_handle));
         return new_handle;
      } else {
         return (Integer)v;
      }
   }

   public static int getSObHandle(Object javaob) {
      Object v = j_to_handle.get(javaob);
      return v == null ? 0 : (Integer)v;
   }

   abstract void shutdown();
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 51 ms
	
	Decompiled with FernFlower.
*/