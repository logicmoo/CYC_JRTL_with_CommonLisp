package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;
import com.franz.jlinker.LispCall.JlinkerState;

abstract class LispCallImplementation {
   abstract Class<?> getOpClass();

   abstract void assemble(String var1);

   abstract void setOp(String var1);

   abstract void setOp(Object var1);

   abstract int addArg(byte var1);

   abstract void setArg(int var1, byte var2);

   abstract int addArg(short var1);

   abstract void setArg(int var1, short var2);

   abstract int addArg(int var1);

   abstract void setArg(int var1, int var2);

   abstract int addArg(long var1);

   abstract void setArg(int var1, long var2);

   abstract int addArg(boolean var1);

   abstract void setArg(int var1, boolean var2);

   abstract int addArg(byte[] var1);

   abstract void setArg(int var1, byte[] var2);

   abstract int addArg(short[] var1);

   abstract void setArg(int var1, short[] var2);

   abstract int addArg(int[] var1);

   abstract void setArg(int var1, int[] var2);

   abstract int addArg(String var1);

   abstract void setArg(int var1, String var2);

   abstract int addArg(String[] var1);

   abstract void setArg(int var1, String[] var2);

   abstract int addArg(float var1);

   abstract void setArg(int var1, float var2);

   abstract int addArg(double var1);

   abstract void setArg(int var1, double var2);

   abstract int addArg(float[] var1);

   abstract void setArg(int var1, float[] var2);

   abstract int addArg(double[] var1);

   abstract void setArg(int var1, double[] var2);

   abstract int addArg(Object var1);

   abstract void setArg(int var1, Object var2);

   abstract int addSymbol(String var1);

   abstract void setSymbol(int var1, String var2);

   abstract int addSymbol(String var1, String var2);

   abstract void setSymbol(int var1, String var2, String var3);

   abstract int addSymbol(String var1, String var2, int var3);

   abstract void setSymbol(int var1, String var2, String var3, int var4);

   abstract int call() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException;

   abstract Object getValue(int var1);

   abstract long discardInLisp(Object... var1);

   
   abstract int typeOf(JLWrapper var1);

   abstract int typeOf(int var1);

   abstract TypeCode getTypeCode(int var1);

   abstract int intValue(int var1);

   abstract long longValue(int var1);

   abstract double doubleValue(int var1);

   abstract boolean booleanValue(int var1);

   abstract String stringValue(int var1);

   abstract int[] intArrayValue(int var1);

   abstract String[] stringArrayValue(int var1);

   abstract double[] doubleArrayValue(int var1);

   abstract Object objectValue(int var1);

   abstract String symbolName(int var1);

   abstract String symbolPackage(int var1);

   abstract String lispType(int var1);

   abstract int query(boolean var1, boolean var2) throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException;

   abstract String queryAsyncName() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException;

   abstract LispCallImplementation builder(LispCall var1, String var2);

   abstract void close();

   abstract void reset();

   abstract int mayCall();

   abstract boolean isJlinkerState(JlinkerState var1);

   abstract boolean isJlinkerState(long var1, JlinkerState... var3);
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 4 ms
	 @deprecated 
	Decompiled with FernFlower.
*/