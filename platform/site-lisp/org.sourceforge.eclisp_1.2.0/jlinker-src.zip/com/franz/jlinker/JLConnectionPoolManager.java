package com.franz.jlinker;

import com.franz.jlinker.JLConnectionPoolManager.poolManager;
import com.franz.jlinker.JLConnectionPoolManager.poolServer;
import com.franz.jlinker.Transport.Listener;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Stack;

public class JLConnectionPoolManager extends JLSocketCodes {
   static JLConnectionPoolManager poolManager = null;
   private Stack<Transport> idlePortsToLisp = new Stack();
   private int portsToLisp = 0;
   private Stack<Transport> busyPortsToLisp = new Stack();
   private Stack<poolServer> poolServers = new Stack();
   int initialPortCount = 0;
   boolean initialPortInStack = false;
   boolean ready = false;
   boolean dropOnePort = false;
   int lispMin;
   int lispMax;
   int lispIdle;
   int javaMin;
   int javaMax;
   int javaIdle;
   int pscounter = 0;
   private JLCommonSocket sockConn = null;
   LinkedList<Object> workQueue = new LinkedList();

   int portsToJavaCount() {
      return this.poolServers.size();
   }

   int portsToLispCount() {
      return this.portsToLisp;
   }

   Transport getPortToLisp(long timeout, Transport initialPort) {
      return this.getPortToLisp(timeout, initialPort, (Object[])null);
   }

   Transport getPortToLisp(long timeout, Transport initialPort, Object[] eRep) {
      boolean empty = false;
      boolean interrupted = false;
      if (!this.ready) {
         Stack var13 = this.idlePortsToLisp;
         synchronized(this.idlePortsToLisp) {
            ++this.initialPortCount;
            return initialPort;
         }
      } else {
         while(true) {
            Transport idlePort = null;
            interrupted = false;
            Stack var8 = this.idlePortsToLisp;
            synchronized(this.idlePortsToLisp) {
               if (this.idlePortsToLisp.empty()) {
                  if (timeout == 0L) {
                     return JLCommonSocket.setERep(eRep, "Port timeout.");
                  }

                  try {
                     if (timeout < 0L) {
                        this.idlePortsToLisp.wait();
                     } else {
                        this.idlePortsToLisp.wait(timeout);
                     }
                  } catch (InterruptedException var10) {
                     interrupted = true;
                  }
               }

               if (!this.idlePortsToLisp.empty()) {
                  idlePort = (Transport)this.idlePortsToLisp.pop();
               }

               empty = this.idlePortsToLisp.empty();
            }

            if (idlePort != null) {
               if (empty) {
                  idlePort.request("connectionPool", 320, new int[0], new String[0], new double[0], true);
                  this.enqueue(111);
               }

               this.busyPortsToLisp.push(idlePort);
               return idlePort;
            }

            if (timeout > 0L && !interrupted) {
               timeout = 0L;
            }
         }
      }
   }

   boolean releasePortToLisp(Transport port, Object err) {
      if (!this.ready && err instanceof IOException || this.ready && this.portsToLisp == 0) {
         JLCommonSocket.disconnect();
         return false;
      } else {
         Stack var3;
         if (this.ready) {
            if (this.stackInitialPort(port)) {
               return true;
            }

            this.busyPortsToLisp.remove(port);
            var3 = this.idlePortsToLisp;
            synchronized(this.idlePortsToLisp) {
               if (!this.dropOnePort && !(err instanceof IOException)) {
                  this.idlePortsToLisp.push(port);
                  this.idlePortsToLisp.notify();
                  return true;
               }

               --this.portsToLisp;
               if (this.dropOnePort && err == null) {
                  err = "idle timeout";
               }

               port.shutdown(err);
               this.dropOnePort = false;
            }
         }

         var3 = this.idlePortsToLisp;
         synchronized(this.idlePortsToLisp) {
            --this.initialPortCount;
         }

         return this.stackInitialPort(port);
      }
   }

   void shutdown(Transport iport) {
      synchronized(this) {
         this.ready = false;
      }

      this.idlePortsToLisp.remove(iport);
      this.busyPortsToLisp.remove(iport);
      boolean idle = true;
      boolean busy = true;
      Transport port = null;

      while(idle || busy) {
         port = null;
         if (this.idlePortsToLisp.empty()) {
            idle = false;
         } else {
            port = (Transport)this.idlePortsToLisp.pop();
         }

         if (port == null && !idle) {
            if (this.busyPortsToLisp.empty()) {
               busy = false;
            } else {
               port = (Transport)this.busyPortsToLisp.pop();
            }
         }

         if (port != null) {
            port.shutdown("PoolManager");
         }
      }

      if (iport != null) {
         iport.shutdown("PoolManager");
      }

      while(!this.poolServers.empty()) {
         ((poolServer)this.poolServers.pop()).shutdown("PoolManager");
      }

      if (this.sockConn() != null) {
         JLSocketServer s = JLCommonSocket.lispToJavaThread;
         if (s != null) {
            s.shutdown("PoolManager");
         }
      }

   }

   public void initDone() {
      this.ready = true;
      this.stackInitialPort(JLCommonSocket.initialPortToLisp);
      JLCommonSocket.dsprint("InitDone -- initialPortInStack=" + this.initialPortInStack + " initialPortCount=" + this.initialPortCount + " idleStack=" + this.idlePortsToLisp.size() + " busyStack=" + this.busyPortsToLisp.size());
   }

   static void logInitPool(String m) {
      JLCommonSocket.dsprint("InitPool " + m);
   }

   static Object requestInitPool(int[] lspec) {
      if (poolManager != null) {
         return "Pool manager is already running.";
      } else {
         int[] jspec = LispCall.defaultConnectionPool;
         if (jspec == null) {
            return new int[6];
         } else {
            logInitPool(lspec + " " + lspec.length);
            logInitPool(jspec + " " + jspec.length);

            for(int i = 0; i < 6; ++i) {
               int l = lspec[i];
               int j = jspec[i];
               int v = 0;
               if (l == -1 && j == -1) {
                  switch(i) {
                  case 0:
                  case 1:
                  case 3:
                  case 4:
                     v = 1;
                     break;
                  case 2:
                  case 5:
                     v = 0;
                  }
               } else if (l == -1) {
                  v = j;
               } else if (j == -1) {
                  v = l;
               } else {
                  v = Math.min(l, j);
               }

               jspec[i] = v;
            }

            logInitPool(jspec + " " + jspec.length);
            if (jspec[0] > 0 && jspec[3] > 0) {
               poolManager = new JLConnectionPoolManager(jspec);
               poolManager.stackInitialPort(JLCommonSocket.initialPortToLisp);
            }

            return jspec;
         }
      }
   }

   boolean stackInitialPort(Transport port) {
      if (this.initialPortInStack) {
         return false;
      } else if (port != JLCommonSocket.initialPortToLisp) {
         return false;
      } else {
         Stack var2 = this.idlePortsToLisp;
         synchronized(this.idlePortsToLisp) {
            if (this.initialPortInStack) {
               return false;
            } else if (this.initialPortCount > 0) {
               return false;
            } else {
               this.idlePortsToLisp.push(port);
               this.idlePortsToLisp.notify();
               ++this.portsToLisp;
               this.initialPortInStack = true;
               return true;
            }
         }
      }
   }

   JLConnectionPoolManager(int[] spec) {
      this.lispMin = spec[0];
      this.lispMax = spec[1];
      this.lispIdle = spec[2];
      this.javaMin = spec[3];
      this.javaMax = spec[4];
      this.javaIdle = spec[5];
   }

   Object newPoolManager() {
      Object v = this.newPoolServer(new poolManager(this.sockConn(), this));
      JLCommon.dsprint("New Pool Manager: " + v);
      return v;
   }

   JLCommonSocket sockConn() {
      if (this.sockConn == null) {
         this.sockConn = (JLCommonSocket)JLCommon.lispJavaConnection;
      }

      return this.sockConn;
   }

   boolean lispAdvertises() {
      return this.sockConn().lispAdvertises;
   }

   boolean javaAdvertises() {
      return this.sockConn().javaAdvertises;
   }

   Object newPortToLisp() {
      Transport port = null;
      Listener listener = null;
      Object r;
      if (this.lispAdvertises()) {
         JLCommon.dsprint("newPortToLisp: Connecting to " + this.sockConn().linkHost + ":" + this.sockConn().linkPort);
         r = Transport.connectToHostPort(this.sockConn().linkHost, this.sockConn().linkPort, "client", false);
         if (!(r instanceof Transport)) {
            return "Connect failed";
         }

         port = (Transport)r;
      } else {
         if (!this.javaAdvertises()) {
            return "Unknown Java state.";
         }

         listener = JLCommonSocket.listener();
      }

      if (listener != null) {
         try {
            JLCommon.dsprint("newPortToLisp: Accepting connection to " + listener);
            port = Transport.acceptDataPort(listener, "client", false);
         } catch (Exception var6) {
            ;
         }
      }

      JLCommon.dsprint("newPortToLisp: Sending REQ_verify_from_Java on " + port);
      r = port.request("connectionPool", 103, (int[])null, new String[]{this.sockConn().java_key}, (double[])null, false);
      JLCommon.dsprint("newPortToLisp: Reply to REQ_verify_from_Java is " + r);
      if (!this.sockConn().lisp_key.equals(r)) {
         port.disconnect();
         if (r instanceof Object[]) {
            Object[] rr = (Object[])r;
            r = "{" + rr[0] + ", " + rr[1] + "}";
         }

         return "Cannot validate connection " + r;
      } else {
         Stack var4 = this.idlePortsToLisp;
         synchronized(this.idlePortsToLisp) {
            this.idlePortsToLisp.push(port);
            ++this.portsToLisp;
         }

         JLCommon.dsprint("newPortToLisp: current size is " + this.idlePortsToLisp.size());
         return 220;
      }
   }

   Object newPoolServer(poolServer s) {
      if (this.lispAdvertises()) {
         Object p = Transport.connectToHostPort(this.sockConn().linkHost, this.sockConn().linkPort, "server", false);
         if (!(p instanceof Transport)) {
            return "Connect failed";
         }

         s.serverPort = (Transport)p;
      } else {
         if (!this.javaAdvertises()) {
            return "Unknown Java state.";
         }

         Listener newPort = JLCommonSocket.listener();
         if (newPort == null) {
            return "No Listener.";
         }

         s.listener = newPort;
      }

      s.start();
      this.poolServers.push(s);
      return 210;
   }

   Object dequeue() {
      LinkedList var1 = this.workQueue;
      synchronized(this.workQueue) {
         return this.workQueue.isEmpty() ? null : this.workQueue.remove();
      }
   }

   void enqueue(Object x) {
      LinkedList var2 = this.workQueue;
      synchronized(this.workQueue) {
         this.workQueue.add(x);
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 114 ms
	
	Decompiled with FernFlower.
*/