package com.franz.jlinker;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class TranStruct extends JLWrapper {
   public String home;
   public int type;
   public int[] nums;
   public String[] strings;
   public double[] reals;
   public Object exdata;

   public Object getExdata() {
      return this.exdata;
   }

   public void setExdata(Object val) {
      this.exdata = val;
   }

   public TranStruct(String h, int t, int[] n, String[] s, double[] r) {
      this.exdata = null;
      this.home = h;
      this.type = t;
      this.nums = n;
      this.strings = s;
      this.reals = r;
   }

   public TranStruct(boolean x) {
      this("Self", 0, new int[1], new String[0], new double[0]);
      if (x) {
         this.nums[0] = 1;
      } else {
         this.nums[0] = 0;
      }

      this.setImmediate();
      this.setType(9, 0, 0);
   }

   public TranStruct(byte x) {
      this("Self", 0, new int[1], new String[0], new double[0]);
      this.nums[0] = x;
      this.setImmediate();
      this.setType(1, 0, 0);
   }

   public TranStruct(short x) {
      this("Self", 0, new int[1], new String[0], new double[0]);
      this.nums[0] = x;
      this.setImmediate();
      this.setType(2, 0, 0);
   }

   public TranStruct(int x) {
      this("Self", 0, new int[1], new String[0], new double[0]);
      this.nums[0] = x;
      this.setImmediate();
      this.setType(3, 0, 0);
   }

   public TranStruct(long x) {
      this("Self", 0, new int[4], new String[0], new double[0]);
      int mask = 536870911;
      int sign = 1;
      if (x < 0L) {
         sign = -1;
         x = -(x + 1L);
      }

      int bits = (int)(x & (long)mask);
      this.nums[0] = bits;
      x >>= 29;
      bits = (int)(x & (long)mask);
      this.nums[1] = bits;
      x >>= 29;
      this.nums[2] = (int)x;
      this.nums[3] = sign;
      this.setImmediate();
      this.setType(4, 0, 0);
   }

   public TranStruct(char x) {
      this("Self", 0, new int[0], new String[1], new double[0]);
      char[] s = new char[]{x};
      this.strings[0] = new String(s);
      this.setImmediate();
      this.setType(5, 0, 0);
   }

   public TranStruct(String x) {
      this("Self", 0, new int[0], new String[1], new double[0]);
      this.strings[0] = x;
      this.setImmediate();
      this.setType(6, 0, 0);
   }

   public TranStruct(float x) {
      this("Self", 0, new int[0], new String[0], new double[1]);
      this.reals[0] = (double)x;
      this.setImmediate();
      this.setType(7, 0, 0);
   }

   public TranStruct(double x) {
      this("Self", 0, new int[0], new String[0], new double[1]);
      this.reals[0] = x;
      this.setImmediate();
      this.setType(8, 0, 0);
   }

   public TranStruct(String[] x) {
      this("Self", 0, new int[0], x, new double[0]);
      this.setImmediate();
      this.setType(6, 1, 0);
   }

   public TranStruct(byte[] x) {
      this("Self", 0, new int[0], new String[0], new double[0]);
      if (Transport.exData == 0) {
         int[] cp = new int[x.length];

         for(int i = 0; i < x.length; ++i) {
            cp[i] = x[i];
         }

         this.nums = cp;
         this.setImmediate();
         this.setType(1, 1, 0);
      } else {
         this.setExdata(x);
         this.setImmediate();
         this.setType(1, 1, 0);
         this.type |= 8192;
      }

   }

   public TranStruct(short[] x) {
      this("Self", 0, new int[0], new String[0], new double[0]);
      if (Transport.exData == 0) {
         int[] cp = new int[x.length];

         for(int i = 0; i < x.length; ++i) {
            cp[i] = x[i];
         }

         this.nums = cp;
         this.setImmediate();
         this.setType(2, 1, 0);
      } else {
         this.setExdata(x);
         this.setImmediate();
         this.setType(2, 1, 0);
         this.type |= 16384;
      }

   }

   public TranStruct(float[] x) {
      this("Self", 0, new int[0], new String[0], new double[0]);
      if (Transport.exData == 0) {
         double[] cp = new double[x.length];

         for(int i = 0; i < x.length; ++i) {
            cp[i] = (double)x[i];
         }

         this.reals = cp;
         this.setImmediate();
         this.setType(7, 1, 0);
      } else {
         this.setExdata(x);
         this.setImmediate();
         this.setType(7, 1, 0);
         this.type |= 24576;
      }

   }

   public TranStruct(double[] x) {
      this("Self", 0, new int[0], new String[0], x);
      this.setImmediate();
      this.setType(8, 1, 0);
   }

   public TranStruct(int[] x) {
      this("Self", 0, x, new String[0], new double[0]);
      this.setImmediate();
      this.setType(3, 1, 0);
   }

   public TranStruct(Throwable x) {
      this("Java", 0, new int[2], new String[2], new double[0]);
      this.strings[0] = x.getClass().getName();
      this.strings[1] = x.toString();
      this.setRemote(2, 1);
      this.setType(0, 0, 61);
      JLSocketClient.registerJavaObject(x, this);
   }

   static boolean isP(Object x) {
      return x instanceof TranStruct;
   }

   static int getArrayLength(Object x) {
      return x instanceof TranStruct[] ? ((TranStruct[])x).length : -1;
   }

   static int getObjectArrayLength(Object x) {
      if (!(x instanceof Object[])) {
         return -1;
      } else {
         Object[] y = (Object[])x;

         for(int i = 0; i < y.length; ++i) {
            if (!(y[i] instanceof TranStruct)) {
               return -i - 1;
            }
         }

         return y.length;
      }
   }

   static TranStruct[] toArray(Object x) {
      Object[] y = (Object[])x;
      TranStruct[] res = new TranStruct[y.length];

      for(int i = 0; i < y.length; ++i) {
         res[i] = (TranStruct)y[i];
      }

      return res;
   }

   static int getBits(int base, int width, int shift) {
      int mask = (1 << width) - 1 << shift;
      return (base & mask) >> shift;
   }

   int getTypeBits(int width, int shift) {
      return getBits(this.type, width, shift);
   }

   boolean immediateP() {
      return this.getTypeBits(1, 0) == 0;
   }

   boolean indirectP() {
      return 1 == this.getTypeBits(1, 0);
   }

   boolean localP() {
      return this.home.equalsIgnoreCase("Java");
   }

   boolean remoteP() {
      return !this.home.equalsIgnoreCase("Self") && !this.home.equalsIgnoreCase("Java");
   }

   boolean intP() {
      return this.immediateP() && this.rankP(0) && this.baseP(3);
   }

   boolean rankP(int n) {
      int r = this.getTypeBits(5, 3);
      if (r == 31) {
         return n == this.nums[2];
      } else {
         return n == r;
      }
   }

   boolean baseP(int tp) {
      return tp == this.getTypeBits(5, 8);
   }

   boolean booleanP() {
      return this.immediateP() && this.rankP(0) && this.baseP(9);
   }

   boolean aggrP(int tp) {
      return tp == this.getTypeBits(8, 16);
   }

   boolean lastUseP() {
      return 1 == this.getTypeBits(1, 1);
   }

   public boolean symbolP() {
      return this.immediateP() && this.rankP(0) && this.baseP(10);
   }

   public boolean nullP() {
      return this.immediateP() && this.rankP(0) && this.baseP(31);
   }

   public boolean integerP() {
      return this.immediateP() && this.rankP(0) && (this.baseP(1) || this.baseP(2) || this.baseP(3));
   }

   public boolean shortP() {
      return this.immediateP() && this.rankP(0) && this.baseP(2);
   }

   boolean longP() {
      return this.immediateP() && this.rankP(0) && this.baseP(4);
   }

   boolean byteP() {
      return this.immediateP() && this.rankP(0) && this.baseP(1);
   }

   public boolean charP() {
      return this.immediateP() && this.rankP(0) && this.baseP(5);
   }

   public boolean realP() {
      return this.immediateP() && this.rankP(0) && (this.baseP(7) || this.baseP(8));
   }

   public boolean singleP() {
      return this.immediateP() && this.rankP(0) && this.baseP(7);
   }

   public boolean doubleP() {
      return this.immediateP() && this.rankP(0) && this.baseP(8);
   }

   public boolean stringP() {
      return this.immediateP() && this.rankP(0) && this.baseP(6);
   }

   static int setBits(int inbase, int newbase, int width, int shift) {
      int mask = (1 << width) - 1 << shift;
      int base = inbase | mask;
      base ^= mask;
      base |= mask & newbase << shift;
      return base;
   }

   TranStruct setRemote(int indirection, int discard) {
      int base = this.type;
      switch(indirection) {
      case 1:
         base = setBits(base, 0, 1, 0);
         break;
      case 2:
         base = setBits(base, 1, 1, 0);
      }

      switch(discard) {
      case 1:
         base = setBits(base, 0, 1, 1);
         base = setBits(base, 0, 1, 2);
         break;
      case 2:
         base = setBits(base, 1, 1, 1);
         break;
      case 3:
         base = setBits(base, 0, 1, 1);
         base = setBits(base, 1, 1, 2);
      }

      this.type = base;
      return this;
   }

   TranStruct setType(int base, int rank, int aggr) {
      int obtype = this.type;
      obtype = setBits(obtype, base, 5, 8);
      obtype = setBits(obtype, rank, 5, 3);
      obtype = setBits(obtype, aggr, 8, 16);
      this.type = obtype;
      return this;
   }

   TranStruct setImmediate() {
      return this.setRemote(1, 1);
   }

   TranStruct lastUse() {
      return this.setRemote(0, 2);
   }

   public int intValue(int i) {
      return i < this.nums.length ? this.nums[i] : 0;
   }

   public int intValue() {
      return this.intValue(0);
   }

   public boolean boolValue() {
      return this.intValue() != 0;
   }

   public char charValue(int j, int i) {
      return i < this.strings.length && j < this.strings[i].length() ? this.strings[i].charAt(j) : ' ';
   }

   public char charValue(int j) {
      return this.charValue(j, 0);
   }

   public char charValue() {
      return this.charValue(0, 0);
   }

   public String stringValue(int i) {
      return i < this.strings.length ? this.strings[i] : "";
   }

   public String stringValue() {
      return this.stringValue(0);
   }

   public String symbolName() {
      return this.stringValue(0);
   }

   public String symbolPackage() {
      return this.stringValue(1);
   }

   public double doubleValue(int i) {
      return i < this.reals.length ? this.reals[0] : 0.0D;
   }

   public double doubleValue() {
      return this.doubleValue(0);
   }

   public long longValue() {
      long x0 = (long)this.intValue(0);
      long x1 = (long)this.intValue(1);
      long x2 = (long)this.intValue(2);
      long sign = (long)this.intValue(3);
      if (sign == 0L) {
         sign = 1L;
      }

      return sign * (x0 + (x1 + (x2 << 29) << 29));
   }

   public int symbolCaseModes() {
      return this.intValue(0);
   }

   public Object pointerValue() {
      return JLSocketClient.extractJavaRef(this, new Object[3]);
   }

   public static TranStruct newTrSym(String name, String pkg, int cmd) {
      TranStruct str = new TranStruct("Self", 0, new int[1], new String[2], new double[0]);
      str.strings[0] = name;
      str.strings[1] = pkg;
      str.nums[0] = cmd;
      str.setImmediate();
      str.setType(10, 0, 0);
      return str;
   }

   public static TranStruct nullTrS() {
      TranStruct x = new TranStruct("Self", 0, new int[0], new String[0], new double[0]);
      x.setImmediate();
      x.setType(31, 0, 0);
      if (Transport.exData == 0) {
         x.type |= 57344;
      }

      return x;
   }

   public static TranStruct newTrS(Object x) {
      if (x == null) {
         return nullTrS();
      } else if (x instanceof TranStruct) {
         return (TranStruct)x;
      } else if (x instanceof JLinkerException) {
         JLinkerException y = (JLinkerException)x;
         Object z = y.errorObject();
         return z == null ? new TranStruct(y) : newTrS(z);
      } else if (x instanceof Throwable) {
         return new TranStruct((Throwable)x);
      } else {
         String cln = x.getClass().getName();
         int[] nn;
         byte rr;
         byte tt;
         String[] ss;
         if (cln.startsWith("[")) {
            nn = new int[]{0, 0, Array.getLength(x)};
            ss = new String[]{cln};
            rr = 1;
            tt = 4;
         } else if (x instanceof Class) {
            nn = new int[2];
            ss = new String[]{cln, ((Class)x).getName()};
            rr = 0;
            tt = 5;
         } else if (x instanceof Constructor) {
            nn = new int[2];
            ss = JLSocketClient.addSig(((Constructor)x).getParameterTypes(), cln, ((Constructor)x).getDeclaringClass().getName(), "");
            rr = 0;
            tt = 6;
         } else if (x instanceof Method) {
            nn = new int[2];
            ss = JLSocketClient.addSig(((Method)x).getParameterTypes(), cln, ((Method)x).getDeclaringClass().getName(), ((Method)x).getName());
            rr = 0;
            tt = 7;
         } else {
            nn = new int[2];
            ss = new String[]{cln};
            rr = 0;
            tt = 1;
         }

         TranStruct str = new TranStruct("Java", 0, nn, ss, new double[0]);
         str.setRemote(2, 1);
         str.setType(0, rr, tt);
         JLSocketClient.registerJavaObject(x, str);
         return str;
      }
   }

   static String showStrings(String[] s) {
      String tail = "}";
      if (s == null) {
         return "Null_String[]";
      } else {
         switch(s.length) {
         case 0:
            return "{}";
         case 1:
            return "{" + s[0] + tail;
         default:
            tail = ", " + s.length + "..." + tail;
         case 2:
            return "{" + s[0] + ", " + s[1] + tail;
         }
      }
   }

   static String showStrings(Object[] s, int max) {
      String out = "{";
      if (s == null) {
         return "NULL_Object[]";
      } else {
         switch(s.length) {
         case 0:
            break;
         case 1:
            out = out + s[0];
            break;
         case 2:
         case 3:
            out = out + s[0] + ", " + s[1];
            if (2 == s.length) {
               break;
            }

            if (max > out.length()) {
               out = out + ", " + s[2];
               break;
            }
         default:
            out = out + s[0] + ", " + s[1] + s.length + "...";
         }

         return out + "}";
      }
   }

   static String show(Object v) {
      String ss = "";
      int tt;
      if (v instanceof TranStruct) {
         try {
            TranStruct tr = (TranStruct)v;
            if (tr.booleanP()) {
               ss = "Bool " + tr.boolValue();
            } else if (tr.integerP()) {
               ss = "Int " + tr.intValue();
            } else if (tr.realP()) {
               ss = "Real " + tr.doubleValue();
            } else if (tr.stringP()) {
               ss = "\"" + tr.stringValue() + "\"";
            } else if (tr.shortP()) {
               ss = "Short " + tr.intValue();
            } else if (tr.symbolP()) {
               ss = "Sym " + tr.symbolName() + " in " + tr.symbolPackage();
            } else if (JLSocketClient.errorP(tr)) {
               ss = "ERROR " + showStrings(tr.strings);
            } else if (tr.remoteP()) {
               ss = "Lisp " + showStrings(tr.strings);
            } else if (tr.indirectP()) {
               ss = "" + tr.pointerValue();
            } else {
               tt = tr.getTypeBits(8, 16);
               ss = tt + " " + tr.getTypeBits(5, 8) + " " + tr.getTypeBits(5, 3) + " [" + tr.nums.length + "][" + tr.strings.length + "]";
            }

            ss = "<" + ss + ">";
         } catch (Exception var4) {
            ss = "<???>";
         }
      } else if (v instanceof TranStruct[]) {
         TranStruct[] aa = (TranStruct[])v;
         ss = "{";

         for(tt = 0; tt < Math.min(5, aa.length); ++tt) {
            if (tt > 0) {
               ss = ss + ", ";
            }

            if (3 > tt) {
               ss = ss + show(aa[tt]);
            }

            if (4 == tt) {
               ss = ss + (aa.length - 3) + " more";
            }
         }

         ss = ss + "}";
      } else {
         ss = "<?" + v + ">";
      }

      return ss;
   }

   int getIndexInLisp() {
      return this.nums[0];
   }

   protected void finalize() {
      if (this.deadLink != DEAD) {
         addDeadLink(this);
      }
   }

   boolean isLispPointer() {
      return JLSocketClient.liveP(this) && this.remoteP();
   }

   void setDiscarded() {
      this.setRemote(0, 3);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 165 ms
	
	Decompiled with FernFlower.
*/