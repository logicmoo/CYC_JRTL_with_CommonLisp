package com.franz.jlinker;

public class JLTransportCodes {
   public static final int ONE_WAY_CODE = 15;
   public static final int MESSAGE_CODE = 17;
   public static final int RESPONSE_CODE = 33;
   public static final int REQUEST_CODE = 18;
   public static final int REPLY_CODE = 34;
   public static final int ERROR_CODE = 62;
   public static final int DISCONNECT_CODE = 63;
   public static final int INVOKE_CODE = 19;
   public static final int ARGLIST_CODE = 20;
   public static final int RESULT_CODE = 35;
   public static final int ANSWER_CODE = 36;
   public static final int STRING_CODE = 66;
   public static final int INT_CODE = 65;
   public static final int SEQINT_CODE = 99;
   public static final int SEQSTRING_CODE = 101;
   public static final int SEQREAL_CODE = 103;
   public static final int EMPTY_SEQI_CODE = 98;
   public static final int EMPTY_SEQS_CODE = 100;
   public static final int EMPTY_SEQR_CODE = 102;
   public static final int EMPTY_SEQB_CODE = 104;
   public static final int SEQBYTE_CODE = 105;
   public static final int EMPTY_SEQK_CODE = 106;
   public static final int SEQSHORT_CODE = 107;
   public static final int EMPTY_SEQF_CODE = 110;
   public static final int SEQFLOAT_CODE = 111;
   public static final int NULL_CODE = 96;
   public static final int DEFAULT_BUFFER_SIZE = 512;
   public static final int SEQ_LENGTH_LIMIT = 16777216;
   public static final int PORT_IDLE = 0;
   public static final int PORT_CLOSED = -1;
   public static final int PORT_REQUEST = 3;
   public static final int PORT_WAITING_RESPONSE = 2;
   public static final int PORT_WAITING_REPLY = 4;
   public static final int PORT_MESSAGE = 1;
   public static final int PORT_INVOKE = 5;
   public static final int PORT_WAITING_RESULT = 6;
   public static final int TM_EXTNMASK = 57344;
   public static final int TM_EXBYTES = 8192;
   public static final int TM_EXSHORTS = 16384;
   public static final int TM_EXFLOATS = 24576;

   static String inverse(int s) {
      switch(s) {
      case -1:
         return "PORT_CLOSED";
      case 0:
         return "PORT_IDLE";
      case 1:
         return "PORT_MESSAGE";
      case 2:
         return "PORT_WAITING_RESPONSE";
      case 3:
         return "PORT_REQUEST";
      case 4:
         return "PORT_WAITING_REPLY";
      case 5:
         return "PORT_INVOKE";
      case 6:
         return "PORT_WAITING_RESULT";
      default:
         return "" + s;
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 5 ms
	
	Decompiled with FernFlower.
*/