package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;

class JNIWrapper extends JLWrapper {
   TypeCode type;
   Object data;
   String packageName;
   int action;
   int lispIndex;
   String lispType;
   String lispDesc;

   public String getWrapperType() {
      return this.type.getTypeChar();
   }

   public String getLispType() {
      if (this.type == TypeCode.LISP_POINTER) {
         return this.lispType;
      } else {
         return this.type == TypeCode.SYMBOL ? "symbol" : "";
      }
   }

   public int getLispIndex() {
      return this.lispIndex;
   }

   boolean isLispPointer() {
      return this.type == TypeCode.LISP_POINTER;
   }

   void setDiscarded() {
      this.type = TypeCode.NULL;
   }

   public String getSymbolName() {
      return this.type == TypeCode.SYMBOL ? (String)this.data : "";
   }

   public String getSymbolPackage() {
      return this.packageName;
   }

   public int getSymbolAction() {
      return this.action;
   }

   public String getSymbolParts() {
      String nm = "" + this.data;
      if ("".equals(this.packageName)) {
         return "L " + this.action + " " + nm;
      } else {
         return ":".equals(this.packageName) ? "K " + this.action + " " + nm : "P " + this.action + " " + this.packageName + " " + nm;
      }
   }

   JNIWrapper(String tp, int index, String ltype, String more) {
      this.type = TypeCode.NULL;
      this.data = null;
      this.packageName = "";
      this.action = 0;
      this.lispIndex = 0;
      this.lispType = "";
      this.lispDesc = "";
      this.type = encodeType(tp);
      this.lispType = ltype;
      this.lispDesc = more;
      this.lispIndex = index;
   }

   JNIWrapper(String name, String pk, int act) {
      this.type = TypeCode.NULL;
      this.data = null;
      this.packageName = "";
      this.action = 0;
      this.lispIndex = 0;
      this.lispType = "";
      this.lispDesc = "";
      this.type = TypeCode.SYMBOL;
      this.data = name;
      this.packageName = pk;
      this.action = act;
   }

   int getIndexInLisp() {
      return this.lispIndex;
   }

   protected void finalize() {
      if (this.deadLink != DEAD) {
         addDeadLink(this);
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 18 ms
	
	Decompiled with FernFlower.
*/