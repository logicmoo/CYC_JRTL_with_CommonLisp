package com.franz.jlinker;


public class LispConnector {
   public static boolean lispAdvertises = true;
   public static boolean advertInFile = false;
   public static String lispFile = "";
   public static String lispHost = "";
   public static int lispPort = 4321;
   public static int pollInterval = 1000;
   public static int pollCount = 300;
   public static int javaTimeout = -1;
   public static String javaFile = "";
   public static String javaHost = "";
   public static int javaPort = 0;
   public static boolean debug = false;

   public static synchronized boolean go() {
      return go(false, (String[])null);
   }

   public static synchronized boolean go(boolean ver) {
      return go(ver, (String[])null);
   }

   public static synchronized boolean go(boolean ver, String[] throwErr) {
      String why = "";
      JLCommon.sdebug = debug;
      if (JLSocketClient.query(ver)) {
         return true;
      } else {
         if (lispAdvertises) {
            if (advertInFile) {
               if (!JavaLinkDist.connect(lispFile, javaHost, javaPort, pollInterval, pollCount)) {
                  why = "Connect to Lisp file failed.";
               }
            } else if (!JavaLinkDist.connect(lispHost, lispPort, javaHost, javaPort, pollInterval, pollCount)) {
               why = "Connect to Lisp port failed.";
            }
         } else if (advertInFile) {
            if (!JLCommonSocket.advertise(javaFile, javaHost, javaPort, javaTimeout)) {
               why = "Lisp did not connect to file.";
            }
         } else if (!JLCommonSocket.advertise(javaPort, javaTimeout)) {
            why = "Lisp did not connect to port.";
         }

         if (why.length() == 0) {
            return true;
         } else {
            why = "LispConnector.go: " + why;
            if (throwErr == null) {
               throw new IllegalArgumentException(why);
            } else {
               if (throwErr.length > 0) {
                  throwErr[0] = why;
               }

               return false;
            }
         }
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 12 ms
	 @deprecated 
	Decompiled with FernFlower.
*/