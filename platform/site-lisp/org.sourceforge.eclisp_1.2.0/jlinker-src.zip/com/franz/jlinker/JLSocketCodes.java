package com.franz.jlinker;

public abstract class JLSocketCodes {
   public static final String TR_HOMEImmediate = "Self";
   public static final int TR_NONE = 0;
   public static final int TR_RemoteWidth = 3;
   public static final int TR_IndirectShift = 0;
   public static final int TR_IMMEDIATE = 0;
   public static final int TR_INDIRECT = 1;
   public static final int TR_LastShift = 1;
   public static final int TR_KEEP = 0;
   public static final int TR_DISCARD = 1;
   public static final int TR_DiscardShift = 2;
   public static final int TR_LIVE = 0;
   public static final int TR_DISCARDED = 1;
   public static final int TR_RankWidth = 5;
   public static final int TR_RankShift = 3;
   public static final int TR_HIRANK = 31;
   public static final int TR_BaseWidth = 5;
   public static final int TR_ExtnWidth = 3;
   public static final int TR_BaseShift = 8;
   public static final int TR_ExtnShift = 13;
   public static final int TR_BYTE = 1;
   public static final int TR_SHORT = 2;
   public static final int TR_INT = 3;
   public static final int TR_LONG = 4;
   public static final int TR_CHAR = 5;
   public static final int TR_STRING = 6;
   public static final int TR_SINGLE = 7;
   public static final int TR_DOUBLE = 8;
   public static final int TR_BOOL = 9;
   public static final int TR_SYMBOL = 10;
   public static final int TR_MESSAGE = 30;
   public static final int TR_NULL = 31;
   public static final int TR_AggrWidth = 8;
   public static final int TR_AggrShift = 16;
   public static final int TR_AggrMask = 255;
   public static final int TR_POINTER = 1;
   public static final int TR_ARRAY = 4;
   public static final int TR_CLASS = 5;
   public static final int TR_CONSTRUCTOR = 6;
   public static final int TR_METHOD = 7;
   public static final int TR_ERROR = 61;
   public static final int TR_INDEXWIDTH = 29;
   public static final int TR_MKActivate = 1;
   public static final int TR_MKMessage = 2;
   public static final int TR_MKDiscard = 3;
   public static final int TR_MKInvoke = 4;
   public static final int TR_MKNotify = 5;
   public static final int TR_EXTNMASK = 57344;
   public static final int TR_EXBYTES = 8192;
   public static final int TR_EXSHORTS = 16384;
   public static final int TR_EXFLOATS = 24576;
   static final int IGNORE = 0;
   static final int setIMM = 1;
   static final int setIND = 2;
   static final int setLIVE = 1;
   static final int setLAST = 2;
   static final int setDEAD = 3;
   static final int REQ_init_pool = 101;
   static final int REQ_verify_from_Java = 103;
   static final int REQ_verify_from_Lisp = 107;
   static final int REQ_Java_making_port = 320;
   static final int REQ_Lisp_making_port = 210;
   static final int REQ_Lisp_pool_server_started = 220;
   static final int REQ_drop_port_to_Lisp = 230;
   static final int REQ_pool_query = 111;
   static final int REQ_pool_query_reply = 113;
   static final String POOL_REQ_HOME = "connectionPool";
   static final String LISP_SERVER_REQ = "LispServerRequest";
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 4 ms
	
	Decompiled with FernFlower.
*/