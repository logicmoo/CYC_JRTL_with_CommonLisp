package com.franz.jlinker;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JLMouseAdapter extends MouseAdapter {
   public static synchronized void addTo(Component comp) {
      comp.addMouseListener(new JLMouseAdapter());
   }

   private void caller(String name, MouseEvent e) {
      String[] s = new String[]{e.paramString()};
      int[] l = new int[]{e.getModifiers(), e.isPopupTrigger() ? 1 : 0, e.getClickCount(), e.getX(), e.getY()};
      LispCall.dispatchEvent(name, e.getComponent(), s, l);
   }

   public void mouseClicked(MouseEvent e) {
      this.caller("mouseClicked", e);
   }

   public void mousePressed(MouseEvent e) {
      this.caller("mousePressed", e);
   }

   public void mouseReleased(MouseEvent e) {
      this.caller("mouseReleased", e);
   }

   public void mouseEntered(MouseEvent e) {
      this.caller("mouseEntered", e);
   }

   public void mouseExited(MouseEvent e) {
      this.caller("mouseExited", e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 12 ms
	
	Decompiled with FernFlower.
*/