package com.franz.jlinker;

import java.awt.Button;
import java.awt.List;
import java.awt.MenuItem;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JLActionListener implements ActionListener {
   private Object handle;

   public static synchronized void addTo(Button comp) {
      JLActionListener l = new JLActionListener();
      l.handle = comp;
      comp.addActionListener(l);
   }

   public static synchronized void addTo(List comp) {
      JLActionListener l = new JLActionListener();
      l.handle = comp;
      comp.addActionListener(l);
   }

   public static synchronized void addTo(MenuItem comp) {
      JLActionListener l = new JLActionListener();
      l.handle = comp;
      comp.addActionListener(l);
   }

   public static synchronized void addTo(TextField comp) {
      JLActionListener l = new JLActionListener();
      l.handle = comp;
      comp.addActionListener(l);
   }

   public void actionPerformed(ActionEvent e) {
      String[] s = new String[]{e.paramString(), e.getActionCommand()};
      int[] l = new int[]{e.getModifiers()};
      LispCall.dispatchEvent("actionPerformed", this.handle, s, l);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 33 ms
	
	Decompiled with FernFlower.
*/