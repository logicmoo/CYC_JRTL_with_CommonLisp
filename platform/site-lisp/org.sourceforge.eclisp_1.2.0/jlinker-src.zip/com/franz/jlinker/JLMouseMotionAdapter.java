package com.franz.jlinker;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class JLMouseMotionAdapter extends MouseMotionAdapter {
   public static synchronized void addTo(Component comp) {
      comp.addMouseMotionListener(new JLMouseMotionAdapter());
   }

   private void caller(String name, MouseEvent e) {
      String[] s = new String[]{e.paramString()};
      int[] l = new int[]{e.getModifiers(), e.isPopupTrigger() ? 1 : 0, e.getClickCount(), e.getX(), e.getY()};
      LispCall.dispatchEvent(name, e.getComponent(), s, l);
   }

   public void mouseDragged(MouseEvent e) {
      this.caller("mouseDragged", e);
   }

   public void mouseMoved(MouseEvent e) {
      this.caller("mouseMoved", e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 10 ms
	
	Decompiled with FernFlower.
*/