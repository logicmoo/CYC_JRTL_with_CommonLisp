package com.franz.jlinker;

import com.franz.jlinker.JLSocketServer.JLSEnder;
import com.franz.jlinker.Transport.Handler;
import com.franz.jlinker.Transport.Listener;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class JLSocketServer extends Thread implements Handler {
   Listener listener = null;
   Transport serverPort = null;
   public Object serverState = "Closed";

   public JLSocketServer(String host, int port) {
      super("JavaLinkServer");
      this.serverState = "Closed";
      this.dsprint("connecting to port.");
      Object p = Transport.connectToHostPort(host, port, "server", false);
      if (p instanceof Transport) {
         this.dsprint("connected to port " + host + ":" + port);
         this.serverPort = (Transport)p;
      } else {
         throw new IllegalArgumentException(this.getName() + " connection to " + host + ":" + port + " failed -- " + p);
      }
   }

   public JLSocketServer(Listener ll) {
      super("JavaLinkServer");
      this.serverState = "Closed";
      this.listener = ll;
      this.dsprint("Using open listener " + this.listener);
   }

   public JLSocketServer(String nm) {
      super(nm);
   }

   void dsprint(String s) {
      JLCommon.dsprint(s);
   }

   public void shutdown(Object reason) {
      this.dsprint("Shutdown - " + reason);
      if (this.serverPort != null) {
         this.serverPort.shutdown(reason);
      }

      this.interrupt();
   }

   Transport initServerPort(boolean initial) {
      Object p = null;

      try {
         if (this.serverPort != null) {
            this.dsprint("run: connected to port.");
            p = this.serverPort;
         } else {
            this.dsprint("run: listening at server port.");

            try {
               p = Transport.acceptDataPort(this.listener, "server", false);
            } catch (Exception var4) {
               p = var4;
            }
         }

         if (p instanceof Transport) {
            this.serverState = "Running";
            this.dsprint("run: server started.");
            return (Transport)p;
         }

         this.dsprint("run: makeServerDataPort failed " + p);
      } catch (Exception var5) {
         this.serverState = this.serverState + " " + var5;
      }

      if (initial) {
         JLCommonSocket.disconnect();
      }

      this.dsprint("run: server ending status: " + this.serverState);
      return null;
   }

   void scheduleDisconnect() {
      this.dsprint("Scheduling disconnect.");
      (new JLSEnder(this)).start();
   }

   public void run() {
      Transport port = this.initServerPort(true);
      if (port != null) {
         try {
            this.serverState = "Running";
            this.dsprint("run: server started.");
            this.serverState = port.doServer(this);
         } finally {
            JLCommonSocket.disconnect();
            this.dsprint("run: server ending status: " + this.serverState);
         }

      }
   }

   JLCommonSocket getAnchor() {
      return (JLCommonSocket)JLCommon.lispJavaConnection;
   }

   public int doMessage(int msg) {
      return msg;
   }

   public Object doRequest(String home, int type, int[] nums, String[] strings, double[] reals) {
      if (home.equals("LispServerRequest")) {
         synchronized(this) {
            this.notify();
         }

         return new String[]{this.getAnchor().java_key, this.getAnchor().lisp_key};
      } else {
         if (home.equals("connectionPool")) {
            JLConnectionPoolManager pm;
            switch(type) {
            case 101:
               return JLConnectionPoolManager.requestInitPool(nums);
            case 111:
               pm = JLConnectionPoolManager.poolManager;
               if (pm == null) {
                  return -1;
               }

               if (nums == null || 1 >= nums.length) {
                  return -3;
               }

               Transport p = null;
               Exception err = null;

               Integer var11;
               try {
                  p = pm.getPortToLisp((long)nums[0], (Transport)null);
                  if (p != null) {
                     Object var18 = p.request("connectionPool", 113, new int[]{nums[1]}, (String[])null, (double[])null, false);
                     return var18;
                  }

                  var11 = -2;
               } catch (Exception var16) {
                  err = var16;
                  break;
               } finally {
                  if (p != null) {
                     pm.releasePortToLisp(p, err);
                  }

               }

               return var11;
            case 210:
               pm = JLConnectionPoolManager.poolManager;
               if (pm == null) {
                  return "No pool manager running.";
               }

               return pm.newPoolManager();
            }
         }

         return "Unknown request: " + home;
      }
   }

   public TranStruct[] doInvoke(TranStruct[] data) {
      int intres = true;
      int style = 2;
      int dlen = data.length;
      TranStruct[] res0 = new TranStruct[0];
      TranStruct[] res = res0;
      if (dlen > 0) {
         TranStruct jls0 = data[0];
         if ((jls0.type & 7936) == 7680 && jls0.nums.length > 1) {
            style = jls0.nums[0];
            int kind = jls0.nums[1];
            int i;
            switch(kind) {
            case 1:
               Object ares = this.doInvokeActivate(jls0.nums[2], jls0.strings);
               if (ares != null) {
                  this.shutdown(ares);
               }
               break;
            case 2:
               int intres = this.doInvokeMessage(jls0.nums[2], jls0.strings);
               res = new TranStruct[]{new TranStruct(intres)};
               break;
            case 3:
               int[] nums = new int[jls0.nums.length - 2];

               for(i = 0; i < nums.length; ++i) {
                  nums[i] = jls0.nums[i + 2];
               }

               JLSocketClient.discard(nums);
               break;
            case 4:
               if (1 < dlen) {
                  TranStruct[] args = new TranStruct[dlen - 2];

                  for(i = 0; i < args.length; ++i) {
                     args[i] = data[i + 2];
                  }

                  res = this.invoke(style, data[1], args);
               }
               break;
            default:
               res = new TranStruct[]{new TranStruct("Unknown message: style=" + style + " kind=" + kind + " nums.length=" + jls0.nums.length)};
            }
         } else {
            res = new TranStruct[]{new TranStruct("Unknown message type: " + jls0.type)};
         }
      } else {
         res = new TranStruct[]{new TranStruct("Zero-length arg list")};
      }

      switch(style) {
      case -1:
      case 0:
         return res0;
      case 1:
      case 2:
      case 3:
      default:
         return res;
      }
   }

   public Object doInvokeActivate(int what, String[] data) {
      Object res = null;
      String from = this.getName() + " activate " + what + " ";
      this.dsprint(from);
      switch(what) {
      case 1:
         this.dsprint(from + "simple round-trip query.");
         if (JLCommonSocket.havePortToLisp()) {
            this.getAnchor().notifyLisp("serverIsLive", 0, "", 1000);
         } else {
            this.dsprint(from + " Port to Lisp not ready.");
         }
         break;
      case 99:
         this.dsprint(from + "shutdown.");

         try {
            JLCommonSocket.disconnect();
            res = "disconnect";
         } catch (Exception var6) {
            res = "disconnect error " + var6;
         }
         break;
      default:
         this.dsprint(from + "one-way message ignored.");
      }

      return res;
   }

   public int doInvokeMessage(int what, String[] data) {
      int dn = data.length;
      int res = false;
      String d0;
      switch(dn) {
      case 0:
         d0 = "<String[0]>";
         break;
      case 1:
         d0 = data[0];
         break;
      default:
         d0 = data[0] + "..." + dn;
      }

      this.dsprint("JLCommonSocket.message: " + what + "  Data: " + d0);
      int res;
      switch(what) {
      case 1:
         if (!JLCommonSocket.havePortToLisp()) {
            res = 2;
         } else {
            this.getAnchor().notifyLisp("connectToServer", 0, "", 1000);
            res = 1;
         }
         break;
      case 2:
         res = JLCommonSocket.setConnected() ? 1 : 0;
         break;
      case 3:
         res = 3;
         break;
      case 11:
         JLConnectionPoolManager pm = JLConnectionPoolManager.poolManager;
         if (pm == null) {
            res = -1;
         } else {
            pm.initDone();
            res = 11;
         }
         break;
      case 21:
         res = JLCommonSocket.setReady() ? 1 : 0;
         break;
      default:
         this.dsprint("JLCommonSocket.message: round-trip message ignored.");
         res = -1;
      }

      this.dsprint("JLCommonSocket.message: returning " + res);
      return res;
   }

   static TranStruct wrap(Object x) {
      return x instanceof TranStruct ? (TranStruct)x : TranStruct.newTrS(x);
   }

   static TranStruct unwrap(Object ref) {
      if (ref instanceof Boolean) {
         return new TranStruct((Boolean)ref);
      } else if (ref instanceof Character) {
         return new TranStruct((Character)ref);
      } else if (ref instanceof Byte) {
         return new TranStruct((Byte)ref);
      } else if (ref instanceof Short) {
         return new TranStruct((Short)ref);
      } else if (ref instanceof Integer) {
         return new TranStruct((Integer)ref);
      } else if (ref instanceof Long) {
         return new TranStruct((Long)ref);
      } else if (ref instanceof Float) {
         return new TranStruct((Float)ref);
      } else if (ref instanceof Double) {
         return new TranStruct((Double)ref);
      } else if (ref instanceof String) {
         return new TranStruct((String)ref);
      } else {
         String s = ref.getClass().getName();
         if (s.equals("[Ljava.lang.String;")) {
            return new TranStruct((String[])ref);
         } else if (s.equals("[B")) {
            return new TranStruct((byte[])ref);
         } else if (s.equals("[S")) {
            return new TranStruct((short[])ref);
         } else if (s.equals("[I")) {
            return new TranStruct((int[])ref);
         } else if (s.equals("[F")) {
            return new TranStruct((float[])ref);
         } else {
            return s.equals("[D") ? new TranStruct((double[])ref) : wrap(ref);
         }
      }
   }

   private TranStruct[] invoke(int style, TranStruct op, TranStruct[] args) {
      JLCommon.dsprint("invoke(" + style + ", " + TranStruct.show(op) + ", " + TranStruct.show(args) + ")");
      int FORNAME = true;
      int GETMETH = true;
      int GETCONS = true;
      int METHOD = true;
      int NEWINST = true;
      int NEWARRAY = true;
      int GETFIELD = true;
      int SETFIELD = true;
      int GETSTATIC = true;
      int SETSTATIC = true;
      int QUERYFREE = true;
      int QUERYLIVE = true;
      int ERROR = true;
      int rtype = 1;
      String rclass = "";
      Class<?> target = null;
      String name = "";
      int argerrs = 0;
      String argerrm = "Arg err:";
      boolean errp = false;
      Object v = null;
      String errm = "";
      Object errv = "";
      Object[] cache = new Object[3];

      int i;
      try {
         int call = 99;
         String s = JLSocketClient.extractJavaType(op, cache);
         Object jmeth = JLSocketClient.extractJavaRef(op, cache);
         Object job = new Object();
         if (s.equalsIgnoreCase("err")) {
            errm = "Op err: " + jmeth;
         } else if (op.stringP()) {
            s = (String)jmeth;
            if (args.length == 1 && s.equalsIgnoreCase("forName")) {
               call = 1;
            } else if (args.length > 1 && s.equalsIgnoreCase("getMethod")) {
               call = 2;
            } else if (args.length > 0 && s.equalsIgnoreCase("getConstructor")) {
               call = 3;
            } else if (args.length > 1 && s.equalsIgnoreCase("newArray")) {
               call = 6;
            } else if (args.length == 3 && s.equalsIgnoreCase("getField")) {
               call = 7;
            } else if (args.length == 4 && s.equalsIgnoreCase("setField")) {
               call = 8;
            } else if (args.length == 2 && s.equalsIgnoreCase("getStatic")) {
               call = 9;
            } else if (args.length == 3 && s.equalsIgnoreCase("setStatic")) {
               call = 10;
            } else if (args.length == 0 && s.equalsIgnoreCase("queryFree")) {
               call = 51;
            } else if (args.length == 0 && s.equalsIgnoreCase("queryLive")) {
               call = 52;
            } else {
               errm = "Unknown op string: " + s;
            }
         } else if (s.equalsIgnoreCase("indirect")) {
            s = jmeth.getClass().getName();
            if (args.length > 0 && s.equals("java.lang.reflect.Method")) {
               call = 4;
            } else if (s.equals("java.lang.reflect.Constructor")) {
               call = 5;
            } else {
               errm = "Bad op class: " + s;
            }
         } else {
            errm = "Unknown op: " + s;
         }

         Object jarg;
         TranStruct darg;
         Object[] jargs;
         Class[] cargs;
         Field fieldHandle;
         switch(call) {
         case 1:
            v = JLSocketClient.extractClassRef(args[0], JLSocketClient.extractJavaRef(args[0], cache));
            break;
         case 2:
            cargs = new Class[args.length - 2];

            for(i = 0; i < args.length; ++i) {
               darg = args[i];
               s = JLSocketClient.extractJavaType(darg, cache);
               jarg = JLSocketClient.extractJavaRef(darg, cache);
               if (s.equalsIgnoreCase("err")) {
                  ++argerrs;
                  argerrm = argerrm + " " + i + ": " + (String)jarg + " ";
               }

               switch(i) {
               case 0:
                  target = JLSocketClient.extractClassRef(darg, jarg);
                  break;
               case 1:
                  name = (String)jarg;
                  break;
               default:
                  cargs[i - 2] = JLSocketClient.extractClassRef(darg, jarg);
               }
            }

            if (argerrs > 0) {
               errp = true;
               errm = argerrm;
            } else {
               v = target.getMethod(name, cargs);
            }
            break;
         case 3:
            cargs = new Class[args.length - 1];

            for(i = 0; i < args.length; ++i) {
               darg = args[i];
               s = JLSocketClient.extractJavaType(darg, cache);
               jarg = JLSocketClient.extractJavaRef(darg, cache);
               if (s.equalsIgnoreCase("err")) {
                  ++argerrs;
                  argerrm = argerrm + " " + i + ": " + (String)jarg + " ";
               }

               switch(i) {
               case 0:
                  target = JLSocketClient.extractClassRef(darg, jarg);
                  break;
               default:
                  cargs[i - 1] = JLSocketClient.extractClassRef(darg, jarg);
               }
            }

            if (argerrs > 0) {
               errp = true;
               errm = argerrm;
            } else {
               v = target.getConstructor(cargs);
            }
            break;
         case 4:
            jargs = new Object[args.length - 1];

            for(i = 0; i < args.length; ++i) {
               darg = args[i];
               s = JLSocketClient.extractJavaType(darg, cache);
               jarg = JLSocketClient.extractJavaRef(darg, cache);
               if (s.equalsIgnoreCase("err")) {
                  ++argerrs;
                  argerrm = argerrm + " " + i + ": " + (String)jarg + " ";
               }

               if (i == 0) {
                  job = jarg;
               } else {
                  jargs[i - 1] = jarg;
               }
            }

            if (argerrs > 0) {
               errp = true;
               errm = argerrm;
            } else {
               v = ((Method)jmeth).invoke(job, jargs);
               rtype = 2;
               rclass = ((Method)jmeth).getReturnType().getName();
            }
            break;
         case 5:
            jargs = new Object[args.length];

            for(i = 0; i < args.length; ++i) {
               darg = args[i];
               s = JLSocketClient.extractJavaType(darg, cache);
               jarg = JLSocketClient.extractJavaRef(darg, cache);
               if (s.equalsIgnoreCase("err")) {
                  ++argerrs;
                  argerrm = argerrm + " " + i + ": " + (String)jarg + " ";
               }

               jargs[i] = jarg;
            }

            if (argerrs > 0) {
               errp = true;
               errm = argerrm;
            } else {
               v = ((Constructor)jmeth).newInstance(jargs);
            }
            break;
         case 6:
            int[] iargs = new int[args.length - 1];

            for(i = 0; i < args.length; ++i) {
               darg = args[i];
               s = JLSocketClient.extractJavaType(darg, cache);
               jarg = JLSocketClient.extractJavaRef(darg, cache);
               if (s.equalsIgnoreCase("err")) {
                  ++argerrs;
                  argerrm = argerrm + " " + i + ": " + (String)jarg + " ";
               }

               switch(i) {
               case 0:
                  target = JLSocketClient.extractClassRef(darg, jarg);
                  break;
               default:
                  iargs[i - 1] = ((Number)jarg).intValue();
               }
            }

            if (argerrs > 0) {
               errp = true;
               errm = argerrm;
            } else {
               v = Array.newInstance(target, iargs);
            }
            break;
         case 7:
            target = JLSocketClient.extractClassRef(args[0], JLSocketClient.extractJavaRef(args[0], cache));
            s = args[1].stringValue();
            jarg = JLSocketClient.extractJavaRef(args[2], cache);
            fieldHandle = target.getField(s);
            v = fieldHandle.get(jarg);
            rtype = 2;
            rclass = fieldHandle.getType().getName();
            break;
         case 8:
            target = JLSocketClient.extractClassRef(args[0], JLSocketClient.extractJavaRef(args[0], cache));
            s = args[1].stringValue();
            jarg = JLSocketClient.extractJavaRef(args[2], cache);
            fieldHandle = target.getField(s);
            job = JLSocketClient.extractJavaRef(args[3], cache);
            fieldHandle.set(jarg, job);
            rtype = 0;
            v = new Integer(0);
            break;
         case 9:
            target = JLSocketClient.extractClassRef(args[0], JLSocketClient.extractJavaRef(args[0], cache));
            s = args[1].stringValue();
            fieldHandle = target.getField(s);
            v = fieldHandle.get((Object)null);
            rtype = 2;
            rclass = fieldHandle.getType().getName();
            break;
         case 10:
            target = JLSocketClient.extractClassRef(args[0], JLSocketClient.extractJavaRef(args[0], cache));
            s = args[1].stringValue();
            fieldHandle = target.getField(s);
            job = JLSocketClient.extractJavaRef(args[2], cache);
            fieldHandle.set((Object)null, job);
            rtype = 0;
            v = new Integer(0);
            break;
         case 51:
            v = new Integer(JLSocketClient.tableFree);
            rtype = 0;
            break;
         case 52:
            v = new Integer(JLSocketClient.tableLive);
            rtype = 0;
            break;
         case 99:
            errp = true;
            break;
         default:
            errp = true;
            errm = "Bad method ref";
         }
      } catch (InvocationTargetException var42) {
         errp = true;
         errv = var42.getTargetException();
         errm = errv.toString();
      } catch (Throwable var43) {
         errp = true;
         errm = var43.toString();
         errv = var43;
      }

      TranStruct[] res;
      if (errp) {
         res = new TranStruct[]{new TranStruct(errm), TranStruct.newTrS(errv)};
      } else if (style < 1) {
         res = new TranStruct[0];
      } else {
         res = new TranStruct[]{new TranStruct(1), null};
         if (v == null) {
            res[1] = TranStruct.nullTrS();
         } else if (rtype == 0) {
            res[1] = unwrap(v);
         } else if (rtype == 1) {
            res[1] = wrap(v);
         } else if (rclass.equals("java.lang.String")) {
            if (style == 1) {
               res[1] = wrap(v);
            } else {
               res[1] = unwrap(v);
            }
         } else if (!rclass.equals("boolean") && !rclass.equals("byte") && !rclass.equals("char") && !rclass.equals("double") && !rclass.equals("float") && !rclass.equals("int") && !rclass.equals("long") && !rclass.equals("short")) {
            if (style == 1) {
               res[1] = wrap(v);
            } else {
               res[1] = unwrap(v);
            }
         } else {
            res[1] = unwrap(v);
         }
      }

      if (op.lastUseP()) {
         JLSocketClient.discard(op.nums[0]);
      }

      for(i = 0; i < args.length; ++i) {
         if (args[i].lastUseP()) {
            JLSocketClient.discard(args[i].nums[0]);
         }
      }

      JLCommon.dsprint("invoke=" + TranStruct.show(res));
      return res;
   }

   public static void main(String[] args) throws Exception {
      JLCommonSocket d = new JLCommonSocket();
      d.scanargs(args);
      String linkHost = d.linkHost;
      int linkPort = d.linkPort;
      boolean r = false;
      LispCall.defaultConnectionPool = new int[]{-1, -1, -1, -1, -1, -1};
      JLCommon.dsprint("Start advertising at " + linkHost + ":" + linkPort);
      if (linkPort == 0 && !"".equals(linkHost)) {
         r = JLCommonSocket.advertise(linkHost, "", 0, 15);
      } else if (linkPort < 1) {
         JLCommon.dsprint("advertise failed - exit(1)");
         System.exit(1);
      } else {
         r = JLCommonSocket.advertise(linkPort, 15);
      }

      if (!r) {
         JLCommon.dsprint("advertise failed - exit(2)");
         System.exit(2);
      }

      while(JLCommonSocket.lispToJavaThread != null) {
         JLCommon.sleep(2000L, "JLSocketClient.main");
      }

      JLCommon.dsprint("exiting main");
      JLCommonSocket.disconnect();
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 365 ms
	
	Decompiled with FernFlower.
*/