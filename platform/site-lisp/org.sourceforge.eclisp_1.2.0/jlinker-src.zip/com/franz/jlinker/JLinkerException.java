package com.franz.jlinker;

public abstract class JLinkerException extends Exception {
   private Object errob = null;
   private static final long serialVersionUID = 1L;

   JLinkerException(String x) {
      super(x);
   }

   JLinkerException(String y, Object l) {
      super(y);
      this.errob = l;
   }

   Object errorObject() {
      return this.errob;
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 5 ms
	
	Decompiled with FernFlower.
*/