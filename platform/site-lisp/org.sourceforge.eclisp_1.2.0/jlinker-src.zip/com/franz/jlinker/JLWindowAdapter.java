package com.franz.jlinker;

import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class JLWindowAdapter extends WindowAdapter {
   public static synchronized void addTo(Window comp) {
      comp.addWindowListener(new JLWindowAdapter());
   }

   private void caller(String ev, WindowEvent e) {
      String[] s = new String[0];
      int[] l = new int[0];
      LispCall.dispatchEvent(ev, e.getWindow(), s, l);
   }

   public void windowOpened(WindowEvent e) {
      this.caller("windowOpened", e);
   }

   public void windowClosing(WindowEvent e) {
      this.caller("windowClosing", e);
   }

   public void windowClosed(WindowEvent e) {
      this.caller("windowClosed", e);
   }

   public void windowIconified(WindowEvent e) {
      this.caller("windowIconified", e);
   }

   public void windowDeiconified(WindowEvent e) {
      this.caller("windowDeiconified", e);
   }

   public void windowActivated(WindowEvent e) {
      this.caller("windowActivated", e);
   }

   public void windowDeactivated(WindowEvent e) {
      this.caller("windowDeactivated", e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 16 ms
	
	Decompiled with FernFlower.
*/