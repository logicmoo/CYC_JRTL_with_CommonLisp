package com.franz.jlinker;

import java.awt.Checkbox;
import java.awt.CheckboxMenuItem;
import java.awt.Choice;
import java.awt.ItemSelectable;
import java.awt.List;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class JLItemListener implements ItemListener {
   private Object handle;

   public static synchronized void addTo(Checkbox comp) {
      JLItemListener l = new JLItemListener();
      l.handle = comp;
      comp.addItemListener(l);
   }

   public static synchronized void addTo(CheckboxMenuItem comp) {
      JLItemListener l = new JLItemListener();
      l.handle = comp;
      comp.addItemListener(l);
   }

   public static synchronized void addTo(Choice comp) {
      JLItemListener l = new JLItemListener();
      l.handle = comp;
      comp.addItemListener(l);
   }

   public static synchronized void addTo(ItemSelectable comp) {
      JLItemListener l = new JLItemListener();
      l.handle = comp;
      comp.addItemListener(l);
   }

   public static synchronized void addTo(List comp) {
      JLItemListener l = new JLItemListener();
      l.handle = comp;
      comp.addItemListener(l);
   }

   public void itemStateChanged(ItemEvent e) {
      String[] s = new String[]{e.paramString(), e.getItem().toString()};
      int[] l = new int[]{e.getStateChange() == 1 ? 1 : 0};
      LispCall.dispatchEvent("itemStateChanged", this.handle, s, l);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 14 ms
	
	Decompiled with FernFlower.
*/