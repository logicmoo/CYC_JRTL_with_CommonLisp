package com.franz.jlinker;

public class JLinkerPortException extends JLinkerException {
   private static final long serialVersionUID = 1L;

   JLinkerPortException(int timeout) {
      super("Failed to obtain port in " + timeout + " milliseconds.");
   }

   JLinkerPortException(String where) {
      super(where);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 4 ms
	
	Decompiled with FernFlower.
*/