package com.franz.jlinker;

public abstract class JavaLinkCommon {
   private static int version = 7001011;

   public static int version() {
      return version;
   }

   public static Object[] newGate() {
      return JLCommon.lispJavaConnection.newGateOp();
   }

   public static String testGate(Object[] gate) {
      return JLCommon.lispJavaConnection.testGateOp(gate);
   }

   public static Object[] lispValues(Object res, String called, int min, int max, boolean firstRefP) {
      return JLCommon.lispJavaConnection.lispValuesOp(res, called, min, max, firstRefP);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 10 ms
	
	Decompiled with FernFlower.
*/