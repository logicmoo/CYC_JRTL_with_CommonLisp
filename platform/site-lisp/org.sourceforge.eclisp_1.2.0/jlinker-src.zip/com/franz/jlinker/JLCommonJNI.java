package com.franz.jlinker;

public class JLCommonJNI extends JLCommon {
   public Object[] lispValuesOp(Object res, String called, int min, int max, boolean firstRefP) {
      return new Object[0];
   }

   public int sendRegisteredEvent(String ev, Object target, String[] s, int[] l, int timeout) {
      int h = JLCommon.getSObHandle(target);
      return h == 0 ? 0 : LispCallJNI.callLispWithEvent(ev, h, s, l);
   }

   void shutdown() {
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 8 ms
	
	Decompiled with FernFlower.
*/