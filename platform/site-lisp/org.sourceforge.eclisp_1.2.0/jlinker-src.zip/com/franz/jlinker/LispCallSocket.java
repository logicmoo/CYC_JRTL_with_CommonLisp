package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;
import com.franz.jlinker.LispCall.JlinkerState;

class LispCallSocket extends LispCallImplementation {
   static Class<?> opclass = TranStruct.class;
   LispCall lci;

   static {
      try {
         opclass = Class.forName("com.franz.jlinker.TranStruct");
      } catch (ClassNotFoundException var1) {
         ;
      }

   }

   Class<?> getOpClass() {
      return opclass;
   }

   LispCallImplementation builder(LispCall parent, String op) {
      LispCallSocket x = new LispCallSocket();
      x.lci = parent;
      if (!op.equals("")) {
         parent.lispOp = new TranStruct(op);
      }

      return x;
   }

   void setOp(String op) {
      this.setOp((Object)(new TranStruct(op)));
   }

   void setOp(Object op) {
      this.lci.lispOp = op;
      if (this.lci.state == 0) {
         this.lci.state = 1;
      }

   }

   synchronized int addArgWrapped(TranStruct x) {
      if (this.lci.state != 1) {
         throw new IllegalArgumentException("Wrong state");
      } else {
         return this.lci.newHolder(x);
      }
   }

   synchronized int addArg(int x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(short x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(byte x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(long x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(boolean x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(int[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(short[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(byte[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(String x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(String[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(double x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(float x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(double[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(float[] x) {
      return this.addArgWrapped(new TranStruct(x));
   }

   synchronized int addArg(Object x) {
      return opclass.isInstance(x) ? this.addArgWrapped((TranStruct)x) : this.addArgWrapped(TranStruct.newTrS(x));
   }

   synchronized int addSymbol(String x) {
      return this.addArgWrapped(TranStruct.newTrSym(x, "", 0));
   }

   synchronized int addSymbol(String x, String pk) {
      return this.addArgWrapped(TranStruct.newTrSym(x, pk, 0));
   }

   synchronized int addSymbol(String x, String pk, int act) {
      return this.addArgWrapped(TranStruct.newTrSym(x, pk, act));
   }

   synchronized void assemble(String where) {
      if (this.lci.state != 1) {
         this.lci.throwWrongState(where, "");
      }

      TranStruct[] argarray = new TranStruct[this.lci.count];
      this.lci.args = argarray;

      for(int i = 0; i < this.lci.count; ++i) {
         argarray[this.lci.count - i - 1] = (TranStruct)this.lci.chain.arg;
         this.lci.chain = this.lci.chain.next;
      }

      this.lci.count = 0;
      this.lci.state = 2;
   }

   synchronized int call() throws JLinkerLispThrow, JLinkerInvokeException, JLinkerLispException, JLinkerPortException {
      if (!this.isJlinkerState(JlinkerState.READY)) {
         throw new IllegalStateException("Jlinker connection is not ready for a call.");
      } else {
         int timeout = this.lci.portTimeout;
         if (timeout < 0) {
            timeout = LispCall.defaultPortTimeout;
         }

         if (timeout < 0) {
            timeout = LispCall.replyTimeout + 1000;
         }

         if (this.lci.state == 1) {
            this.assemble("call");
         }

         if (this.lci.state != 2) {
            this.lci.throwWrongState("call", "");
         }

         TranStruct[] resarray = JLSocketClient.invokeInLispWithExceptions(this.lci.callStyle, (TranStruct)this.lci.lispOp, (TranStruct[])this.lci.args, timeout);
         this.lci.res = resarray;
         if (!this.lci.retain) {
            this.lci.args = null;
         }

         if (this.lci.callStyle >= 3) {
            this.lci.waitref = resarray[1];
            this.lci.res = null;
            this.lci.state = 4;
            return 0;
         } else {
            this.lci.waitref = null;
            this.lci.state = 3;
            return resarray.length == 0 ? 0 : resarray[0].intValue();
         }
      }
   }

   synchronized TranStruct getValue(int i) {
      TranStruct[] resarray = (TranStruct[])this.lci.res;
      TranStruct r = resarray[i + 1];
      if (r == null) {
         this.lci.throwWrongState("getValue", "when value already retrieved once");
      }

      if (!this.lci.retain) {
         resarray[i + 1] = null;
      }

      return r;
   }

   
   @Deprecated
   int typeOf(JLWrapper vv) {
      TranStruct v = (TranStruct)vv;
      if (v.nullP()) {
         return LispCall.RES_NULL;
      } else if (v.booleanP()) {
         return LispCall.RES_BOOLEAN;
      } else if (v.longP()) {
         return LispCall.RES_LONG;
      } else if (v.integerP()) {
         return LispCall.RES_INTEGER;
      } else if (v.realP()) {
         return LispCall.RES_REAL;
      } else if (JLSocketClient.errorP(v)) {
         return LispCall.RES_ERROR;
      } else if (v.symbolP()) {
         return LispCall.RES_SYMBOL;
      } else if (v.stringP()) {
         return LispCall.RES_STRING;
      } else {
         Object w = v.pointerValue();
         if (w == v) {
            return LispCall.RES_LISP_POINTER;
         } else {
            String s = w.getClass().getName();
            if (s.equals("[I")) {
               return LispCall.RES_INT_ARRAY;
            } else if (s.equals("[D")) {
               return LispCall.RES_DOUBLE_ARRAY;
            } else {
               return s.equals("[Ljava.lang.String;") ? LispCall.RES_STRING_ARRAY : LispCall.RES_JAVA_POINTER;
            }
         }
      }
   }

   TypeCode getTypeCode(TranStruct v) {
      if (v.nullP()) {
         return TypeCode.NULL;
      } else if (v.booleanP()) {
         return TypeCode.BOOL;
      } else if (v.longP()) {
         return TypeCode.LONG;
      } else if (v.integerP()) {
         return TypeCode.INT;
      } else if (v.realP()) {
         return TypeCode.DOUBLE;
      } else if (JLSocketClient.errorP(v)) {
         return TypeCode.ERROR;
      } else if (v.symbolP()) {
         return TypeCode.SYMBOL;
      } else if (v.stringP()) {
         return TypeCode.STRING;
      } else {
         Object w = v.pointerValue();
         if (w == v) {
            return TypeCode.LISP_POINTER;
         } else {
            String s = w.getClass().getName();
            if (s.equals("[I")) {
               return TypeCode.INT_ARRAY;
            } else if (s.equals("[D")) {
               return TypeCode.DOUBLE_ARRAY;
            } else {
               return s.equals("[Ljava.lang.String;") ? TypeCode.STRING_ARRAY : TypeCode.JAVA_POINTER;
            }
         }
      }
   }

   
   @Deprecated
   synchronized int typeOf(int i) {
      TranStruct[] resarray = (TranStruct[])this.lci.res;
      return i + 1 >= resarray.length ? LispCall.RES_MISSING : this.typeOf(this.getValue(i));
   }

   TypeCode getTypeCode(int i) {
      return this.getTypeCode(this.getValue(i));
   }

   TranStruct getValueTr(int i) {
      return this.getValue(i);
   }

   synchronized int intValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.integerP()) {
         return v.intValue();
      } else {
         throw new UnsupportedOperationException("intValue of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized long longValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.longP()) {
         return v.longValue();
      } else if (v.integerP()) {
         return (long)v.intValue();
      } else {
         throw new UnsupportedOperationException("longValue of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized double doubleValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.realP()) {
         return v.doubleValue();
      } else {
         throw new UnsupportedOperationException("doubleValue of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized boolean booleanValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.booleanP()) {
         return v.boolValue();
      } else {
         throw new UnsupportedOperationException("booleanValue of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized String stringValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.stringP()) {
         return v.stringValue();
      } else {
         throw new UnsupportedOperationException("stringValue of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized int[] intArrayValue(int i) {
      TranStruct v = this.getValueTr(i);
      int s = this.typeOf(v);
      if (s == LispCall.RES_INT_ARRAY) {
         return (int[])v.pointerValue();
      } else {
         throw new UnsupportedOperationException("intArrayValue of " + LispCall.nameOfType(s));
      }
   }

   synchronized String[] stringArrayValue(int i) {
      TranStruct v = this.getValueTr(i);
      int s = this.typeOf(v);
      if (s == LispCall.RES_STRING_ARRAY) {
         return (String[])v.pointerValue();
      } else {
         throw new UnsupportedOperationException("stringArrayValue of " + LispCall.nameOfType(s));
      }
   }

   synchronized double[] doubleArrayValue(int i) {
      TranStruct v = this.getValueTr(i);
      int s = this.typeOf(v);
      if (s == LispCall.RES_DOUBLE_ARRAY) {
         return (double[])v.pointerValue();
      } else {
         throw new UnsupportedOperationException("doubleArrayValue of " + LispCall.nameOfType(s));
      }
   }

   synchronized Object objectValue(int i) {
      TranStruct v = this.getValueTr(i);
      if (JLSocketClient.pointerP(v)) {
         Object w = v.pointerValue();
         if (w != v) {
            return w;
         }
      }

      throw new UnsupportedOperationException("objectValue of " + LispCall.nameOfType(this.typeOf(v)));
   }

   synchronized String symbolName(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.symbolP()) {
         return v.symbolName();
      } else {
         throw new UnsupportedOperationException("symbolName of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized String symbolPackage(int i) {
      TranStruct v = this.getValueTr(i);
      if (v.symbolP()) {
         return v.symbolPackage();
      } else {
         throw new UnsupportedOperationException("symbolPackage of " + LispCall.nameOfType(this.typeOf(v)));
      }
   }

   synchronized String lispType(int i) {
      TranStruct v = this.getValueTr(i);
      return JLSocketClient.pointerP(v) && v == v.pointerValue() ? v.stringValue() : LispCall.nameOfType(this.typeOf(v));
   }

   synchronized int query(boolean doquery, boolean dofetch) {
      TranStruct[] resarray = null;
      if (this.lci.res != null) {
         resarray = (TranStruct[])this.lci.res;
      }

      switch(this.lci.state) {
      case 0:
      case 1:
      case 2:
      case 6:
         return -100;
      case 3:
         if (resarray == null) {
            return -99;
         } else {
            if (resarray.length == 0) {
               return 0;
            }

            return resarray[0].intValue();
         }
      case 4:
      case 5:
         if (this.lci.waitref == null) {
            return -100;
         } else {
            if (doquery && this.lci.state == 4) {
               resarray = this.peekWaitres("cl:car");
               this.lci.res = resarray;
               if (resarray == null) {
                  return -97;
               }

               int rc = resarray[1].intValue();
               if (rc >= 0) {
                  this.lci.waitres = rc;
                  this.lci.state = 5;
               } else if (rc == -98) {
                  this.lci.waitres = rc;
                  this.lci.res = null;
                  this.lci.state = 5;
               } else if (rc == -99) {
                  this.lci.res = null;
                  this.lci.state = 3;
                  return -99;
               }
            }

            if (dofetch && this.lci.state == 5) {
               resarray = this.peekWaitres("net.jlinker::jl-async-results");
               this.lci.res = resarray;
               if (resarray == null) {
                  return -97;
               } else {
                  this.lci.state = 3;
                  if (resarray.length == 0) {
                     return 0;
                  }

                  return resarray[0].intValue();
               }
            } else {
               if (this.lci.state == 5) {
                  if (doquery) {
                     return this.lci.waitres;
                  }

                  return -11;
               }

               return -10;
            }
         }
      default:
         return -100;
      }
   }

   synchronized String queryAsyncName() {
      if (this.lci.waitref == null) {
         return null;
      } else if (this.lci.state != 4) {
         return null;
      } else {
         TranStruct[] resarray = this.peekWaitres("cl:second");
         if (resarray == null) {
            return null;
         } else {
            return resarray[0].intValue() == 0 ? null : resarray[1].stringValue();
         }
      }
   }

   TranStruct[] peekWaitres(String opName) {
      int timeout = 2 + LispCall.replyTimeout;
      TranStruct op = new TranStruct(opName);
      TranStruct[] r = null;
      TranStruct[] args = new TranStruct[]{(TranStruct)this.lci.waitref};

      try {
         r = JLSocketClient.invokeInLispWithExceptions(2, op, args, timeout);
      } catch (Exception var7) {
         this.lci.queryError = var7;
      }

      return r;
   }

   synchronized void close() {
   }

   synchronized void reset() {
   }

   synchronized void setArgWrapped(int i, JLWrapper aa) {
      TranStruct arg = (TranStruct)aa;
      switch(this.lci.state) {
      case 1:
         this.assemble("setArg");
      case 2:
         break;
      default:
         this.lci.throwWrongState("setArg", "");
      }

      ((TranStruct[])this.lci.args)[i] = arg;
   }

   synchronized void setArg(int i, boolean arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, int arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, byte arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, short arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, long arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, double arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, float arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, String arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, Object arg) {
      if (opclass.isInstance(arg)) {
         this.setArgWrapped(i, (JLWrapper)arg);
      } else {
         this.setArgWrapped(i, TranStruct.newTrS(arg));
      }

   }

   synchronized void setArg(int i, int[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, byte[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, short[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, double[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, float[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setArg(int i, String[] arg) {
      this.setArgWrapped(i, new TranStruct(arg));
   }

   synchronized void setSymbol(int i, String name) {
      this.setArg(i, (Object)TranStruct.newTrSym(name, "", 0));
   }

   synchronized void setSymbol(int i, String name, String pk) {
      this.setArg(i, (Object)TranStruct.newTrSym(name, pk, 0));
   }

   synchronized void setSymbol(int i, String name, String pk, int act) {
      this.setArg(i, (Object)TranStruct.newTrSym(name, pk, act));
   }

   int mayCall() {
      return 2;
   }

   boolean isJlinkerState(JlinkerState target) {
      return JLCommonSocket.isJlinkerState(target);
   }

   boolean isJlinkerState(long delay, JlinkerState... targets) {
      long sleep;
      for(; delay >= 0L; delay -= sleep) {
         JlinkerState[] var7 = targets;
         int var6 = targets.length;

         for(int var5 = 0; var5 < var6; ++var5) {
            JlinkerState t = var7[var5];
            if (this.isJlinkerState(t)) {
               return true;
            }
         }

         if (0L == delay) {
            return false;
         }

         sleep = delay < 100L ? delay : 100L;

         try {
            Thread.sleep(sleep);
         } catch (InterruptedException var8) {
            ;
         }
      }

      return false;
   }

   long discardInLisp(Object... x) {
      return JLSocketClient.discardInLisp(x);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 132 ms
	 @deprecated 
	@deprecated 
	Decompiled with FernFlower.
*/