package com.franz.jlinker;

import com.franz.jlinker.JavaLinkDist.LispException;

public class JLinkerLispException extends LispException {
   private static final long serialVersionUID = 1L;

   JLinkerLispException(String y, Object l) {
      super(y, l);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 3 ms
	
	Decompiled with FernFlower.
*/