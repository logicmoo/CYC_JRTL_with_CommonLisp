package com.franz.jlinker;

import com.franz.jlinker.Transport.ERR;
import com.franz.jlinker.Transport.Handler;
import com.franz.jlinker.Transport.Listener;
import com.franz.jlinker.Transport.PortNotifier;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.UUID;

public class Transport extends JLTransportCodes {
   public static final String lispHomeName = "Lisp";
   public static int varInt = 0;
   public static int exData = 0;
   private boolean kindServer = false;
   private boolean kindClient = false;
   int state = -1;
   int oneWay = 0;
   public static final int ERR_PORT_IO = -112;
   public static final int ERR_TIMEOUT = -113;
   Socket socket;
   InputStream inStream;
   OutputStream outStream;
   byte[] buffer = new byte[512];
   int endpos = 0;
   Object[] iData;
   Thread softLock = null;
   static int debugClient = 0;
   static int debugServer = 0;
   public static final Object staticLock = new Object();
   static boolean makeFlag = false;
   public static PortNotifier notifier = null;
   public static long timeout = 86400000L;
   String doServerDisconnect = null;
   final int doNotHaveCode = 1000000;
   int haveCode = 1000000;
   Throwable lastReadError = null;
   static String idString = null;
   public static int verifiedConnect = 1;
   static final byte ID_CODE0 = 16;
   static final byte ID_CODE1 = 32;
   static final byte ID_CODE3 = 48;
   static final int minimumProtocolLevel = 0;
   static final int verifiedProtocolLevel = 1;

   public static String debug(int cl, int sr) {
      int oldc = debugClient;
      if (cl >= 0) {
         debugClient = cl;
      }

      int olds = debugServer;
      if (sr >= 0) {
         debugServer = sr;
      }

      return "Client was " + oldc + " now " + debugClient + "  Server was " + olds + " now " + debugServer;
   }

   boolean debugP(int level) {
      return level <= (this.kindServer ? debugServer : debugClient);
   }

   Transport(String k, Socket s) throws IOException {
      if (k.equals("server")) {
         this.kindServer = true;
      } else {
         this.kindClient = true;
      }

      this.socket = s;
      this.socket.setSoTimeout(LispCall.readTimeout);
      this.inStream = new BufferedInputStream(this.socket.getInputStream());
      this.outStream = new BufferedOutputStream(this.socket.getOutputStream());
      this.state = 0;
      this.softLock = null;
   }

   private void printKind(int level, String msg) {
      if (this.debugP(level)) {
         System.out.println((this.kindServer ? "server" : "client") + msg);
      }

   }

   static File advertFile(String file, String host, int port) throws IOException {
      JLCommon.dsprint("Transport.advertFile: Writing file " + file + " host:port=" + host + ":" + port);
      File fl = new File(file);
      FileWriter prt = null;

      try {
         prt = new FileWriter(fl);
         if (host.equals("")) {
            host = "localhost";
         }

         String pn = host + " " + port + "\n";
         prt.write(pn, 0, pn.length());
      } finally {
         if (prt != null) {
            prt.close();
         }

      }

      return fl;
   }

   public static Object makeClientDataPort(Listener listener) {
      try {
         Object var1 = staticLock;
         synchronized(staticLock) {
            if (makeFlag) {
               return "makeClientDataPort  is busy, try again later";
            }

            makeFlag = true;
         }

         ServerSocket factory = listener.factory;
         Object res = null;

         try {
            if (notifier != null) {
               notifier.rePort(factory.getLocalPort());
            }

            factory.setSoTimeout(1000);
            Socket client = null;
            long time = 0L;

            while(client == null) {
               try {
                  client = factory.accept();
               } catch (SocketTimeoutException var14) {
                  if (time > timeout) {
                     factory.close();
                     return "cancelled";
                  }

                  time += 1000L;
               }
            }

            client.setTcpNoDelay(true);
            Transport tr = new Transport("client", client);
            Object vr = tr.verifyConnection(true, true);
            if (vr != null && vr != tr) {
               res = "Failed verify.";
            } else {
               res = tr;
            }
         } catch (Exception var15) {
            res = var15;
         }

         Object var9 = res;
         return var9;
      } finally {
         makeFlag = false;
      }
   }

   public static Listener makeListener(int port) throws IOException {
      ServerSocket factory = null;
      factory = new ServerSocket();
      factory.setReuseAddress(true);
      factory.bind(new InetSocketAddress(port));
      return new Listener(factory);
   }

   public static Transport acceptDataPort(Listener h, String kind, boolean closeListener) throws Exception {
      Transport var10;
      try {
         Object var3 = staticLock;
         synchronized(staticLock) {
            if (makeFlag) {
               throw new IllegalStateException("makeServerDataPort is busy, try again later");
            }

            makeFlag = true;
         }

         var3 = null;

         try {
            ServerSocket factory = h.factory;
            factory.setSoTimeout(1000);
            Socket client = null;
            long time = 0L;

            while(client == null) {
               try {
                  client = factory.accept();
               } catch (SocketTimeoutException var20) {
                  if (h.cancel || time > timeout) {
                     factory.close();
                     throw new IllegalStateException("cancelled");
                  }

                  time += 1000L;
               }
            }

            client.setTcpNoDelay(true);
            Transport tr = new Transport(kind, client);
            Object vr = tr.verifyConnection(false, true);
            if (vr != null && vr != tr) {
               throw new IllegalStateException("Failed verify");
            }

            var10 = tr;
         } finally {
            if (closeListener) {
               h.close();
            }

         }
      } finally {
         makeFlag = false;
      }

      return var10;
   }

   public static Object connectViaFile(String file) {
      Object var13;
      try {
         Object var1 = staticLock;
         synchronized(staticLock) {
            if (makeFlag) {
               return "connectToServer is busy, try again later";
            }

            makeFlag = true;
         }

         FileReader str = null;
         Transport connection = null;

         try {
            File fl = new File(file);
            str = new FileReader(fl);
            char[] bf = new char[100];
            int b = false;
            int port = false;
            int b = str.read(bf, 0, 100);
            str.close();
            String s = new String(bf, 0, b);
            int n = s.indexOf(" ", 0);
            if (n < 1) {
               throw new IOException("Ill-formed file");
            }

            String host;
            for(host = s.substring(0, n); s.startsWith(" ", n); ++n) {
               ;
            }

            int port = Integer.parseInt(s.substring(n, b).trim());
            Socket server = new Socket(host, port);
            server.setTcpNoDelay(true);
            connection = new Transport("client", server);
            Object vr = connection.verifyConnection(true, false);
            if (vr != null && vr != connection) {
               return "Failed verify.";
            }

            var13 = new Object[]{new Integer(port), connection, host};
         } catch (Exception var34) {
            var13 = var34;
            return var13;
         } finally {
            if (str != null) {
               try {
                  str.close();
               } catch (Exception var32) {
                  ;
               }
            }

         }
      } finally {
         makeFlag = false;
      }

      return var13;
   }

   public static Object connectToHostPort(String host, int port, String kind, boolean initialPort) {
      Transport var16;
      try {
         Object var4 = staticLock;
         synchronized(staticLock) {
            if (makeFlag) {
               return "connectToServer is busy, try again later";
            }

            makeFlag = true;
         }

         var4 = null;

         try {
            Socket server = new Socket(host, port);
            server.setTcpNoDelay(true);
            Transport connection = new Transport(kind, server);
            Object vr = connection.verifyConnection(initialPort, false);
            if (vr != null && vr != connection) {
               String var17 = "Failed verify " + vr;
               return var17;
            }

            var16 = connection;
         } catch (Exception var13) {
            Exception var8 = var13;
            return var8;
         }
      } finally {
         makeFlag = false;
      }

      return var16;
   }

   public synchronized void shutdown(Object reason) {
      JLCommon.dsprint("Port shutdown - " + reason + " " + this);

      try {
         this.socket.close();
      } catch (IOException var3) {
         ;
      }

      if (this.doServerDisconnect == null) {
         this.doServerDisconnect = "shutdown: " + reason;
      }

   }

   public synchronized boolean disconnect() {
      switch(this.state) {
      case -1:
         return false;
      case 0:
         if (this.kindClient) {
            this.message(-1, 63, true);

            try {
               JLCommon.sleep(100L, "Transport.disconnect");
            } catch (Exception var3) {
               ;
            }
         }
      default:
         try {
            this.state = -1;
            this.socket.close();
            return true;
         } catch (Exception var2) {
            return false;
         }
      }
   }

   public Object doServer(Handler handler) {
      Object rep = "";
      this.oneWay = 0;

      while(this.state == 0) {
         int code;
         try {
            code = this.streamInCode(LispCall.requestTimeout);
         } catch (SocketException var5) {
            return "Socket error " + var5;
         }

         switch(code) {
         case 15:
            this.oneWay = 1;
            break;
         case 17:
            rep = this.doServerMessage(handler);
            this.oneWay = 0;
            break;
         case 18:
            rep = this.doServerRequest(handler);
            this.oneWay = 0;
            break;
         case 19:
            rep = this.doServerInvoke();
            break;
         case 20:
            rep = this.doServerArglist(handler);
            break;
         case 63:
            this.disconnect();
            rep = "Disconnected";
            break;
         default:
            rep = "Bad code " + code;
         }

         if (!this.stringEqual("", rep)) {
            return rep;
         }

         if (this.doServerDisconnect != null) {
            return this.doServerDisconnect;
         }
      }

      return "Bad server state";
   }

   boolean stringEqual(Object x, Object y) {
      return x instanceof String && y instanceof String ? ((String)x).equals(y) : false;
   }

   int streamInInt() throws IOException {
      return (Integer)this.streamInValue(true);
   }

   private Object doServerMessage(Handler handler) {
      int res = false;
      boolean var3 = true;

      int m;
      try {
         m = this.portInInt();
      } catch (Exception var6) {
         m = -1;
      }

      if (m <= 0) {
         return "Bad message code " + m;
      } else {
         res = true;

         int res;
         try {
            res = handler.doMessage(m);
         } catch (Exception var7) {
            if (this.oneWay == 0) {
               this.respond(var7);
            }

            if (this.debugP(1)) {
               return "Message " + m + " throws " + var7;
            }

            return "";
         }

         try {
            if (this.oneWay == 0) {
               this.respond(res);
            }

            return "";
         } catch (Exception var5) {
            return "Respond to " + m + " throws " + var5;
         }
      }
   }

   private Object doServerRequest(Handler handler) {
      Object rep = "No handler";
      String home = "";
      byte kind = 0;

      Object rep;
      int kind;
      try {
         home = (String)this.streamInValue(true);
         kind = this.streamInInt();
         int[] nums = (int[])this.streamInValue(true);
         String[] strings = (String[])this.streamInValue(true);
         double[] reals = (double[])this.streamInValue(true);
         rep = handler.doRequest(home, kind, nums, strings, reals);
      } catch (Exception var10) {
         if (this.oneWay == 0) {
            this.respond(var10);
         }

         return "Request " + home + " " + kind + " throws " + var10;
      }

      try {
         if (this.oneWay == 0) {
            this.reply(rep);
         }

         return "";
      } catch (Exception var9) {
         return "Reply to " + home + " " + kind + " throws " + var9;
      }
   }

   private Object doServerInvoke() {
      int length = -1;
      TranStruct[] idt = null;

      try {
         length = this.portInInt();
      } catch (Exception var4) {
         ;
      }

      if (length < 0) {
         return "Bad invoke length " + length;
      } else {
         idt = new TranStruct[length];
         if (this.debugP(2)) {
            System.out.println("Transport.doInvoke length=" + length);
         }

         this.iData = new Object[]{new Integer(0), new Integer(length), idt};
         return "";
      }
   }

   private Object doServerArglist(Handler handler) {
      if (this.iData == null) {
         return "bad server state";
      } else {
         Object[] ida = this.iData;
         int inext = (Integer)ida[0];
         int ilen = (Integer)ida[1];
         Object idu = ida[2];
         TranStruct[] idua = (TranStruct[])idu;
         boolean var7 = true;

         try {
            int index = this.portInInt();
            if (index != inext) {
               return "protocol error";
            }

            idua[index] = this.newTS(index, "Transport.doInvoke arg=");
            ++inext;
         } catch (Exception var13) {
            return "doInvokeArglist throws " + var13;
         }

         if (inext == ilen) {
            if (this.debugP(2)) {
               System.out.println("Transport.doInvoke calling");
            }

            TranStruct[] rdata;
            try {
               rdata = handler.doInvoke(idua);
            } catch (Exception var11) {
               JLCommon.dsprint("Exception after " + TranStruct.show(idua));
               if (JLCommon.sdebug) {
                  var11.printStackTrace();
               }

               if (this.oneWay == 0) {
                  this.respond(var11);
               }

               return "doInvoke throws " + var11;
            }

            if (this.debugP(2)) {
               System.out.println("Transport.doInvoke returns");
            }

            if (this.oneWay == 0) {
               try {
                  int rdlength = rdata.length;
                  if (this.debugP(2)) {
                     System.out.println("Transport.doInvoke result length=" + rdlength);
                  }

                  this.streamOutCode(35);
                  this.portOut(rdlength);
                  this.streamOutFlush();

                  for(int i = 0; i < rdlength; ++i) {
                     this.sendResultPart(i, (TranStruct)rdata[i]);
                  }
               } catch (Exception var12) {
                  return "sendResultPart throws " + var12;
               }
            } else {
               this.oneWay = 0;
            }

            this.iData = null;
         } else {
            ida[0] = new Integer(inext);
         }

         return "";
      }
   }

   TranStruct newTS(int index, String where) throws IOException {
      String home = (String)this.streamInValue(true);
      int kind = this.streamInInt();
      int[] nums = (int[])this.streamInValue(true);
      String[] strings = (String[])this.streamInValue(true);
      double[] reals = (double[])this.streamInValue(true);
      if (this.debugP(2)) {
         System.out.println(where + index);
      }

      TranStruct ts = new TranStruct(home, kind, nums, strings, reals);
      switch(57344 & kind) {
      case 8192:
      case 16384:
      case 24576:
         ts.setExdata(this.streamInValue(true));
      default:
         return ts;
      }
   }

   synchronized String grabSoftLock(String from) {
      Thread cur = Thread.currentThread();
      if (this.softLock == null) {
         this.softLock = cur;
      } else {
         if (this.softLock == cur) {
            return "Recursive call to" + from;
         }

         while(this.softLock != null) {
            try {
               this.wait();
            } catch (Exception var4) {
               ;
            }
         }

         this.softLock = cur;
      }

      return "";
   }

   synchronized void dropSoftLock() {
      if (this.softLock != null) {
         this.softLock = null;
         this.notifyAll();
      }
   }

   Object message(int messageValue, int code, boolean ignore) {
      String var11;
      try {
         String gv = this.grabSoftLock("message()");
         if (gv.length() <= 0) {
            int old = this.state;
            int ret = 0;
            Object eret = "";
            Object eret0 = eret;

            try {
               switch(this.state) {
               case 0:
                  this.state = 1;
                  if (ignore) {
                     ret = this.streamOutCode(15);
                  }

                  if (ret >= 0) {
                     ret = this.streamOutCode(code);
                  }

                  if (ret >= 0 && messageValue >= 0) {
                     ret = this.portOut(messageValue);
                  }

                  if (ret >= 0) {
                     ret = this.streamOutFlush();
                  }

                  if (ret >= 0 && !ignore) {
                     eret = this.responseIn();
                  }
                  break;
               default:
                  ret = ERR.PORT_STATE.code();
               }
            } finally {
               this.state = old;
            }

            if (eret == eret0) {
               Integer var19 = new Integer(ret);
               return var19;
            }

            Object var18 = eret;
            return var18;
         }

         var11 = gv;
      } finally {
         this.dropSoftLock();
      }

      return var11;
   }

   public Object request(String home, int type, int[] nums, String[] strings, double[] reals, boolean ignore) {
      Object[] var14;
      try {
         String gv = this.grabSoftLock("request()");
         if (gv.length() > 0) {
            var14 = new Object[]{ERR.BUSY, gv};
            return var14;
         }

         int old = this.state;
         int rc = 0;
         if (this.kindClient) {
            try {
               switch(this.state) {
               case 0:
                  this.state = 3;
                  if (ignore) {
                     rc = this.streamOutCode(15);
                  }

                  if (rc >= 0) {
                     rc = this.streamOutCode(18);
                  }

                  if (rc >= 0) {
                     rc = this.streamOut(home);
                  }

                  if (rc >= 0) {
                     rc = this.streamOut(type);
                  }

                  if (rc >= 0) {
                     rc = this.streamOut(nums);
                  }

                  if (rc >= 0) {
                     rc = this.streamOutStrings(home, strings);
                  }

                  if (rc >= 0) {
                     rc = this.streamOut(reals);
                  }

                  if (rc >= 0) {
                     if (!ignore) {
                        Object res = this.replyIn();
                        Object var12 = res;
                        return var12;
                     }

                     return null;
                  }
               default:
                  rc = ERR.PORT_STATE.code();
               }
            } finally {
               this.state = old;
            }

            var14 = new Object[]{ERR.inverse(rc), "request", inverse(this.state)};
            return var14;
         }

         var14 = new Object[]{ERR.PORT_CLASS, "request"};
      } finally {
         this.dropSoftLock();
      }

      return var14;
   }

   int streamOutStrings(String home, String[] strings) {
      return home.equalsIgnoreCase("Lisp") ? this.streamOut(new String[0]) : this.streamOut(strings);
   }

   public Object invoke(TranStruct[] args, boolean ignore) {
      Object[] var10;
      try {
         String gv = this.grabSoftLock("invoke()");
         if (gv.length() > 0) {
            var10 = new Object[]{ERR.BUSY, gv};
            return var10;
         }

         int old = this.state;
         int rc = 0;
         if (!this.kindClient) {
            var10 = new Object[]{ERR.PORT_CLASS, "invoke"};
            return var10;
         }

         try {
            switch(this.state) {
            case 0:
               this.state = 5;
               if (ignore) {
                  rc = this.streamOutCode(15);
               }

               if (rc >= 0) {
                  rc = this.streamOutCode(19);
               }

               if (rc >= 0) {
                  rc = this.portOut(args.length);
               }

               if (rc >= 0) {
                  rc = this.streamOutFlush();
               }

               if (rc >= 0) {
                  for(int i = 0; i < args.length; ++i) {
                     if (args[i] != null && rc >= 0) {
                        rc = this.invokeArg(i, args[i]);
                     }
                  }
               }

               Object var8;
               if (ignore) {
                  var8 = new Object[0];
                  return var8;
               }

               if (rc >= 0) {
                  Object v = this.resultIn();
                  this.printKind(1, " invoke => isArrayLen:" + TranStruct.getArrayLength(v) + " isArrayOfLen:" + TranStruct.getObjectArrayLength(v) + "  " + v);
                  var8 = v;
                  return var8;
               }
               break;
            default:
               rc = ERR.PORT_STATE.code();
            }
         } finally {
            this.state = old;
         }

         var10 = new Object[]{ERR.inverse(rc), "invoke", inverse(this.state)};
      } finally {
         this.dropSoftLock();
      }

      return var10;
   }

   int invokeArg(int i, TranStruct arg) {
      int rc;
      switch(this.state) {
      case 5:
         rc = this.sendTS(20, i, arg, "invokeArg");
         break;
      default:
         rc = ERR.PORT_STATE.code();
      }

      return rc;
   }

   int sendTS(int code, int i, TranStruct arg, String where) {
      if (this.debugP(2)) {
         System.out.println(where + i);
      }

      int rc = this.streamOutCode(code);
      if (rc >= 0) {
         rc = this.portOut(i);
      }

      if (rc >= 0) {
         rc = this.streamOut(arg.home);
      }

      if (rc >= 0) {
         rc = this.streamOut(arg.type);
      }

      if (rc >= 0) {
         rc = this.streamOut(arg.nums);
      }

      if (rc >= 0) {
         rc = this.streamOutStrings(arg.home, arg.strings);
      }

      if (rc >= 0) {
         rc = this.streamOut(arg.reals);
      }

      Object ex = arg.getExdata();
      switch(arg.type & 57344) {
      case 0:
      default:
         break;
      case 8192:
         if (ex == null) {
            ex = new byte[0];
         }

         this.streamOut((byte[])ex);
         break;
      case 16384:
         if (ex == null) {
            ex = new short[0];
         }

         this.streamOut((short[])ex);
         break;
      case 24576:
         if (ex == null) {
            ex = new float[0];
         }

         this.streamOut((float[])ex);
      }

      this.streamOutFlush();
      return rc;
   }

   public synchronized int respond(int value) {
      this.streamOutCode(33);
      this.portOut(value);
      this.streamOutFlush();
      return 0;
   }

   synchronized int respond(Exception value) {
      this.streamOutCode(62);
      this.portOut(value.toString());
      this.streamOutFlush();
      return 0;
   }

   synchronized int reply(Object value) {
      this.streamOutCode(34);
      this.streamOut(value);
      this.streamOutFlush();
      return 0;
   }

   synchronized int sendResultPart(int i, TranStruct part) {
      return this.sendTS(36, i, part, "Transport.doInvoke resultPart ");
   }

   Object responseIn() {
      int old = this.state;
      int ret = 0;
      Object eret = "";
      Object eret0 = eret;
      if (!this.kindClient) {
         return "responseIn: ERR_PORT_CLASS";
      } else {
         try {
            label81:
            switch(this.state) {
            case 1:
               this.streamOutFlush();
               this.state = 2;

               int code;
               try {
                  code = this.streamInCode(LispCall.replyTimeout);
               } catch (SocketException var15) {
                  String var8 = "responseIn: ERR_SOCKET " + var15;
                  return var8;
               }

               switch(code) {
               case 18:
                  eret = "responseIn: ERR_CALLBACK";
                  break label81;
               case 33:
                  try {
                     ret = this.portInInt();
                  } catch (Exception var14) {
                     eret = "responseIn->portInInt: " + var14;
                  }
                  break label81;
               case 62:
                  try {
                     eret = this.portInString();
                  } catch (Exception var13) {
                     eret = "responseIn->portInString: " + var13;
                  }
                  break label81;
               default:
                  eret = "responseIn: ERR_PROTOCOL" + code;
                  break label81;
               }
            default:
               eret = "responseIn: ERR_PORT_STATE " + this.state;
            }
         } finally {
            this.state = old;
         }

         if (eret == eret0) {
            eret = new Integer(ret);
         }

         this.printKind(1, " responseIn " + eret);
         return eret;
      }
   }

   Object replyIn() {
      int old = this.state;
      Object res = null;
      if (!this.kindClient) {
         return "replyIn: ERR_PORT_CLASS";
      } else {
         try {
            switch(this.state) {
            case 3:
               this.streamOutFlush();
               this.state = 4;

               int code;
               try {
                  code = this.streamInCode(LispCall.replyTimeout);
               } catch (SocketException var13) {
                  String var6 = "replyIn: ERR_SOCKET " + var13;
                  return var6;
               }

               switch(code) {
               case 18:
                  res = "replyIn: ERR_CALLBACK";
                  return res;
               case 34:
                  try {
                     res = this.streamInValue(true);
                  } catch (Exception var11) {
                     res = var11;
                  }

                  this.printKind(1, " replyIn " + res);
                  Object var15 = res;
                  return var15;
               case 62:
                  try {
                     res = this.portInString();
                  } catch (Exception var12) {
                     res = var12;
                  }

                  this.printKind(1, " replyIn Err" + res);
                  return res;
               default:
                  res = "replyIn: ERR_PROTOCOL " + code;
                  return res;
               }
            default:
               res = "replyIn: ERR_PORT_STATE " + this.state;
               return res;
            }
         } finally {
            this.state = old;
         }
      }
   }

   Object resultIn() {
      int old = this.state;
      int code = false;
      if (!this.kindClient) {
         return "resultIn: ERR_PORT_CLASS";
      } else {
         try {
            Object eres;
            switch(this.state) {
            case 5:
               this.streamOutFlush();
               this.state = 6;

               int code;
               try {
                  code = this.streamInCode(LispCall.replyTimeout);
               } catch (SocketException var15) {
                  String var8 = "resultIn: ERR_SOCKET " + var15;
                  return var8;
               }

               switch(code) {
               case -113:
                  eres = "resultIn: ERR_TIMEOUT ";
                  return eres;
               case -112:
                  eres = "resultIn: ERR_PORT_IO " + this.lastReadError;
                  return eres;
               case 18:
                  eres = "resultIn: ERR_CALLBACK";
                  return eres;
               case 35:
                  try {
                     int l = this.portInInt();
                     Object[] res = new Object[l];
                     this.printKind(1, " resultIn " + l);

                     for(int i = 0; i < l; ++i) {
                        res[i] = this.resultPartIn(i);
                     }

                     eres = res;
                  } catch (Exception var14) {
                     eres = var14;
                  }

                  return eres;
               case 62:
                  try {
                     eres = this.portInString();
                  } catch (Exception var13) {
                     eres = var13;
                  }

                  this.printKind(1, " resultIn Err" + eres);
                  return eres;
               default:
                  eres = "resultIn: ERR_PROTOCOL " + code;
                  return eres;
               }
            default:
               eres = "resultIn: ERR_PORT_STATE " + this.state;
               return eres;
            }
         } finally {
            this.state = old;
         }
      }
   }

   Object resultPartIn(int i) {
      int code = this.streamInCode();
      switch(code) {
      case 36:
         try {
            int inx = this.portInInt();
            if (i != inx) {
               return new Object[]{ERR.PROTOCOL, i, inx, "resultPartIn"};
            }

            return this.newTS(inx, "resultPartIn");
         } catch (Exception var4) {
            return var4;
         }
      default:
         return new Object[]{ERR.PROTOCOL, code, "resultPartIn"};
      }
   }

   int streamOutFlush() {
      return this.portFlush();
   }

   int streamOutCode(int code) {
      return this.portOut((byte)code);
   }

   int streamOut(Object v) {
      if (v == null) {
         return this.streamOutCode(96);
      } else if (v instanceof Integer) {
         return this.streamOut((Integer)v);
      } else if (v instanceof String) {
         return this.streamOut((String)v);
      } else {
         String type = v.getClass().getName();
         if (type.equals("[I")) {
            return this.streamOut((int[])v);
         } else if (type.equals("[D")) {
            return this.streamOut((double[])v);
         } else {
            return type.equals("[Ljava.lang.String;") ? this.streamOut((String[])v) : ERR.VAL_TYPE.code();
         }
      }
   }

   int streamOut(String s) {
      this.printKind(2, " streamOut STRING: " + s);
      this.portOut((byte)66);
      return this.portOut(s);
   }

   int streamOut(int v) {
      this.printKind(2, " streamOut INT: " + v);
      this.portOut((byte)65);
      return this.portOut(v);
   }

   boolean streamOutEmpty(Object a, int code, String note) {
      if (a != null && Array.getLength(a) != 0) {
         return false;
      } else {
         this.printKind(2, " streamOut EMPTY_SEQ" + note);
         this.portOut((byte)code);
         return true;
      }
   }

   int streamOut(byte[] a) {
      if (this.streamOutEmpty(a, 104, "B")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQBYTE " + a.length);
         this.portOut((byte)105);
         this.portOut(a.length);
         this.portOut(a);
         return a.length;
      }
   }

   int streamOut(short[] a) {
      if (this.streamOutEmpty(a, 106, "K")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQSHORT " + a.length);
         this.portOut((byte)107);
         this.portOut(a.length);

         for(int i = 0; i < a.length; ++i) {
            this.portOut(a[i]);
         }

         return a.length;
      }
   }

   int streamOut(int[] a) {
      if (this.streamOutEmpty(a, 98, "I")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQINT " + a.length);
         this.portOut((byte)99);
         this.portOut(a.length);

         for(int i = 0; i < a.length; ++i) {
            this.portOut(a[i]);
         }

         return a.length;
      }
   }

   int streamOut(float[] a) {
      if (this.streamOutEmpty(a, 110, "F")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQFLOAT " + a.length);
         this.portOut((byte)111);
         this.portOut(a.length);

         for(int i = 0; i < a.length; ++i) {
            this.portOut(a[i]);
         }

         return a.length;
      }
   }

   int streamOut(double[] a) {
      if (this.streamOutEmpty(a, 102, "R")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQREAL " + a.length);
         this.portOut((byte)103);
         this.portOut(a.length);

         for(int i = 0; i < a.length; ++i) {
            this.portOut(a[i]);
         }

         return a.length;
      }
   }

   int streamOut(String[] a) {
      if (this.streamOutEmpty(a, 100, "S")) {
         return 0;
      } else if (a.length >= 16777216) {
         return ERR.TOO_LONG.code();
      } else {
         this.printKind(2, " streamOut SEQSTRING " + a.length);
         this.portOut((byte)101);
         this.portOut(a.length);

         for(int i = 0; i < a.length; ++i) {
            this.portOut(a[i]);
         }

         return a.length;
      }
   }

   int streamInCode(int timeout) throws SocketException {
      int old = this.socket.getSoTimeout();

      int var4;
      try {
         this.socket.setSoTimeout(timeout);
         var4 = this.streamInCode();
      } finally {
         this.socket.setSoTimeout(old);
      }

      return var4;
   }

   int streamInCode() {
      if (this.haveCode == 1000000) {
         return this.portIn_8();
      } else {
         int r = this.haveCode;
         this.haveCode = 1000000;
         return r;
      }
   }

   Object streamInValue(boolean doThrow) throws IOException {
      Object w = null;
      int code = this.streamInCode();
      String type;
      switch(code) {
      case 65:
         type = "INT";
         w = new Integer(this.portInInt());
         break;
      case 66:
         type = "STRING";
         w = this.portInString();
         break;
      case 96:
         type = "NULL";
         w = null;
         break;
      case 98:
         type = "EMPTY_SEQI";
         w = new int[0];
         break;
      case 99:
         type = "SEQINT";
         w = this.portInSeqInt();
         break;
      case 100:
         type = "EMPTY_SEQS";
         w = new String[0];
         break;
      case 101:
         type = "SEQSTRING";
         w = this.portInSeqString();
         break;
      case 102:
         type = "EMPTY_SEQR";
         w = new double[0];
         break;
      case 103:
         type = "SEQREAL";
         w = this.portInSeqReal();
         break;
      case 104:
         type = "EMPTY_SEQB";
         w = new byte[0];
         break;
      case 105:
         type = "SEQBYTE";
         w = this.portInSeqByte();
         break;
      case 106:
         type = "EMPTY_SEQK";
         w = new short[0];
         break;
      case 107:
         type = "SEQSHORT";
         w = this.portInSeqShort();
         break;
      case 110:
         type = "EMPTY_SEQF";
         w = new float[0];
         break;
      case 111:
         type = "SEQFLOAT";
         w = this.portInSeqFloat();
         break;
      default:
         type = "NOT_DATA";
         w = null;
         if (this.haveCode == 1000000) {
            this.haveCode = code;
         } else if (doThrow) {
            throw new IOException("streamInValue protocol error and bad code: " + this.haveCode + " " + code);
         }

         if (doThrow) {
            throw new IOException("streamInValue bad code: " + code + " " + this.lastReadError);
         }
      }

      this.printKind(2, " streamIn " + type + ": " + w);
      return w;
   }

   int portIn_8() {
      int res;
      try {
         res = this.inStream.read();
         this.printKind(5, " portIn_8: " + res);
      } catch (SocketTimeoutException var3) {
         this.lastReadError = var3;
         res = ERR.TIMEOUT.code();
      } catch (IOException var4) {
         this.lastReadError = var4;
         res = ERR.PORT_IO.code();
      }

      return res;
   }

   int portIn_16() {
      int lo = this.portIn_8();
      if (lo < 0) {
         return lo;
      } else {
         int hi = this.portIn_8();
         if (hi < 0) {
            return hi;
         } else {
            hi = lo + (hi << 8);
            this.printKind(4, " portIn_16: " + hi);
            return hi;
         }
      }
   }

   int portInInt() throws IOException {
      int s = this.portIn_8();
      if (s < 0) {
         throw new IOException("portInInt->portIn_8_a=" + s + " " + this.lastReadError);
      } else {
         byte count;
         boolean neg;
         switch(s) {
         case 0:
            count = 4;
            neg = false;
            break;
         case 1:
            count = 4;
            neg = true;
            break;
         case 2:
            count = 3;
            neg = false;
            break;
         case 3:
            count = 3;
            neg = true;
            break;
         case 4:
            count = 2;
            neg = false;
            break;
         case 5:
            count = 2;
            neg = true;
            break;
         case 6:
            count = 1;
            neg = false;
            break;
         case 7:
            count = 1;
            neg = true;
            break;
         case 8:
            return -1;
         default:
            return s - 9;
         }

         int v = 0;
         int shift = 0;

         for(int j = 0; j < count; ++j) {
            int w = this.portIn_8();
            if (w < 0) {
               throw new IOException("portInInt->portIn_8_b" + j + "=" + w + " " + this.lastReadError);
            }

            v |= w << shift;
            shift += 8;
         }

         if (neg) {
            v = -v;
         }

         this.printKind(3, " portInInt: " + v);
         return v;
      }
   }

   String portInString() throws IOException {
      int len = this.portInInt();
      if (len < 0) {
         return null;
      } else {
         StringBuffer s = new StringBuffer(len);

         for(int i = 0; i < len; ++i) {
            int b = this.portIn_16();
            if (b < 0) {
               throw new IOException("portIn=" + b + " " + this.lastReadError);
            }

            s.append((char)b);
         }

         String v = s.toString();
         this.printKind(3, " portInString: " + v);
         return v;
      }
   }

   int[] portInSeqInt() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqInt: " + len);
      int[] a = new int[len];

      for(int i = 0; i < len; ++i) {
         a[i] = this.portInInt();
      }

      return a;
   }

   short[] portInSeqShort() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqShort: " + len);
      short[] a = new short[len];

      for(int i = 0; i < len; ++i) {
         a[i] = (short)this.portInInt();
      }

      return a;
   }

   byte[] portInSeqByte() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqByte: " + len);
      byte[] a = new byte[len];
      int bytes = this.inStream.read(a);
      int s = len - bytes;
      if (bytes < len) {
         throw new IOException("streamInSeqByte short: " + s);
      } else {
         return a;
      }
   }

   String[] portInSeqString() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqString: " + len);
      String[] a = new String[len];

      for(int i = 0; i < len; ++i) {
         a[i] = this.portInString();
      }

      return a;
   }

   float[] portInSeqFloat() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqFloat: " + len);
      float[] a = new float[len];

      for(int i = 0; i < len; ++i) {
         a[i] = this.portInFloat();
      }

      return a;
   }

   double[] portInSeqReal() throws IOException {
      int len = this.portInInt();
      this.printKind(3, " portInSeqReal: " + len);
      double[] a = new double[len];

      for(int i = 0; i < len; ++i) {
         a[i] = this.portInReal();
      }

      return a;
   }

   double portInReal() throws IOException {
      int s = this.portIn_8();
      if (s < 0) {
         throw new IOException("portInReal->portIn_8_a=" + s + " " + this.lastReadError);
      } else {
         long e0 = (long)this.portIn_8();
         if (e0 < 0L) {
            throw new IOException("portInReal->portIn_8_b=" + e0 + " " + this.lastReadError);
         } else {
            long e1 = (long)this.portIn_8();
            if (e1 < 0L) {
               throw new IOException("portInReal->portIn_8_c=" + e1 + " " + this.lastReadError);
            } else {
               long v = 0L;

               for(int shift = 0; shift < 51; shift += 8) {
                  long w = (long)this.portIn_8();
                  if (w < 0L) {
                     throw new IOException("portInReal->portIn_8_d" + shift + "=" + w + " " + this.lastReadError);
                  }

                  v |= w << shift;
               }

               v |= (e1 << 8 | e0) << 52;
               if (s != 0) {
                  v |= Long.MIN_VALUE;
               }

               double r = Double.longBitsToDouble(v);
               this.printKind(3, " portInReal: " + r);
               return r;
            }
         }
      }
   }

   float portInFloat() throws IOException {
      int s = this.portIn_8();
      if (s < 0) {
         throw new IOException("portInFloat->portIn_8_a=" + s + " " + this.lastReadError);
      } else {
         int e0 = this.portIn_8();
         if (e0 < 0) {
            throw new IOException("portInFloat->portIn_8_b=" + e0 + " " + this.lastReadError);
         } else {
            int e1 = this.portIn_8();
            if (e1 < 0) {
               throw new IOException("portInFloat->portIn_8_c=" + e1 + " " + this.lastReadError);
            } else {
               int v = 0;

               for(int shift = 0; shift < 23; shift += 8) {
                  int w = this.portIn_8();
                  if (w < 0) {
                     throw new IOException("portInFloat->portIn_8_d" + shift + "=" + w + " " + this.lastReadError);
                  }

                  v |= w << shift;
               }

               v |= (e1 << 8 | e0) << 23;
               if (s != 0) {
                  v |= Integer.MIN_VALUE;
               }

               float r = Float.intBitsToFloat(v);
               this.printKind(3, " portInFloat: " + r);
               return r;
            }
         }
      }
   }

   int portFlush() {
      if (this.endpos > 0) {
         try {
            this.printKind(4, " portFlush " + this.endpos + " bytes: " + this.buffer[0] + " " + this.buffer[1] + "...");
            this.outStream.write(this.buffer, 0, this.endpos);
            this.outStream.flush();
         } catch (Exception var2) {
            return ERR.FLUSH_IO.code();
         }
      }

      this.endpos = 0;
      return 0;
   }

   int portReserveSpace(int size) {
      int rc = 0;
      if (this.endpos + size > this.buffer.length) {
         rc = this.portFlush();
      }

      return rc < 0 ? rc : this.endpos + size;
   }

   int portOut(byte x) {
      int rc = this.portReserveSpace(1);
      if (rc < 0) {
         return rc;
      } else {
         this.printKind(3, " portOut byte: " + x);
         this.bufferOut_8(x);
         return this.endpos;
      }
   }

   int portOut(byte[] x) {
      int free = this.buffer.length - this.endpos;
      if (free < x.length) {
         this.portFlush();
      }

      for(int i = 0; i < x.length; i += 100) {
         int rc = this.portReserveSpace(100);
         if (rc < 0) {
            return rc;
         }

         int end = i + 100;
         if (x.length < end) {
            end = x.length;
         }

         for(int j = i; j < end; ++j) {
            this.bufferOut_8(x[j]);
         }
      }

      return this.endpos;
   }

   int portOut(char x) {
      int rc = this.portReserveSpace(2);
      if (rc < 0) {
         return rc;
      } else {
         this.printKind(4, " portOut char: " + x);
         this.bufferOut_16(x);
         return this.endpos;
      }
   }

   int portOut(short x) {
      return this.portOut((int)x);
   }

   int portOut(int x) {
      long v = (long)x;
      int tag;
      byte top;
      byte len;
      if (v < 0L) {
         v = -v;
         if (v == 1L) {
            tag = 8;
            top = 0;
            len = 1;
         } else if (v < 256L) {
            tag = 7;
            top = 8;
            len = 2;
         } else if (v < 65536L) {
            tag = 5;
            top = 16;
            len = 3;
         } else if (v < 16777216L) {
            tag = 3;
            top = 24;
            len = 4;
         } else {
            tag = 1;
            top = 32;
            len = 5;
         }
      } else if (v < 247L) {
         tag = x + 9;
         top = 0;
         len = 1;
      } else if (v < 256L) {
         tag = 6;
         top = 8;
         len = 2;
      } else if (v < 65536L) {
         tag = 4;
         top = 16;
         len = 3;
      } else if (v < 16777216L) {
         tag = 2;
         top = 24;
         len = 4;
      } else {
         tag = 0;
         top = 32;
         len = 5;
      }

      int rc = this.portReserveSpace(len);
      if (rc < 0) {
         return rc;
      } else {
         this.printKind(3, " portOut int: " + x);
         this.bufferOut_8(tag);

         for(int shift = 0; shift < top; shift += 8) {
            this.bufferOut_8((int)(255L & v >> shift));
         }

         return this.endpos;
      }
   }

   int portOut(float x) {
      int rc = this.portReserveSpace(6);
      if (rc < 0) {
         return rc;
      } else {
         this.printKind(3, " portOut float: " + x);
         int b = Float.floatToRawIntBits(x);
         int s = 0;
         if (b < 0) {
            b ^= Integer.MIN_VALUE;
            s = 1;
         }

         int e = b >> 23;
         b |= 2139095040;
         b ^= 2139095040;
         this.bufferOut_8(s);
         this.bufferOut_16(e);

         for(int shift = 0; shift < 23; shift += 8) {
            this.bufferOut_8((int)(255L & (long)(b >> shift)));
         }

         return this.endpos;
      }
   }

   int portOut(double x) {
      int rc = this.portReserveSpace(10);
      if (rc < 0) {
         return rc;
      } else {
         this.printKind(3, " portOut double: " + x);
         long b = Double.doubleToRawLongBits(x);
         int s = 0;
         if (b < 0L) {
            b ^= Long.MIN_VALUE;
            s = 1;
         }

         int e = (int)(b >> 52);
         b |= 9218868437227405312L;
         b ^= 9218868437227405312L;
         this.bufferOut_8(s);
         this.bufferOut_16(e);

         for(int shift = 0; shift < 52; shift += 8) {
            this.bufferOut_8((int)(255L & b >> shift));
         }

         return this.endpos;
      }
   }

   int portOut(String x) {
      int rc;
      if (x == null) {
         rc = this.portOut((int)-1);
         if (rc < 0) {
            return rc;
         }

         this.printKind(3, " portOut String: " + x);
      } else {
         rc = this.portOut(x.length());
         if (rc < 0) {
            return rc;
         }

         this.printKind(3, " portOut String: " + x);

         for(int i = 0; i < x.length(); ++i) {
            rc = this.portOut(x.charAt(i));
            if (rc < 0) {
               return rc;
            }
         }
      }

      return this.endpos;
   }

   int bufferOut_8(int x) {
      this.printKind(5, " bufferOut_8: " + x);
      this.buffer[this.endpos] = (byte)(255 & x);
      ++this.endpos;
      return this.endpos;
   }

   int bufferOut_16(int x) {
      this.printKind(5, " bufferOut_16: " + x);
      this.buffer[this.endpos] = (byte)(255 & x);
      ++this.endpos;
      this.buffer[this.endpos] = (byte)(255 & x >> 8);
      ++this.endpos;
      return this.endpos;
   }

   Object verifyConnection(boolean initialPort, boolean javaAdvertised) throws JLinkerLispException {
      int vct = LispCall.verifiedConnectTimeout;
      if (verifiedConnect == 0) {
         return null;
      } else if (JLCommon.lispVersion > 0 && JLCommon.lispVersion < 7000000) {
         return null;
      } else {
         int result = -1;
         Object err = null;
         int reply;
         if (initialPort) {
            idString = UUID.randomUUID().toString();
            this.streamOutCode(17);
            this.streamOutCode(verifiedConnect + 9);
            this.portFlush();

            try {
               reply = this.streamInCode(vct);
               if (reply == 18) {
                  this.streamOutCode(62);
                  this.portOut("Version mismatch.");
                  this.portFlush();
                  JLCommon.sleep((long)(2 * vct), "VerifyConnection cancel.");
                  return "Version mismatch,  Lisp is 8.2.";
               }

               if (reply == 62) {
                  this.portInString();
                  verifiedConnect = 0;
                  return null;
               }

               if (reply == -113) {
                  return "Timeout waiting for initial verify reply from Lisp.";
               }

               if (reply != 33) {
                  return "Unexpected initial verify reply from Lisp: " + reply;
               }

               result = this.portInInt();
               if (result < 0) {
                  return "Unexpected initial verify result from Lisp: " + result;
               }

               verifiedConnect = result;
               if (verifiedConnect == 0) {
                  return null;
               }
            } catch (IOException var9) {
               return var9;
            }
         }

         if (idString == null) {
            return "idstring is null!";
         } else {
            this.streamOutCode(initialPort ? 16 : 32);
            this.streamOutCode(verifiedConnect);
            this.streamOutCode(1);
            this.portOut(idString);
            this.portFlush();

            try {
               vct *= 2;
               reply = this.streamInCode(vct);
               if (reply == -113) {
                  err = "Timeout waiting for verify reply.";
               } else if (reply != 48) {
                  err = "Unexpected verify reply code " + reply;
               } else {
                  reply = this.streamInCode(vct);
                  if (reply <= 0) {
                     err = "Unexpected protocol level in reply " + reply;
                  } else if (reply < 0) {
                     err = "Lisp protocol level too low " + reply;
                  } else {
                     int n = this.streamInCode(vct);
                     if (n < 0) {
                        err = "Unexpected verify length " + n;
                     } else {
                        for(int i = 0; i < n; ++i) {
                           this.streamInValue(true);
                        }

                        result = 1;
                     }
                  }
               }
            } catch (IOException var10) {
               err = var10;
            }

            if (result > 0) {
               return this;
            } else {
               this.shutdown("Verify err " + err);
               return err;
            }
         }
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 745 ms
	
	Decompiled with FernFlower.
*/