package com.franz.jlinker;

import com.franz.jlinker.JLCommonSocket.CannotConnect;
import com.franz.jlinker.JLCommonSocket.JLSocketState;
import com.franz.jlinker.LispCall.JlinkerState;
import com.franz.jlinker.Transport.Listener;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

public class JLCommonSocket extends JLCommon {
   static Transport initialPortToLisp;
   public static JLSocketServer lispToJavaThread;
   private static JLSocketState jlinkerReady;
   public int notify_seq = -1;
   public static String default_l2j;
   public static String default_j2l;
   public String linkFile = "";
   static final String localName = "Java";
   int linkPort = 0;
   String linkHost = "";
   public String lisp_key = "NOT SET";
   public String java_key = System.getProperty("user.name") + Thread.currentThread().hashCode() + System.nanoTime() + Math.random();
   boolean lispAdvertises = false;
   boolean javaAdvertises = false;
   static Listener listener;

   static {
      jlinkerReady = JLSocketState.NULL;
      default_l2j = "LispToJava.trp";
      default_j2l = "JavaToLisp.trp";
      listener = null;
   }

   static boolean havePortToLisp() {
      return initialPortToLisp != null;
   }

   static Transport getPortToLisp(long timeout, Object[] eRep) {
      Transport init = initialPortToLisp;
      if (init == null) {
         return setERep(eRep, "Not connected - " + jlinkerReady);
      } else {
         JLConnectionPoolManager pm = JLConnectionPoolManager.poolManager;
         if (pm == null) {
            return init;
         } else {
            Transport res = pm.getPortToLisp(timeout, init, eRep);
            if (res == null) {
               return null;
            } else if (init == res) {
               return initialPortToLisp == null ? setERep(eRep, "Disconnecting or disconnected - " + jlinkerReady) : initialPortToLisp;
            } else {
               return res;
            }
         }
      }
   }

   static Transport setERep(Object[] eRep, Object rep) {
      if (eRep != null && eRep.length > 0) {
         eRep[0] = rep;
      }

      return null;
   }

   static boolean releasePortToLisp(Transport port, Object err) {
      JLConnectionPoolManager pm = JLConnectionPoolManager.poolManager;
      if (pm != null) {
         return pm.releasePortToLisp(port, err);
      } else {
         if (err instanceof IOException) {
            dsprint("Cannot continue after IOException " + err);
            disconnect();
         }

         return true;
      }
   }

   static boolean isReady() {
      return JLSocketState.READY == jlinkerReady;
   }

   static boolean isIdle() {
      Class var0 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (JLSocketState.NULL == jlinkerReady) {
            return true;
         } else {
            return JLSocketState.TERMINATED == jlinkerReady;
         }
      }
   }

   static boolean isConnecting() {
      Class var0 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (JLSocketState.CONNECTING == jlinkerReady) {
            return true;
         } else {
            return JLSocketState.CONNECTED == jlinkerReady;
         }
      }
   }

   static boolean isEnding() {
      Class var0 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (JLSocketState.ENDING == jlinkerReady) {
            return true;
         } else {
            return JLSocketState.TERMINATED == jlinkerReady;
         }
      }
   }

   static boolean setConnected() {
      JLSocketState newState = JLSocketState.READY;
      if (isLispVersion(7001014)) {
         newState = JLSocketState.CONNECTED;
      }

      Class var1 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (JLSocketState.CONNECTING == jlinkerReady) {
            jlinkerReady = newState;
         }

         if (JLSocketState.CONNECTED == jlinkerReady) {
            jlinkerReady = newState;
         }

         return jlinkerReady == newState;
      }
   }

   static boolean setReady() {
      Class var0 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (JLSocketState.CONNECTED == jlinkerReady) {
            jlinkerReady = JLSocketState.READY;
         }

         return JLSocketState.READY == jlinkerReady;
      }
   }

   static boolean isJlinkerState(JlinkerState target) {
      switch($SWITCH_TABLE$com$franz$jlinker$LispCall$JlinkerState()[target.ordinal()]) {
      case 1:
         return isIdle();
      case 2:
         return isConnecting();
      case 3:
         if (JLSocketState.READY == jlinkerReady) {
            return true;
         }

         return false;
      case 4:
         if (JLSocketState.ENDING == jlinkerReady) {
            return true;
         }

         return false;
      case 5:
         if (JLSocketState.TERMINATED == jlinkerReady) {
            return true;
         }

         return false;
      default:
         return false;
      }
   }

   static boolean beginConnect(int wait) {
      while(true) {
         Class var1 = JLCommon.class;
         synchronized(JLCommon.class) {
            if (isIdle()) {
               jlinkerReady = JLSocketState.CONNECTING;
               return true;
            }

            if (jlinkerReady != JLSocketState.ENDING) {
               return false;
            }
         }

         try {
            if (wait == 0) {
               return false;
            }

            if (wait < 0) {
               Thread.sleep(100L);
            } else {
               int d = Math.min(100, wait);
               Thread.sleep((long)d);
               wait -= d;
            }
         } catch (InterruptedException var2) {
            ;
         }
      }
   }

   static Listener listener() {
      return listener;
   }

   public JLCommonSocket(String[] pp) throws IllegalArgumentException {
      JLCommon.lispJavaConnection = this;
      this.linkPort = 0;
      this.linkHost = "";
      this.linkFile = "";
      this.scanargs(pp);
      this.startWithConnect();
   }

   public JLCommonSocket(String j2l, String lhost, int lport) throws IllegalArgumentException {
      JLCommon.lispJavaConnection = this;
      this.linkPort = lport;
      this.linkHost = lhost;
      this.linkFile = j2l;
      this.startWithConnect();
   }

   private void startWithConnect() {
      this.lispAdvertises = true;
      this.javaAdvertises = false;
      lispToJavaThread = null;
      dsprint("JLCommonSocket.startWithConnect: file/host:port=" + this.linkFile + "/" + this.linkHost + ":" + this.linkPort);
      Object tr;
      if (this.linkPort == 0) {
         tr = Transport.connectViaFile(this.linkFile);
         if (tr instanceof Object[]) {
            Object[] r = (Object[])tr;
            this.linkPort = (Integer)r[0];
            this.linkHost = (String)r[2];
            tr = r[1];
            dsprint("JLCommonSocket.startWithConnect: connection 1 to " + this.linkHost + ":" + this.linkPort);
         }
      } else {
         tr = Transport.connectToHostPort(this.linkHost, this.linkPort, "client", true);
      }

      dsprint("JLCommonSocket.startWithConnect: starting tr = " + tr);
      if (!(tr instanceof Transport)) {
         dsprint("JLCommonSocket.startWithConnect: connectToServer failed " + tr);
         throw new IllegalArgumentException("Lisp to Java: connectToServer failed " + tr);
      } else {
         initialPortToLisp = null;
         if (tr instanceof Transport) {
            initialPortToLisp = (Transport)tr;
            dsprint("JLCommonSocket.startWithConnect: javaToLispPort is " + initialPortToLisp);
            initDist();
            this.exchangeVersionInfo();
            lispToJavaThread = new JLSocketServer(this.linkHost, this.linkPort);
            lispToJavaThread.start();
            this.startMessages("startWithConnect");
         } else {
            dsprint("JLCommonSocket.startWithConnect: connectToServer failed " + tr);
            throw new IllegalArgumentException("Lisp to Java: connectToServer failed " + tr);
         }
      }
   }

   synchronized void shutdown() {
      if (initialPortToLisp != null) {
         JLConnectionPoolManager pm = JLConnectionPoolManager.poolManager;
         dsprint("Shutdown pm=" + pm + "  port=" + initialPortToLisp);
         if (pm == null) {
            initialPortToLisp.disconnect();
         } else {
            pm.shutdown(initialPortToLisp);
         }

         initialPortToLisp = null;
      }

      JLConnectionPoolManager.poolManager = null;
   }

   void exchangeVersionInfo() {
      Object r = initialPortToLisp.request("Java", 0, new int[0], new String[]{this.java_key}, new double[]{(double)minJavaVersion(), (double)version(), (double)minLispVersion()}, false);
      if (r instanceof String && !((String)r).startsWith("Wrong") && !((String)r).startsWith("Jlinker version mis-match") && !((String)r).startsWith("Incorrect ")) {
         this.lisp_key = (String)r;
         lispMinVersion = 6005000;
         lispVersion = 6005000;
         lispMinJava = 6005000;
         dsprint("exchangeVersionInfo: lisp_key is set - " + this.lisp_key);
      } else {
         if (!(r instanceof String[])) {
            dsprint("exchangeVersionInfo: error reply " + r);
            disconnect();
            throw new CannotConnect("Did not receive a lisp_key " + showRes(r));
         }

         String[] rr = (String[])r;
         this.lisp_key = rr[0];
         if (1 < rr.length) {
            lispMinVersion = Integer.parseInt(rr[1]);
         }

         if (2 < rr.length) {
            lispVersion = Integer.parseInt(rr[2]);
         }

         if (3 < rr.length) {
            lispMinJava = Integer.parseInt(rr[3]);
         }

         dsprint("exchangeVersionInfo: lisp_key is set - " + this.lisp_key);
      }

   }

   void startMessages(String from) {
      dsprint("JLCommonSocket." + from + ": " + "Java VM version " + versionStringOfJDK());
      dsprint("JLCommonSocket." + from + ": " + "jLinker version " + version());
   }

   public JLCommonSocket() {
   }

   public JLCommonSocket(String l2j, int port, String host, int timeoutSeconds) throws IllegalArgumentException {
      JLCommon.lispJavaConnection = this;
      this.javaAdvertises = true;
      this.lispAdvertises = false;
      lispToJavaThread = null;
      this.linkPort = port;
      this.linkHost = host;
      boolean writeFile = false;
      if (l2j != null) {
         writeFile = true;
      }

      JLCommon.dsprint("JLCommonSocket.advertiseInner: Advertising connection " + (writeFile ? "in file " + l2j : "") + " at " + host + ":" + port + " timeout=" + timeoutSeconds + "seconds");
      if (!writeFile && port == 0) {
         dsprint("advertise with underspecified server.");
         throw new IllegalArgumentException("advertise with underspecified server.");
      } else {
         if (timeoutSeconds > 0) {
            Transport.timeout = (long)(timeoutSeconds * 1000);
         }

         try {
            listener = Transport.makeListener(port);
         } catch (IOException var14) {
            throw new IllegalArgumentException("advertise.makeListener failed " + var14);
         }

         File file = null;
         Object cp = null;

         try {
            if (writeFile) {
               try {
                  file = Transport.advertFile(l2j, host, listener.localPort());
               } catch (IOException var13) {
                  throw new IllegalArgumentException("advertise.writeFile failed " + var13);
               }
            }

            cp = Transport.makeClientDataPort(listener);
         } finally {
            if (file != null && !sdebug) {
               dsprint("Deleting file " + l2j);
               file.delete();
            }

         }

         Transport tr = null;
         if (cp instanceof Transport) {
            tr = (Transport)cp;
            initialPortToLisp = tr;
            dsprint("JLCommonSocket.startByAdvertising: client_object is set - " + initialPortToLisp);
            initDist();
            this.exchangeVersionInfo();
            lispToJavaThread = new JLSocketServer(listener);
            lispToJavaThread.start();
            this.startMessages("startByAdvertising");
         } else {
            throw new IllegalArgumentException("advertise: makeClientDataPort failed " + cp);
         }
      }
   }

   static String showRes(Object r) {
      String v = "";
      if (r instanceof Object[]) {
         v = "[";
         Object[] a = (Object[])r;

         for(int i = 0; i < a.length; ++i) {
            v = v + a[i] + " ";
         }
      } else {
         v = v + r;
      }

      return v;
   }

   boolean notifyLisp(String ev, int h, String p, int timeout) {
      ++this.notify_seq;
      dsprint("JLCommonSocket.notifyLisp: sending " + ev);
      boolean r = this.notifyLispShort(ev, h, this.notify_seq, p, timeout);
      dsprint("JLCommonSocket.notifyLisp: sent " + r + " " + ev);
      return r;
   }

   boolean notifyLisp(String ev, int h, String[] p, int[] l, int timeout) {
      ++this.notify_seq;
      dsprint("JLCommonSocket.notifyLisp: sending " + ev);
      boolean r = this.notifyLispBoth(ev, h, this.notify_seq, p, l, timeout);
      dsprint("JLCommonSocket.notifyLisp: sent " + r + " " + ev);
      return r;
   }

   private boolean notifyLispShort(String ev, int h, int notify_seq, String p, int timeout) {
      return this.notifyLispBoth(ev, h, notify_seq, new String[]{p}, new int[0], timeout);
   }

   private boolean notifyLispBoth(String ev, int h, int notify_seq, String[] p, int[] l, int timeout) {
      int[] nums = new int[4 + l.length];
      nums[0] = -1;
      nums[1] = 5;
      nums[2] = h;
      nums[3] = notify_seq;
      Object v = null;
      Transport port = null;

      int i;
      for(i = 0; i < l.length; ++i) {
         nums[4 + i] = l[i];
      }

      String[] strings = new String[1 + p.length];
      strings[0] = ev;

      for(i = 0; i < p.length; ++i) {
         strings[1 + i] = p[i];
      }

      TranStruct d = new TranStruct("Self", 7680, nums, strings, new double[0]);
      if (Transport.exData == 0) {
         d.type |= 57344;
      }

      Object err = null;
      Object[] eRep = new Object[1];

      try {
         port = getPortToLisp((long)timeout, eRep);
         if (port == null) {
            v = "notifyLispBoth: Null port - " + eRep[0];
         } else {
            v = port.invoke(new TranStruct[]{d}, true);
         }
      } catch (Exception var19) {
         err = var19;
      } finally {
         if (port != null) {
            releasePortToLisp(port, err);
         }

      }

      JLCommon.dsprint("JLCommonSocket.notifyLispBoth: invoke=> " + v);
      return port != null;
   }

   int isRegistered(Object x) {
      int h = JLCommon.getSObHandle(x);
      return h == 0 ? 0 : h;
   }

   public int sendRegisteredEvent(String ev, Object target, String[] s, int[] l, int timeout) {
      int h = this.isRegistered(target);
      if (h == 0) {
         return 0;
      } else {
         return this.notifyLisp(ev, h, s, l, timeout) ? this.notify_seq : -1;
      }
   }

   public static String versionStringOfJDK() {
      try {
         return System.getProperty("java.vm.version", "1.1");
      } catch (Exception var1) {
         return var1.toString();
      }
   }

   public Object[] lispValuesOp(Object rr, String called, int min, int max, boolean firstRefP) {
      TranStruct[] res = (TranStruct[])rr;
      String err = "";
      int vct = -1;
      int rlen = res.length;
      if (rlen == 1 && JLSocketClient.errorP(res[0])) {
         err = "LispError from " + called + ": " + res[0].stringValue(0) + " " + res[0].stringValue(1);
         JLSocketClient.discardInLisp(res[0]);
      } else if (res[0].integerP()) {
         vct = res[0].intValue();
         if (vct != rlen - 1) {
            err = "Strange result (r[0] not length) " + called + ": " + res.toString();
         } else if (vct >= min && vct <= max) {
            if (vct > 0 && firstRefP && !JLSocketClient.pointerP(res[1])) {
               err = "Unexpected value returned from " + called + ": " + res[1].toString();
            }
         } else {
            err = "Unexpected values count from " + called + ": " + (new Integer(vct)).toString();
         }
      } else if (rlen == 0) {
         err = "Strange zero-length result.";
      } else if (rlen == 1) {
         err = "Strange result(not err, not String) " + called + ": len=" + rlen + " " + res[0];
      } else if (rlen == 2) {
         err = "Strange result(not err, not String) " + called + ": len=" + rlen + " " + res[0] + " " + res[1];
      } else {
         err = "Strange result(not err, not String) " + called + ": len=" + rlen + " " + res[0] + " " + res[1] + " ...";
      }

      return new Object[]{new Integer(vct), err};
   }

   public static synchronized void initDist() {
      JLSocketClient.table = new Hashtable();
      JLSocketClient.nextIndex = 1001;
      JLSocketClient.tableLive = 0;
      JLSocketClient.tableFree = 0;
      JLSocketClient.oldestFree = null;
      JLSocketClient.newestFree = null;
      JLSocketClient.connectIndex = (int)(System.currentTimeMillis() >> 13 & 536870911L);
      JLCommon.j_to_handle = new Hashtable(1000);
      JLCommon.new_handle = 1;
      JLCommon.lispMinJava = -1;
      JLCommon.lispMinVersion = -1;
      JLCommon.lispVersion = -1;
   }

   public static boolean connectionComplete() {
      int dt = 20;
      int wc = 0;

      while(!isReady()) {
         try {
            Thread.sleep((long)dt);
         } catch (InterruptedException var3) {
            ;
         }

         if (isReady()) {
            return true;
         }

         if (isEnding()) {
            throw new CannotConnect("Shutdown - a");
         }

         wc += dt;
         if (wc > 30000) {
            JLCommon.dsprint("JLCommonSocket.connectionComplete: failing with timeout.");
            if (lispToJavaThread != null) {
               cancelServer();
               JLCommon.sleep(2000L, "connectionComplete b");
            }

            throw new CannotConnect("Timeout waiting for remote server.");
         }

         if (wc == 3000 || wc == 10000 || wc == 20000) {
            JLCommon.dsprint("JLCommonSocket.connectionComplete: waiting for remote server...");
         }
      }

      if (isReady()) {
         return true;
      } else {
         throw new CannotConnect("Shutdown - b");
      }
   }

   static void cancelServer() {
      if (listener != null) {
         listener.cancel = true;
      }
   }

   static void sleeper(long millis) {
      try {
         Thread.sleep(millis);
      } catch (InterruptedException var3) {
         ;
      }

   }

   public static boolean disconnect() {
      Class var0 = JLCommon.class;
      synchronized(JLCommon.class) {
         if (isEnding()) {
            return false;
         }

         jlinkerReady = JLSocketState.ENDING;
      }

      JLSocketServer serverThread = lispToJavaThread;
      if (serverThread == Thread.currentThread()) {
         serverThread.scheduleDisconnect();
         return false;
      } else {
         return disconnectInternal(serverThread);
      }
   }

   static boolean disconnectInternal(JLSocketServer serverThread) {
      if (lispJavaConnection != null) {
         lispJavaConnection.shutdown();
         lispJavaConnection = null;
      }

      if (listener != null) {
         listener.close();
      }

      sleeper(500L);
      if (serverThread != null) {
         lispToJavaThread = null;
         serverThread.shutdown("Common disconnect");

         while(serverThread != null) {
            try {
               serverThread.join();
               serverThread = null;
            } catch (InterruptedException var2) {
               ;
            }
         }
      }

      listener = null;
      initDist();
      jlinkerReady = JLSocketState.TERMINATED;
      return false;
   }

   static boolean connectInner(boolean findFile, String j2l, String lHost, int lPort) {
      if (findFile) {
         JLCommon.dsprint("JLCommonSocket.connectInner(" + j2l + ")");

         try {
            new JLCommonSocket(j2l, "", 0);
         } catch (Exception var7) {
            JLCommon.dsprint("JLCommonSocket.connectInner: failed " + var7);
            LispCall.connectError = var7;
            return false;
         }
      } else {
         JLCommon.dsprint("JLCommonSocket.connectInner(" + lHost + ":" + lPort + ")");

         try {
            new JLCommonSocket("", lHost, lPort);
         } catch (CannotConnect var5) {
            throw var5;
         } catch (Exception var6) {
            JLCommon.dsprint("JLCommonSocket.connectInner: failed " + var6);
            LispCall.connectError = var6;
            return false;
         }
      }

      if (!connectionComplete()) {
         return disconnect();
      } else {
         JLCommon.dsprint("JLCommonSocket.connectInner: done.");
         return true;
      }
   }

   static boolean connectLoop(boolean findFile, String j2l, String lHost, int lPort, int pollInterval, int pollCount) {
      if (isReady()) {
         JLCommon.dsprint("JLCommonSocket.connectLoop not needed.");
         return true;
      } else if (!beginConnect(0)) {
         JLCommon.dsprint("JLCommonSocket.connectLoop busy in some other thread.");
         return false;
      } else {
         initJlinker();
         if (pollCount <= 0) {
            return disconnect();
         } else {
            JLCommon.dsprint("JLCommonSocket.connectLoop begin: " + findFile + "(" + j2l + ") " + lHost + ":" + lPort + " " + pollInterval + "x" + pollCount);

            try {
               for(; !connectInner(findFile, j2l, lHost, lPort); JLCommon.dsprint("JLCommonSocket.connectLoop trying again.")) {
                  if (pollInterval < 0) {
                     pollCount = -1;
                  } else {
                     --pollCount;
                  }

                  if (pollCount <= 0) {
                     return disconnect();
                  }

                  JLCommon.dsprint("JLCommonSocket.connectLoop sleeping " + pollCount + " " + pollInterval);

                  try {
                     JLCommon.sleep((long)pollInterval, "connectLoop");
                  } catch (Exception var7) {
                     ;
                  }
               }
            } catch (CannotConnect var8) {
               JLCommon.dsprint("JLCommonSocket.connectLoop CannotConnect " + var8);
               return disconnect();
            }

            JLCommon.dsprint("JLCommonSocket.connectLoop done.");
            return true;
         }
      }
   }

   public static boolean connect(String host, int port, int pollInterval, int pollCount) {
      if (pollInterval < 0) {
         pollInterval = LispCall.defaultPollInterval;
      }

      if (pollCount < 0) {
         pollCount = LispCall.defaultPollCount;
      }

      return connectLoop(false, (String)null, host, port, pollInterval, pollCount);
   }

   public static boolean connect(String j2l, int pollInterval, int pollCount) {
      if (pollInterval < 0) {
         pollInterval = LispCall.defaultPollInterval;
      }

      if (pollCount < 0) {
         pollCount = LispCall.defaultPollCount;
      }

      if (j2l == null || "".equals(j2l)) {
         j2l = default_j2l;
      }

      return connectLoop(true, j2l, "", 0, pollInterval, pollCount);
   }

   static boolean advertiseInner(String l2j, String host, int port, int timeoutSeconds) {
      initJlinker();
      if (!beginConnect(0)) {
         JLCommon.dsprint("JLCommonSocket.advertiseInner: bad initial state " + jlinkerReady);
         return false;
      } else {
         new JLCommonSocket(l2j, port, host, timeoutSeconds);
         if (!connectionComplete()) {
            return disconnect();
         } else {
            JLCommon.dsprint("JLCommonSocket.advertiseInner: done.");
            return true;
         }
      }
   }

   public static boolean advertise(String l2j, String host, int port, int timeoutSeconds) {
      if (l2j == null || "".equals(l2j)) {
         l2j = default_l2j;
      }

      try {
         return advertiseInner(l2j, host, port, timeoutSeconds);
      } catch (IllegalArgumentException var5) {
         dsprint("advertise failed: " + var5);
         LispCall.connectError = var5;
         return false;
      }
   }

   private static void initJlinker() {
      String vc = "";
      String db = "";
      int vt = -1;

      try {
         vc = System.getProperty("com.franz.jlinker.verify", "");
         db = System.getProperty("com.franz.jlinker.debug", "");
         vt = Integer.parseInt(System.getProperty("com.franz.jlinker.verifytimeout", ""));
      } catch (Exception var4) {
         ;
      }

      if ("true".equalsIgnoreCase(vc)) {
         Transport.verifiedConnect = 1;
      } else if ("false".equalsIgnoreCase(vc)) {
         Transport.verifiedConnect = 0;
      }

      if ("true".equalsIgnoreCase(db)) {
         sdebug = true;
      } else if ("false".equalsIgnoreCase(db)) {
         sdebug = false;
      }

      if (vt > 0) {
         LispCall.verifiedConnectTimeout = vt;
      }

   }

   public static boolean advertise(int port, int timeoutSeconds) {
      try {
         return advertiseInner((String)null, "", port, timeoutSeconds);
      } catch (IllegalArgumentException var3) {
         dsprint("advertise failed: " + var3);
         LispCall.connectError = var3;
         return false;
      }
   }

   public static void main(String[] pp) throws IllegalArgumentException, InterruptedException {
      dsprint("JLCommonSocket: starting main.");
      LispCall.defaultConnectionPool = new int[]{-1, -1, -1, -1, -1, -1};
      if (beginConnect(0)) {
         new JLCommonSocket(pp);
         LispCall.prototype = new LispCallSocket();
         dsprint("JLCommonSocket: init done.");
         lispToJavaThread.join();
         dsprint("JLCommonSocket: leaving main.");
         System.exit(0);
      } else {
         throw new IllegalStateException("Jlinker in odd state " + jlinkerReady);
      }
   }

   public void scanargs(String[] pp) {
      for(int i = 0; i < pp.length; ++i) {
         if (pp[i].equals("-debug")) {
            JLCommon.sdebug = true;
         } else if (pp[i].equals("-lhost")) {
            ++i;
            this.linkHost = pp[i];
         } else if (pp[i].equals("-lport")) {
            try {
               ++i;
               this.linkPort = Integer.parseInt(pp[i]);
            } catch (Exception var9) {
               ;
            }
         } else {
            int vv;
            if (pp[i].equals("-tdebug")) {
               try {
                  ++i;
                  vv = Integer.parseInt(pp[i]);
                  dsprint(Transport.debug(vv, vv));
               } catch (Exception var8) {
                  ;
               }
            } else if (pp[i].equals("-tsdebug")) {
               try {
                  ++i;
                  vv = Integer.parseInt(pp[i]);
                  dsprint(Transport.debug(-1, vv));
               } catch (Exception var7) {
                  ;
               }
            } else if (pp[i].equals("-tcdebug")) {
               try {
                  ++i;
                  vv = Integer.parseInt(pp[i]);
                  dsprint(Transport.debug(vv, -1));
               } catch (Exception var6) {
                  ;
               }
            } else if (pp[i].equals("-verify")) {
               ++i;

               try {
                  vv = Integer.parseInt(pp[i]);
                  Transport.verifiedConnect = vv;
               } catch (NumberFormatException var5) {
                  ;
               }

               dsprint("Verify level " + Transport.verifiedConnect);
            }
         }
      }

   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 313 ms
	
	Decompiled with FernFlower.
*/