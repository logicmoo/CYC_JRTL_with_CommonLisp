package com.franz.jlinker;


public abstract class JavaLinkDist extends JLSocketClient {
   
   public static TranStruct newDistOb(int i) {
      return new TranStruct(i);
   }

   
   public static TranStruct newDistOb(String i) {
      return new TranStruct(i);
   }

   
   public static boolean connect(String lispHost, int lispPort, String javaHost, int javaPort, int pollInterval, int pollCount) {
      return JLCommonSocket.connect(lispHost, lispPort, pollInterval, pollCount);
   }

   
   public static boolean connect(String j2l, String javaHost, int javaPort, int pollInterval, int pollCount) {
      return JLCommonSocket.connect(j2l, pollInterval, pollCount);
   }

   
   public static boolean advertise(int port, int timeoutSeconds) {
      return JLCommonSocket.advertise(port, timeoutSeconds);
   }

   
   public static boolean advertise(String l2j, String host, int port, int timeoutSeconds) {
      return JLCommonSocket.advertise(l2j, host, port, timeoutSeconds);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 13 ms
	 @deprecated 
	@deprecated 
	@deprecated 
	@deprecated 
	@deprecated 
	@deprecated 
	@deprecated 
	Decompiled with FernFlower.
*/