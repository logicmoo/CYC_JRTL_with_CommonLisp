package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;
import java.util.ArrayList;

public abstract class JLWrapper {
   static ArrayList<Integer> toDiscard = new ArrayList();
   static JLWrapper deadChain = null;
   Object deadLink;
   static final Object LIVE = new String[]{"live"};
   static final Object DEAD = new String[]{"dead"};

   public JLWrapper() {
      this.deadLink = LIVE;
   }

   static TypeCode encodeType(String s) {
      TypeCode[] var4;
      int var3 = (var4 = TypeCode.values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         TypeCode t = var4[var2];
         if (s.equals(t.getTypeChar())) {
            return t;
         }
      }

      return TypeCode.UNKNOWN;
   }

   static TypeCode encodeType(int r) {
      TypeCode[] var4;
      int var3 = (var4 = TypeCode.values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         TypeCode t = var4[var2];
         if (r == TypeCode.access$2(t)) {
            return t;
         }
      }

      return null;
   }

   abstract int getIndexInLisp();

   abstract boolean isLispPointer();

   abstract void setDiscarded();

   public static int[] report() {
      int d = 0;
      if (deadChain != null) {
         JLWrapper var1 = deadChain;
         synchronized(deadChain) {
            for(JLWrapper w = deadChain; w != null; w = (JLWrapper)w.deadLink) {
               ++d;
            }
         }
      }

      return new int[]{toDiscard.size(), d};
   }

   static synchronized void addDeadLink(JLWrapper str) {
      if (DEAD != str.deadLink) {
         if (LIVE == str.deadLink && str.isLispPointer()) {
            str.deadLink = deadChain;
            deadChain = str;
         }

      }
   }

   static synchronized int getDeadNum() {
      if (deadChain == null) {
         return 0;
      } else {
         JLWrapper deadEntry = deadChain;
         deadChain = (JLWrapper)deadEntry.deadLink;
         deadEntry.deadLink = DEAD;
         return deadEntry.getIndexInLisp();
      }
   }

   static void pullDeadNums() {
      while(true) {
         int dn = getDeadNum();
         if (dn == 0) {
            return;
         }

         ArrayList var1 = toDiscard;
         synchronized(toDiscard) {
            toDiscard.add(dn);
         }
      }
   }

   static int[] getNumArray(int batch) {
      if (batch < 0) {
         batch = LispCall.discardBatchSize;
      }

      int[] anum = null;
      int m;
      if (batch < 1) {
         m = toDiscard.size();
      } else {
         m = batch;
      }

      if (m <= toDiscard.size()) {
         ArrayList var3 = toDiscard;
         synchronized(toDiscard) {
            int n = toDiscard.size();
            if (m < n) {
               n = m;
            }

            if (n > 0) {
               anum = new int[n];

               for(int i = 0; i < n; ++i) {
                  anum[i] = (Integer)toDiscard.remove(0);
               }
            }
         }
      }

      return anum;
   }

   static int[] collectDeadNums(Object[] stra) {
      int batch = -1;
      JLCommon.dsprint("discardInLisp arg=" + stra.length + "  old=" + toDiscard.size());
      ArrayList var2 = toDiscard;
      synchronized(toDiscard) {
         Object[] var6 = stra;
         int var5 = stra.length;
         int var4 = 0;

         while(true) {
            if (var4 >= var5) {
               break;
            }

            Object ob = var6[var4];
            if (ob instanceof JLWrapper) {
               JLWrapper str = (JLWrapper)ob;
               if (str.isLispPointer()) {
                  toDiscard.add(str.getIndexInLisp());
                  str.setDiscarded();
               }
            } else if (ob instanceof Number) {
               batch = ((Number)ob).intValue();
            }

            ++var4;
         }
      }

      JLCommon.dsprint("discardInLisp  after args=" + toDiscard.size());

      while(true) {
         int dn = getDeadNum();
         if (dn == 0) {
            JLCommon.dsprint("discardInLisp  after deadNums=" + toDiscard.size());
            return getNumArray(batch);
         }

         ArrayList var11 = toDiscard;
         synchronized(toDiscard) {
            toDiscard.add(dn);
         }
      }
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 50 ms
	
	Decompiled with FernFlower.
*/