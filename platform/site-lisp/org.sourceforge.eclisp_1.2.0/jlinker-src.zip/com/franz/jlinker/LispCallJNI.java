package com.franz.jlinker;

import com.franz.jlinker.JLWrapper.TypeCode;
import com.franz.jlinker.LispCall.JlinkerState;
import java.lang.reflect.Field;

public class LispCallJNI extends LispCallImplementation {
   static Class<Object> opclass = Object.class;
   LispCall lci;
   String argtypes = "";
   int rescount = -1;
   public String restypes = null;
   TypeCode[] resCodes = null;
   public Object res0 = null;
   public Object res1 = null;
   public Object res2 = null;
   public Object res3 = null;
   public Object res4 = null;
   public int int0 = 0;
   public float float0 = 0.0F;
   public double double0 = 0.0D;
   static Object[] eventQueue = null;
   static int eventCount = 0;
   static Thread lispThread;
   static int callFlag = 0;

   Class<?> getOpClass() {
      return opclass;
   }

   LispCallImplementation builder(LispCall parent, String op) {
      LispCallJNI x = new LispCallJNI();
      x.lci = parent;
      if (!op.equals("")) {
         parent.lispOp = op;
      }

      return x;
   }

   void setOp(String op) {
      this.setOp((Object)op);
   }

   void setOp(Object op) {
      this.lci.lispOp = op;
      if (this.lci.state == 0) {
         this.lci.state = 1;
      }

   }

   synchronized int addArgWrapped(String type, Object x) {
      if (this.lci.state != 1) {
         throw new IllegalArgumentException("Wrong state");
      } else {
         int n = this.lci.newHolder(x);
         if (n == 1) {
            this.argtypes = type;
         } else {
            this.argtypes = this.argtypes + type;
         }

         return n;
      }
   }

   synchronized int addArg(int x) {
      return this.addArgWrapped("I", new Integer(x));
   }

   synchronized int addArg(short x) {
      return this.addArgWrapped("S", new Integer(x));
   }

   synchronized int addArg(byte x) {
      return this.addArgWrapped("B", new Integer(x));
   }

   synchronized int addArg(long x) {
      return this.addArgWrapped("J", new Long(x));
   }

   synchronized int addArg(boolean x) {
      int y = 0;
      if (x) {
         y = 1;
      }

      return this.addArgWrapped("Z", new Integer(y));
   }

   synchronized int addArg(int[] x) {
      return this.addArgWrapped("N", x);
   }

   synchronized int addArg(short[] x) {
      return this.addArgWrapped("M", x);
   }

   synchronized int addArg(byte[] x) {
      return this.addArgWrapped("K", x);
   }

   synchronized int addArg(String x) {
      return this.addArgWrapped("T", x);
   }

   synchronized int addArg(String[] x) {
      return this.addArgWrapped("U", x);
   }

   synchronized int addArg(double x) {
      return this.addArgWrapped("D", new Double(x));
   }

   synchronized int addArg(float x) {
      return this.addArgWrapped("F", new Float(x));
   }

   synchronized int addArg(double[] x) {
      return this.addArgWrapped("E", x);
   }

   synchronized int addArg(float[] x) {
      return this.addArgWrapped("G", x);
   }

   synchronized int addArg(Object x) {
      return this.addArgWrapped("X", x);
   }

   synchronized int addSymbol(String x) {
      return this.addArgWrapped("Y", new JNIWrapper(x, "", 0));
   }

   synchronized int addSymbol(String x, String pk) {
      return this.addArgWrapped("Y", new JNIWrapper(x, pk, 0));
   }

   synchronized int addSymbol(String x, String pk, int act) {
      return this.addArgWrapped("Y", new JNIWrapper(x, pk, act));
   }

   synchronized void assemble(String where) {
      if (this.lci.state != 1) {
         this.lci.throwWrongState(where, "");
      }

      Object[] argarray = new Object[this.lci.count];
      this.lci.args = argarray;

      for(int i = 0; i < this.lci.count; ++i) {
         argarray[this.lci.count - i - 1] = this.lci.chain.arg;
         this.lci.chain = this.lci.chain.next;
      }

      this.lci.count = 0;
      this.lci.state = 2;
   }

   native int callInLisp(int var1, Object var2, int var3, String var4, Object[] var5);

   native int nthIntValue(int var1, JNIWrapper var2);

   native Object nthObjectValue(int var1, JNIWrapper var2);

   static synchronized int callLispWithEvent(String ev, int h, String[] s, int[] i) {
      if (callFlag == 2) {
         return callLispHandler(ev, h, s, i);
      } else {
         eventQueue = new Object[]{ev, new Integer(h), s, i, eventQueue};
         ++eventCount;
         return 0;
      }
   }

   public static synchronized int pollEventQueue(int n) {
      int done = 0;

      for(int i = 0; i < n; ++i) {
         if (eventQueue == null) {
            return done;
         }

         Object[] ev = eventQueue;

         Object[] prev;
         for(prev = null; ev[4] != null; ev = (Object[])ev[4]) {
            prev = ev;
         }

         if (prev == null) {
            eventQueue = null;
         } else {
            prev[4] = null;
         }

         --eventCount;
         --done;
         callLispHandler((String)ev[0], (Integer)ev[1], (String[])ev[2], (int[])ev[3]);
      }

      return eventCount;
   }

   static native int callLispHandler(String var0, int var1, String[] var2, int[] var3);

   int setLispError(String desc) {
      this.rescount = -1;
      this.res0 = null;
      this.restypes = "R";
      this.resCodes = null;
      this.res1 = desc;
      return 0;
   }

   synchronized int call() throws JLinkerLispException {
      if (this.lci.state == 1) {
         this.assemble("call");
      }

      if (this.lci.state != 2) {
         this.lci.throwWrongState("call", "");
      }

      this.rescount = this.callInLisp(this.lci.callStyle, this.lci.lispOp, this.lci.lispOpKind, this.argtypes, (Object[])this.lci.args);
      if (this.rescount < 0) {
         throw new JLinkerLispException("Lisp error", this.res1);
      } else {
         if (!this.lci.retain) {
            this.lci.args = null;
         }

         if (this.lci.callStyle >= 3) {
            this.lci.waitref = this.res0;
            this.lci.state = 4;
            return 0;
         } else {
            this.lci.waitref = null;
            this.lci.state = 3;
            this.lci.res = this.lci;
            return this.rescount;
         }
      }
   }

   synchronized Object getValue(int i) {
      Object v = null;
      if (i >= 0 && i < this.rescount) {
         TypeCode restype = this.getResCode(i);
         if (restype == null) {
            this.lci.throwWrongState("getValue", " when result is not available.");
         }

         if (restype == TypeCode.SEEN) {
            this.lci.throwWrongState("getValue", " when value already retrieved once.");
         }

         if (restype == TypeCode.MISSING) {
            this.lci.throwWrongState("getValue", " when result is missing.");
         }

         if (restype == TypeCode.WRONG_STATE) {
            this.lci.throwWrongState("getValue", " when LispCall is in wrong state.");
         }

         if (restype == TypeCode.UNKNOWN) {
            this.lci.throwWrongState("getValue", " when result type is unknown.");
         } else if (restype == TypeCode.NULL) {
            v = null;
         } else if (restype == TypeCode.BOOL) {
            v = new Boolean(this.int0 == 1);
         } else if (restype == TypeCode.CHAR) {
            v = new Character((char)this.int0);
         } else if (restype == TypeCode.BYTE) {
            v = new Byte((byte)this.int0);
         } else if (restype == TypeCode.SHORT) {
            v = new Short((short)this.int0);
         } else if (restype == TypeCode.INT) {
            v = new Integer(this.int0);
         } else if (restype == TypeCode.FLOAT) {
            v = new Float(this.float0);
         } else if (restype == TypeCode.DOUBLE) {
            v = new Double(this.double0);
         } else if (i == 0) {
            v = this.res0;
         } else if (i == 1) {
            v = this.res1;
         } else if (i == 2) {
            v = this.res2;
         } else if (i == 3) {
            v = this.res3;
         } else if (this.rescount == 5) {
            v = this.res4;
         } else {
            v = this.nthObjectValue(i - 4, (JNIWrapper)this.res4);
         }

         if (!this.lci.retain) {
            switch(i) {
            case 0:
               this.res0 = null;
            case 1:
               this.res1 = null;
            case 2:
               this.res2 = null;
            case 3:
               this.res3 = null;
            case 4:
               if (this.rescount == 5) {
                  this.res4 = null;
               }
            default:
               this.resCodes[i] = TypeCode.SEEN;
            }
         }
      } else {
         this.lci.throwWrongState("getValue", " when index is out of range.");
      }

      return v;
   }

   
   @Deprecated
   int typeOf(JLWrapper vv) {
      if (vv instanceof JNIWrapper) {
         JNIWrapper v = (JNIWrapper)vv;
         return v.type.getTypeNum();
      } else {
         return TypeCode.UNKNOWN.getTypeNum();
      }
   }

   
   @Deprecated
   int typeOf(int i) {
      return this.getTypeCode(i).getTypeNum();
   }

   TypeCode getTypeCode(int i) {
      TypeCode rtc = this.getResCode(i);
      if (rtc == TypeCode.WRAPPER) {
         rtc = ((JNIWrapper)this.getValue(i)).type;
      }

      if (rtc != null) {
         return rtc;
      } else {
         return i >= 0 && this.rescount > i ? TypeCode.UNKNOWN : TypeCode.MISSING;
      }
   }

   synchronized int intValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (i == 0) {
         if (tp == TypeCode.INT || tp == TypeCode.SHORT || tp == TypeCode.BYTE) {
            return this.int0;
         }
      } else {
         if (tp == TypeCode.INT) {
            return (Integer)this.getValue(i);
         }

         if (tp == TypeCode.SHORT) {
            return (Short)this.getValue(i);
         }

         if (tp == TypeCode.BYTE) {
            return (Byte)this.getValue(i);
         }
      }

      throw new UnsupportedOperationException("intValue of " + tp.nameOfType());
   }

   synchronized long longValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (i == 0) {
         if (tp == TypeCode.INT || tp == TypeCode.SHORT || tp == TypeCode.BYTE) {
            return (long)this.int0;
         }

         if (tp == TypeCode.LONG) {
            return (Long)this.res0;
         }
      } else {
         if (tp == TypeCode.LONG) {
            return (Long)this.getValue(i);
         }

         if (tp == TypeCode.INT) {
            return (long)(Integer)this.getValue(i);
         }

         if (tp == TypeCode.SHORT) {
            return (long)(Short)this.getValue(i);
         }

         if (tp == TypeCode.BYTE) {
            return (long)(Byte)this.getValue(i);
         }
      }

      throw new UnsupportedOperationException("longValue of " + tp.nameOfType());
   }

   synchronized double doubleValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (i == 0) {
         if (tp == TypeCode.DOUBLE) {
            return this.double0;
         }

         if (tp == TypeCode.FLOAT) {
            return (double)this.float0;
         }
      } else {
         if (tp == TypeCode.DOUBLE) {
            return (Double)this.getValue(i);
         }

         if (tp == TypeCode.FLOAT) {
            return (double)(Float)this.getValue(i);
         }
      }

      throw new UnsupportedOperationException("doubleValue of " + tp.nameOfType());
   }

   synchronized float floatValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (i == 0) {
         if (tp == TypeCode.DOUBLE) {
            return (float)this.double0;
         }

         if (tp == TypeCode.FLOAT) {
            return this.float0;
         }
      } else {
         if (tp == TypeCode.DOUBLE) {
            return (float)(Double)this.getValue(i);
         }

         if (tp == TypeCode.FLOAT) {
            return (Float)this.getValue(i);
         }
      }

      throw new UnsupportedOperationException("floatValue of " + tp.nameOfType());
   }

   synchronized boolean booleanValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (i == 0) {
         if (tp == TypeCode.BOOL) {
            if (1 == this.int0) {
               return true;
            }

            return false;
         }
      } else if (tp == TypeCode.BOOL) {
         return (Boolean)this.getValue(i);
      }

      throw new UnsupportedOperationException("booleanValue of " + tp.nameOfType());
   }

   synchronized String stringValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.STRING) {
         return (String)this.getValue(i);
      } else {
         throw new UnsupportedOperationException("stringValue of " + tp.nameOfType());
      }
   }

   synchronized int[] intArrayValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.INT_ARRAY) {
         return (int[])this.getValue(i);
      } else {
         throw new UnsupportedOperationException("intArrayValue of " + tp.nameOfType());
      }
   }

   synchronized String[] stringArrayValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.STRING_ARRAY) {
         return (String[])this.getValue(i);
      } else {
         throw new UnsupportedOperationException("stringArrayValue of " + tp.nameOfType());
      }
   }

   synchronized double[] doubleArrayValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.DOUBLE_ARRAY) {
         return (double[])this.getValue(i);
      } else {
         throw new UnsupportedOperationException("doubleArrayValue of " + tp.nameOfType());
      }
   }

   synchronized float[] floatArrayValue(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.FLOAT_ARRAY) {
         return (float[])this.getValue(i);
      } else {
         throw new UnsupportedOperationException("floatArrayValue of " + tp.nameOfType());
      }
   }

   synchronized Object objectValue(int i) {
      return this.getValue(i);
   }

   synchronized String symbolName(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.SYMBOL) {
         return (String)((JNIWrapper)this.getValue(i)).data;
      } else {
         throw new UnsupportedOperationException("symbolName of " + tp.nameOfType());
      }
   }

   synchronized String symbolPackage(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.SYMBOL) {
         return ((JNIWrapper)this.getValue(i)).packageName;
      } else {
         throw new UnsupportedOperationException("symbolPackage of " + tp.nameOfType());
      }
   }

   synchronized String lispType(int i) {
      TypeCode tp = this.getTypeCode(i);
      if (tp == TypeCode.LISP_POINTER) {
         return ((JNIWrapper)this.getValue(i)).getLispType();
      } else {
         return tp == TypeCode.SYMBOL ? "symbol" : tp.nameOfType();
      }
   }

   synchronized int query(boolean doquery, boolean dofetch) {
      switch(this.lci.state) {
      case 0:
      case 1:
      case 2:
      case 6:
         return -100;
      case 3:
         if (this.rescount == -1) {
            return -99;
         }

         return this.rescount;
      case 4:
      case 5:
         if (this.lci.waitref == null) {
            return -100;
         } else {
            if (doquery && this.lci.state == 4) {
               int rc = this.nthIntValue(0, (JNIWrapper)this.lci.waitref);
               if (rc >= 0) {
                  this.lci.waitres = rc;
                  this.lci.state = 5;
               } else if (rc == -98) {
                  this.lci.waitres = rc;
                  this.lci.state = 5;
               } else if (rc == -99) {
                  this.lci.state = 3;
                  this.lci.res = this.lci;
                  return -99;
               }
            }

            if (dofetch && this.lci.state == 5) {
               this.rescount = this.callInLisp(2, "net.jlinker::jl-async-results", 0, "P", new Object[]{this.lci.waitref});
               this.lci.state = 3;
               this.lci.res = this.lci;
               if (this.rescount == -1) {
                  return 0;
               }

               return this.rescount;
            } else {
               if (this.lci.state == 5) {
                  if (doquery) {
                     return this.lci.waitres;
                  }

                  return -11;
               }

               return -10;
            }
         }
      default:
         return -100;
      }
   }

   String queryAsyncName() {
      if (this.lci.waitref == null) {
         return null;
      } else if (this.lci.state != 4) {
         return null;
      } else {
         Object name = this.nthObjectValue(1, (JNIWrapper)this.lci.waitref);
         return name instanceof String ? (String)name : null;
      }
   }

   synchronized void close() {
      this.reset();
   }

   synchronized void reset() {
      this.rescount = -1;
      this.restypes = null;
      this.resCodes = null;
      this.res0 = null;
      this.res1 = null;
      this.res2 = null;
      this.res3 = null;
      this.res4 = null;
      this.int0 = 0;
      this.float0 = 0.0F;
      this.double0 = 0.0D;
   }

   TypeCode getResCode(int i) {
      TypeCode r = null;
      if (this.restypes == null) {
         return null;
      } else {
         int ln = this.restypes.length();
         if (i >= 0 && i < ln) {
            if (this.resCodes == null) {
               this.resCodes = new TypeCode[ln];
            }

            r = this.resCodes[i];
            if (r == null) {
               this.resCodes[i] = JLWrapper.encodeType(this.restypes.substring(i, i + 1));
            }

            r = this.resCodes[i];
         }

         return r;
      }
   }

   synchronized void setArgWrapped(int i, TypeCode type, Object arg) {
      this.setArgWrapped(i, type.getTypeChar(), arg);
   }

   synchronized void setArgWrapped(int i, String type, Object arg) {
      switch(this.lci.state) {
      case 1:
         this.assemble("setArg");
      case 2:
         break;
      default:
         this.lci.throwWrongState("setArg", "");
      }

      this.argtypes = this.argtypes.substring(0, i) + type + this.argtypes.substring(i + 1);
      Object[] argarray = (Object[])this.lci.args;
      argarray[i] = arg;
   }

   synchronized void setArg(int i, boolean arg) {
      int v = 0;
      if (arg) {
         v = 1;
      }

      this.setArgWrapped(i, (String)"Z", new Integer(v));
   }

   synchronized void setArg(int i, int arg) {
      this.setArgWrapped(i, (String)"I", new Integer(arg));
   }

   synchronized void setArg(int i, byte arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.BOOL, arg);
   }

   synchronized void setArg(int i, short arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.SHORT, arg);
   }

   synchronized void setArg(int i, short[] arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.SHORT_ARRAY, arg);
   }

   synchronized void setArg(int i, long arg) {
      this.setArgWrapped(i, (String)"J", new Long(arg));
   }

   synchronized void setArg(int i, double arg) {
      this.setArgWrapped(i, (String)"D", new Double(arg));
   }

   synchronized void setArg(int i, float arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.FLOAT, new Double((double)arg));
   }

   synchronized void setArg(int i, String arg) {
      this.setArgWrapped(i, (String)"T", arg);
   }

   synchronized void setArg(int i, Object arg) {
      this.setArgWrapped(i, "P", arg);
   }

   synchronized void setArg(int i, int[] arg) {
      this.setArgWrapped(i, (String)"N", arg);
   }

   synchronized void setArg(int i, byte[] arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.BYTE_ARRAY, arg);
   }

   synchronized void setArg(int i, double[] arg) {
      this.setArgWrapped(i, (String)"E", arg);
   }

   synchronized void setArg(int i, float[] arg) {
      this.setArgWrapped(i, (TypeCode)TypeCode.FLOAT_ARRAY, arg);
   }

   synchronized void setArg(int i, String[] arg) {
      this.setArgWrapped(i, (String)"U", arg);
   }

   synchronized void setSymbol(int i, String name) {
      this.setArgWrapped(i, (String)"Y", new JNIWrapper(name, "", 0));
   }

   synchronized void setSymbol(int i, String name, String pk) {
      this.setArgWrapped(i, (String)"Y", new JNIWrapper(name, pk, 0));
   }

   synchronized void setSymbol(int i, String name, String pk, int act) {
      this.setArgWrapped(i, (String)"Y", new JNIWrapper(name, pk, act));
   }

   int mayCall() {
      switch(callFlag) {
      case 0:
         return 0;
      case 1:
      default:
         if (lispThread.equals(Thread.currentThread())) {
            return 1;
         }

         return -1;
      case 2:
         return 2;
      }
   }

   public static void setLispThread(int flag) {
      LispCall.prototype = new LispCallJNI();
      JLCommon.lispJavaConnection = new JLCommonJNI();
      if (flag == 2) {
         callFlag = 2;
      } else {
         lispThread = Thread.currentThread();
         callFlag = 1;
      }

   }

   public static byte[] getLongFieldBytes(Field field, Object instance) throws IllegalArgumentException, IllegalAccessException {
      byte[] val = new byte[9];
      long v = field.getLong(instance);
      val[0] = 1;
      if (v < 0L) {
         val[0] = -1;
         v = -(v + 1L);
      }

      for(int i = 8; i > 0; --i) {
         val[i] = (byte)((int)(v & 255L));
         v >>= 8;
      }

      return val;
   }

   public static byte[] getLongValueBytes(Long input) throws IllegalArgumentException {
      byte[] val = new byte[9];
      long v = input;
      val[0] = 1;
      if (v < 0L) {
         val[0] = -1;
         v = -(v + 1L);
      }

      for(int i = 8; i > 0; --i) {
         val[i] = (byte)((int)(v & 255L));
         v >>= 8;
      }

      return val;
   }

   public static void setLongFieldBytes(Field field, Object instance, int sign, int b1, int b2, int b3, int b4, int b5, int b6, int b7, int b8) throws IllegalArgumentException, IllegalAccessException {
      long v = (long)(b1 & 255) | (long)(b2 & 255) << 8 | (long)(b3 & 255) << 16 | (long)(b4 & 255) << 24 | (long)(b5 & 255) << 32 | (long)(b6 & 255) << 40 | (long)(b7 & 255) << 48 | (long)(b8 & 255) << 56;
      if (sign < 0) {
         v = -v - 1L;
      }

      field.setLong(instance, v);
   }

   boolean isJlinkerState(JlinkerState target) {
      switch($SWITCH_TABLE$com$franz$jlinker$LispCall$JlinkerState()[target.ordinal()]) {
      case 3:
         return true;
      default:
         return false;
      }
   }

   boolean isJlinkerState(long delay, JlinkerState... targets) {
      JlinkerState[] var7 = targets;
      int var6 = targets.length;

      for(int var5 = 0; var5 < var6; ++var5) {
         JlinkerState t = var7[var5];
         if (this.isJlinkerState(t)) {
            return true;
         }
      }

      return false;
   }

   long discardInLisp(Object... stra) {
      int[] anum = JLWrapper.collectDeadNums(stra);
      if (anum != null) {
         JLCommon.dsprint("LispCallJNI.discardInLisp calling Lisp " + anum.length);
         LispCall lc = new LispCall("net.jlinker::discard-in-lisp");
         lc.addArg((Object)null);
         lc.addArg(anum);

         try {
            lc.call();
         } catch (Exception var5) {
            ;
         }
      }

      return (long)JLWrapper.toDiscard.size();
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 195 ms
	 @deprecated 
	@deprecated 
	Decompiled with FernFlower.
*/