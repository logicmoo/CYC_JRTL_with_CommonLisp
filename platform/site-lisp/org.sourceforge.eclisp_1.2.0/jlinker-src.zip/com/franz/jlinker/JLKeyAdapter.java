package com.franz.jlinker;

import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class JLKeyAdapter extends KeyAdapter {
   public static synchronized void addTo(Component comp) {
      comp.addKeyListener(new JLKeyAdapter());
   }

   private void caller(String name, KeyEvent e) {
      String[] s = new String[]{e.paramString()};
      int[] l = new int[]{e.getModifiers(), e.isActionKey() ? 1 : 0, e.getKeyCode()};
      LispCall.dispatchEvent(name, e.getComponent(), s, l);
   }

   public void keyTyped(KeyEvent e) {
      this.caller("keyTyped", e);
   }

   public void keyPressed(KeyEvent e) {
      this.caller("keyPressed", e);
   }

   public void keyReleased(KeyEvent e) {
      this.caller("keyReleased", e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 12 ms
	
	Decompiled with FernFlower.
*/