package com.franz.jlinker;

import com.franz.jlinker.JavaLinkDist.InvokeException;

public class JLinkerInvokeException extends InvokeException {
   private static final long serialVersionUID = 1L;

   JLinkerInvokeException(String x) {
      super(x);
   }

   JLinkerInvokeException(String x, Object e) {
      super(x, e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 4 ms
	
	Decompiled with FernFlower.
*/