package com.franz.jlinker;

import com.franz.jlinker.JavaLinkDist.LispThrow;

public class JLinkerLispThrow extends LispThrow {
   private static final long serialVersionUID = 1L;
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 2 ms
	
	Decompiled with FernFlower.
*/