package com.franz.jlinker;

import java.awt.Component;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class JLComponentAdapter extends ComponentAdapter {
   public static synchronized void addTo(Component comp) {
      comp.addComponentListener(new JLComponentAdapter());
   }

   private void caller(String name, ComponentEvent e) {
      String[] s = new String[]{e.paramString()};
      int[] l = new int[0];
      LispCall.dispatchEvent(name, e.getComponent(), s, l);
   }

   public void componentResized(ComponentEvent e) {
      this.caller("componentResized", e);
   }

   public void componentMoved(ComponentEvent e) {
      this.caller("componentMoved", e);
   }

   public void componentShown(ComponentEvent e) {
      this.caller("componentShown", e);
   }

   public void componentHidden(ComponentEvent e) {
      this.caller("componentHidden", e);
   }
}

/*
	DECOMPILATION REPORT

	Decompiled from: G:\opt\CYC_JRTL_with_CommonLisp\platform\site-lisp\org.sourceforge.eclisp_1.2.0\lib\jlinker.jar
	Total time: 9 ms
	
	Decompiled with FernFlower.
*/